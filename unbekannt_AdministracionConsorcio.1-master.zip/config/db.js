/*
 * config/db.js 
 */

module.exports = {
//  url : 'mongodb://localhost:27017/starter-node-angular'
  url : 'mongodb://192.168.0.69:27017/admin'
    	
//    url : 'mongodb://adc:Acciona2015@ds037812.mongolab.com:37812/IbmCloud_5r4vndup_2held5bm'
}