angular.module('appRoutes', []).config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
	$locationProvider
	.html5Mode(false);
	
	$routeProvider
		.when('/',{
			redirectTo: '/mensaje/0'
		})
		.when('/login', {
			templateUrl: './views/login.html',
			controller: 'loginController'
		})
		.when('/mensaje', {
			templateUrl: './views/mensaje.html',
			controller: 'mensajeController'
		})
		.when('/mensaje/:id?', {
			templateUrl: './views/mensaje.html',
			controller: 'mensajeController'
		})
		.when('/usuario/:id?', {
			templateUrl: './views/usuario.html',
			controller: 'usuarioController'
		})
		.when('/generalidad/:id?', {
			templateUrl: './views/generalidad.html',
			controller: 'generalidadController'
		})
		.when('/novedad/:id?', {
			templateUrl: './views/novedad.html',
			controller: 'novedadController'
		})
		.when('/telefono/:id?', {
			templateUrl: './views/telefono.html',
			controller: 'telefonoController'
		})
		.when('/expensa/:id?', {
			templateUrl: './views/expensa.html',
			controller: 'expensaController'
		})
		.when('/pago/:id?', {
			templateUrl: './views/pago.html',
			controller: 'pagoController'
		})
		.when('/votacion/:id?', {
			templateUrl: './views/votacion.html',
			controller: 'votacionController'
		})
		.when('/reclamo/:id?', {
			templateUrl: './views/reclamo.html',
			controller: 'reclamoController'
		})
		.when('/configuracion', {
			templateUrl: './views/configuracion.html',
			controller: 'configuracionController'
		})
		.when('/error', {
			templateUrl: './views/configuracion.html'
		})
		.when('/galeriaExpensa/:id', {
			templateUrl: './views/galeriaExpensa.html',
			controller: 'galeriaExpensaController'
		})
		.when('/users/mensaje', {
			templateUrl: './views/mensaje.html',
			controller: 'usersMensajeController'
		})
		.when('/users/reclamo/:id', {
			templateUrl: './views/reclamo.html',
			controller: 'usersReclamoController'
		})
		.when('/users/votacion/:id', {
			templateUrl: './views/votacion.html',
			controller: 'usersVotacionController'
		})
		.when('/users/generalidad/:id?', {
			templateUrl: './views/generalidad.html',
			controller: 'usersGeneralidadController'
		})
		.when('/users/mensaje/:id?',{
			templateUrl: './views/mensaje.html',
			controller: 'usersMensajeController'
		})
		.when('/users/telefono/:id?',{
			templateUrl: './views/telefono.html',
			controller: 'usersTelefonoController'
		})
		.when('/users/novedad/:id?', {
			templateUrl: './views/novedad.html',
			controller: 'usersNovedadController'
		})
		.when('/users/expensa/:id?', {
			templateUrl: './views/expensa.html',
			controller: 'usersExpensaController'
		})
		.when('/users/pago/:id?', {
			templateUrl: './views/pago.html',
			controller: 'usersPagoController'
		})
		.when('/users/votacion/:id?', {
			templateUrl: './views/votacion.html',
			controller: 'usersVotacionController'
		})
		.otherwise({
			templateUrl: './views/error.html'
		})
}]);