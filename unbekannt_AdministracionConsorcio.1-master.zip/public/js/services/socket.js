adm.service('socket', function($rootScope){
	var socket = io();
	var service = {
		on: on,
		emit: emit,
		showNumberEvents: showNumberEvents,
		updateEvents: updateEvents,
		updateEventByConsorcio: updateEventByConsorcio
	};

	return service;

	function on(eventName, cb){
		socket.on(eventName, function (data){
			cb(data);
		});
	}

	function emit(eventName, data_aux){
		socket.emit(eventName, data_aux);
	}

	function showNumberEvents(){
		var events = JSON.parse(localStorage.getItem('events'));
		
		for(var x = 0; x < events.length; x++){
			if(events[x].idConsorcio == $rootScope.consorcio){
				$rootScope.countReclamo = events[x].reclamos;
				$rootScope.countMsg = events[x].mensajes;
				$rootScope.countPago = events[x].pagos;
			}
		}
	}

	function updateEvents(idConsorcio_aux, countReclamo_aux, countMsg_aux, countPago_aux){
		var events = JSON.parse(localStorage.getItem('events'));

		for(var x = 0; x < events.length; x++){
			if(events[x].idConsorcio == idConsorcio_aux){
				events[x].reclamos = events[x].reclamos + countReclamo_aux;
				events[x].mensajes = events[x].mensajes + countMsg_aux;
				events[x].pagos = events[x].pagos + countPago_aux;
			}
		}

		localStorage.setItem('events', JSON.stringify(events));

		showNumberEvents();
	}

	function updateEventByConsorcio(idConsorcio_aux, countReclamo_aux, countMsg_aux, countPago_aux){
		var events = JSON.parse(localStorage.getItem('events'));

		for(var x = 0; x < events.length; x++){
			if(events[x].idConsorcio == idConsorcio_aux){
				events[x].reclamos = events[x].reclamos - countReclamo_aux;
				events[x].mensajes = events[x].mensajes - countMsg_aux;
				events[x].pagos = events[x].pagos - countPago_aux;
			}
		}

		localStorage.setItem('events', JSON.stringify(events));

		showNumberEvents();
	}
});
