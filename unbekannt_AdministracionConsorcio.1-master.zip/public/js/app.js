var adm = angular
    .module('AdministracionConsorcio', ['ngAnimate', 'ngRoute', 'ngCookies', 'appRoutes', 'ui.bootstrap','ui.bootstrap.progressbar', 'ui.multiselect', 'ui.mask', 'ngTagsInput', 'acciona-crypto', 'smart-table', 'internationalPhoneNumber'])
.config([
    '$compileProvider',
    function( $compileProvider )
    {   
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|file|blob):|data:application|data:image\//); //Permitir apertura de archivos con el explorador
        // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)
    }
]);
var server = "";
adm.factory("auth", function($http, $cookies, $location, $rootScope, tipoHabitanteFactory)
{
    function SetCredentials(username, password, _id, nombreApellido, isAdmin){
        var authdata = username + ':' + password;

        $rootScope.globals = {
            currentUser: {
                id: _id,
                username: username,
                nombreApellido: nombreApellido,
                authdata: authdata,
                isAdmin: isAdmin
            }
        };

        var finCookie = new Date();
        finCookie.setHours(finCookie.getHours() + 12);

        var options = {
            expires: finCookie
        }

        $http.defaults.headers.common['Authorization'] = 'Basic ' + authdata; // jshint ignore:line
        $cookies.putObject('globals', $rootScope.globals, options);
    }

    function ClearCredentials(){
        $rootScope.globals = {};
        $cookies.remove('globals');
        $http.defaults.headers.common.Authorization = 'Basic ';
    }

    return{
        login : function(username, password, cb)
        {
            $http.get('/api/usuarioByMail?username=' + username + '&password=' + password)
         	.success(function(usuario){
                if(usuario == null){
                    cb(false);
                }
                else{
                	$rootScope.username = usuario.nombreApellido;
                    SetCredentials(usuario.mail, usuario.password, usuario._id, usuario.nombreApellido, true);
                    localStorage.setItem('login', 0);
                    cb(true);
                }
         	});           
            
        },
        loginPropInq : function(username, password, cb)
        {
            $http.get('/api/propInqByMail?username=' + username + '&password=' + password)
            .success(function(usuario){
                if(usuario == null || !usuario.activo){
                    cb(false);
                }
                else{
                    $rootScope.username = usuario.nombreApellido;

                    SetCredentials(usuario.mail, usuario.password, usuario._id, usuario.nombreApellido, false);

                    cb(true);
                }
            });           
            
        },
        loginUser : function(cods_array, user, cb)
        {
            $http.get('/mapi/verificarConsorcioWeb/' + cods_array + '/' + '0')
            .success(function(consorcio){
                if(consorcio.length){
                    var datos = {
                        nombreApellido: user.userNA,
                        mail: user.email,
                        telefono: user.telefono,
                        celular: user.celular,
                        uuid: "",
                        password: user.password,
                        descripcion: user.propietario ? 'Propietario' : 'Inquilino',
                        codigoDptoLote: cods_array[1],
                        codigo: cods_array[0],
                        fechaAlta: new Date(),
                        fechaBaja: ""
                    };

                    $http.post('/mapi/registroUsuario', {datos: datos, usuarioExiste: 'false'}).success(function(data){
                        $rootScope.username = data.nombreApellido;
                        SetCredentials(data.mail, data.password, data._id, data.nombreApellido, false);

                        cb(true);
                    });
                }
                else{
                    cb(false);
                }
            });
        },
        logout : function()
        {
            //al hacer logout eliminamos la cookie con $cookies.remove
            $rootScope.$broadcast("userLoggedOut");
            ClearCredentials();
            localStorage.setItem('login', 0);
            localStorage.setItem('events', null);
            //mandamos al login
            $location.path("/login");
        },
        clearCredentials: function() {
            ClearCredentials();
        },
        getUserName: function(cb){
        	var globals = $rootScope.globals;
            if(globals != undefined && globals.currentUser != undefined && globals != ''){
                cb(globals.currentUser.nombreApellido);
            }
            else{
                cb('');
            }
        },
        getUserMail: function(cb){
        	var globals = $rootScope.globals;
            if(globals != undefined && globals.currentUser != undefined && globals != ''){
                cb(globals.currentUser.username);
            }
            else{
                cb('');
            }
        },
        getCurrentUserId: function(cb){
            var globals = $rootScope.globals;
            if(globals != undefined && globals.currentUser != undefined && globals != ''){
                cb(globals.currentUser.id);
            }
            else{
                cb('');
            }
        },
        esPropietario : function(codigoConsorcio){
            $http.get(server  + '/mapi/getConsorcio?codigoConsorcio=' + codigoConsorcio).success(function(data){
                var propietario = false;
                var sinTipo = true;

                if(data[0].pisos.length != 0){
                    if(sinTipo){
                        for(var piso = 0; piso < data[0].pisos.length; piso++){
                            for(var dpto = 0; dpto < data[0].pisos[piso].deptos.length; dpto++){
                                for(var prop = 0; prop < data[0].pisos[piso].deptos[dpto].propietarios.length; prop++){
                                    if(data[0].pisos[piso].deptos[dpto].propietarios[prop].idUsuario == $rootScope.globals.currentUser.id && data[0].pisos[piso].deptos[dpto].propietarios[prop].tipo == 'Propietario'){
                                        propietario = true;
                                        sinTipo = false;
                                    }
                                }
                            }
                        }
                    }
                }
                else{
                    for(var lote = 0; lote < data[0].lotes.length; lote++){
                        if(sinTipo){
                            for(var prop = 0; prop < data[0].lotes[lote].propietarios.length; prop++){
                                if(data[0].lotes[lote].propietarios[prop].idUsuario == $rootScope.globals.currentUser.id && data[0].lotes[lote].propietarios[prop].tipo == 'Propietario'){
                                    propietario = true;
                                    sinTipo = false;
                                }
                            }
                        }
                    }
                }

                tipoHabitanteFactory.setTipo(propietario);
            });
        },
        in_array : function(needle, haystack)
        {
            var key = '';
            for(key in haystack)
            {
                if(haystack[key] == needle)
                {
                    return true;
                }
            }
            return false;
        }
    }
}); 

adm.factory("menssageFactory", function($http){
	return {
        verificarConversacion: function(participantes, cb){
            $http.get(server + "/app/verificarConversacion/" + participantes)
            .success(function(data){
                cb(data)
            })
        },
        crearConversacion: function(usuarioRemitente, participantes, cb){
            $http.post(server + "/app/crearConversacion", {usuarioRemitente: usuarioRemitente, participantes: participantes})
            .success(function(data){
                cb(data)
            })
        },
        crearMensaje: function(mensaje, cb){
            //console.log(mensaje);
            $http.post(server + '/app/crearMensaje',mensaje)
            .success(function(data){
                cb(data)
            });
        },
        actualizarConversacion: function(idConversacion, idUltimoMensaje, idUsuario, cb){
            $http.post(server + '/app/actualizarConversacion', {idConversacion: idConversacion, idUltimoMensaje: idUltimoMensaje, idUsuario: idUsuario})
            .success(function(data){
                cb(data);
            });
        },
		obtenerConversaciones: function(idUsuario, idConsorcio, cb){
			$http.get(server + "/app/obtenerConversaciones/" + idUsuario + "/" + idConsorcio)
			.success(function(data){
                var conversaciones = data;

                for (var i = 0; i < conversaciones.length; i++) 
                {
                    conversaciones[i].destinatarios = "";
                    if(conversaciones[i].avistantes.length == 2)
                    {
                        for (var j = 0; j < conversaciones[i].avistantes.length; j++)
                        {
                            if(conversaciones[i].avistantes[j].idUsuario._id != idUsuario)
                            {
                                conversaciones[i].destinatarios += conversaciones[i].avistantes[j].idUsuario.nombreApellido + '. ';
                            	
                            }
                            else
                            {
                                conversaciones[i].cantidadNoLeidos = conversaciones[i].avistantes[j].noLeidos;
                            }
                            
                        }
                    }
                    else
                    {
                        var numeroDestinatarios = 0;
                        for (var j = 0; j < conversaciones[i].avistantes.length; j++)
                        {
                            if(conversaciones[i].avistantes[j].idUsuario._id != idUsuario && numeroDestinatarios < 3)
                            {
                                conversaciones[i].destinatarios += conversaciones[i].avistantes[j].idUsuario.nombreApellido + ", ";
                                numeroDestinatarios++;
                            }
                            else
                            {
                                conversaciones[i].cantidadNoLeidos = conversaciones[i].avistantes[j].noLeidos;
                            }
                        }
                    }
                    conversaciones[i].destinatarios = conversaciones[i].destinatarios.replace(/,\s*$/, '');
                }
                
				cb(conversaciones);
			});
		},
        obtenerConversacion: function(idConversacion, cb){
            $http.get(server + "/app/obtenerConversacion/" + idConversacion)
            .success(function(data){
                cb(data);
            })
        },
        obtenerImagen: function(idImagen, cb){
            $http.get(server + "/api/obtenerArchivoById/" + idImagen)
            .success(function(data){
                cb(data);
            })
        }
	}
});

adm.factory('tipoHabitanteFactory', [function(){
    var propietario = false;
    
    return {
        setTipo: function(tipo){
            propietario = tipo;
        },
        esPropietario: function(){
            return propietario;
        }
    };
}]);

//mientras corre la aplicación, comprobamos si el usuario tiene acceso a la ruta a la que está accediendo
adm.run(function($rootScope, $cookies, $window, auth, $location, $http)
{
	$rootScope.location = $location;
	
   // keep user logged in after page refresh
    $rootScope.globals = $cookies.getObject('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata;
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        var loggedIn = $rootScope.globals.currentUser;
        if (!loggedIn) {
        	$rootScope.username = '';
            $location.path('/login');
        }
        else{
        	$rootScope.username = loggedIn.nombreApellido;
            $rootScope.$broadcast("userLogged");
        }
    });
});

adm.directive('uniqueEmail', ["$http", function ($http) {
	  return {
	    require:'ngModel',
	    restrict:'A',
	    link:function (scope, el, attrs, ngModel) {
	    	ngModel.$parsers.push(function (viewValue) {
	        if (viewValue) {
	          $http.get('/api/verifyUniqueEmail/' + viewValue)
	          .success(function(data){
	        	  if(data == true){
	        		  ngModel.$setValidity('uniqueEmail', true);
	        	  }
	        	  else{
	        		  ngModel.$setValidity('uniqueEmail', false);
	        	  }
	        	  return viewValue;
	          });
	        }
	        return viewValue;
	      });
	    }
	  };
}]);

adm.factory('commonFactory', function($filter, $timeout, $q){
	//fake call to the server, normally this service would serialize table state to send it to the server (with query parameters for example) and parse the response
	//in our case, it actually performs the logic which would happened in the server
	function getPage(elementList, start, number, params) {
		var deferred = $q.defer();
		var filtered = params.search.predicateObject ? $filter('filter')(elementList, params.search.predicateObject) : elementList;

		if (params.sort.predicate) {
			filtered = $filter('orderBy')(filtered, params.sort.predicate, params.sort.reverse);
		}

		var result = filtered.slice(start, start + number);

		deferred.resolve({
			data: result,
			numberOfPages: Math.ceil(filtered.length / number)
		});

		return deferred.promise;
	}
	
	return{
		getPage: getPage
	}
});

adm.directive('googlePlaces', function($window){
    return {
        restrict:'E',
        replace:true,
        scope: { 
        	location: '='
	 	},
        template: '<input class="form-control" id="google_places_ac" name="location" type="text" required/>',
        link: function($scope, elem, attrs){
        	elem.on('blur', onBlur);
    		
        	function onBlur(){
        		var autocompleteService = new google.maps.places.AutocompleteService();
            	var request = {
					input: elem.val() //le paso el string ingresado por el usuario para obtener la primera predicción
            	};
            		
            	autocompleteService.getPlacePredictions(request, function(predictions, status){
            		if(status == google.maps.places.PlacesServiceStatus.OK){
            			elem.val(predictions[0].description);
            			
            			var geocoder = new google.maps.Geocoder();
            			var geocoderRequest = {
        					placeId: predictions[0].place_id
            			};
            			
            			geocoder.geocode(geocoderRequest, function(result, GeocoderStatus){
            				if(GeocoderStatus == google.maps.GeocoderStatus.OK){
			            		$scope.location = {
									latitude: result[0].geometry.location.lat(),
									longitude: result[0].geometry.location.lng(),
									placeId: predictions[0].place_id
								};
            				}
            			});
            		}

            		$scope.$apply();
            	});
        	}
        	
        	var autocomplete = new google.maps.places.Autocomplete($("#google_places_ac")[0], {});
            
        	google.maps.event.addListener(autocomplete, 'place_changed', function() {
            	var place = autocomplete.getPlace();
                $scope.location = {
                		latitude: place.geometry.location.lat(),
                		longitude: place.geometry.location.lng(),
                		placeId: place.place_id
                };

                $scope.$apply();
            });
        }
    }
});

adm.directive('checkFileSize', function() {
    return {
        link: function(scope, elem, attr, ctrl) {
            function bindEvent(element, type, handler) {
                if (element.addEventListener) {
                    element.addEventListener(type, handler, false);
                } 
                else {
                    element.attachEvent('on' + type, handler);
                }
            }

            bindEvent(elem[0], 'change', function() {
                var validSize = true;

                for(var x = 0; x < this.files.length; x++){
                    if(parseInt(this.files[x].size / 1048576) > 6){
                        validSize = false;
                    }
                }

                scope.validSize = !validSize;
                scope.$apply();
            });
        }
    }
});