adm.controller('mensajeController', function ($rootScope, $location, $modal, $interval, auth, menssageFactory, $scope, $http, $anchorScroll, socket) {

    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }
    
	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    $scope.listaConversaciones = [];

    $scope.pageNumber = 1;

    //Popover de ayuda
    var rutaImagenes = '../images/mensajes/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Mensajes" permite mostrar la lista de conversaciones que el administrador mantiene con los inquilinos/propietarios.\nDesde el botón "Crear mensaje" accedemos a la pantalla de creación de conversación.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla "Nuevo mensaje" nos permite crear mensaje e iniciar o continuarla en caso de que ya exista una con los destinatarios seleccionados.\nEn esta podemos adjuntar imágenes y/o escribir texto.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla de conversación nos permite realizar un seguimiento de los mensajes intercambiados con uno o más inquilinos/propietarios.\nPodemos visualizar las imágenes adjuntas de los diferentes mensajes y ver su contenido.'
            }
        ]
    };

    //End Popover de ayuda

    function obtenerConversaciones(){
    	$scope.waiting = true;
    	auth.getCurrentUserId(function(_id){
    		if(_id){
	    		menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(data){
	    			$scope.waiting = false;
	    			$scope.listaConversaciones = data;
	    			$scope.row_collection = data;
	    		});
    		}
    	});
    }
    
    $scope.$on('seleccionarConsorcio', function() {
    	$scope.listaConversaciones = [];  
    	$scope.row_collection = [];  
    	obtenerConversaciones();

        if($rootScope.consorcio != 0){
            socket.showNumberEvents();
        }
    });

    var intervalPromise = $interval(function(){ obtenerConversaciones(); }, 30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
    auth.getCurrentUserId(function(_id){
        menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(data){
           $scope.listaConversaciones = data;
           $scope.row_collection = data;

	        //Filters
	        //Períodos disponibles
	        $scope.filtroAnios = [];
	        $scope.filtroMeses = [];
	        
	        for (var i = 0; i < 12; i++) {
	        	$scope.filtroMeses[i] = i + 1;
	        };
	        
	        for(var i = 0; i < $scope.listaConversaciones.length; i++){
	        	var year = new Date($scope.listaConversaciones[i].fechaUpdate).getFullYear();
	        	if(!$scope.filtroAnios.some(compararAnio)){
	        		$scope.filtroAnios.push(year.toString());
	        	}
	        }
        });
    });

    $scope.setPageInfo = function (newPage) {
        $scope.pageNumber = newPage;
    };

    function compararAnio(value, index, ar) {
        if (value == (new Date()).getFullYear()){
            return true;
        }
        else
        {
            return false;
        }
    }
    
    //Mensaje ModalInstance
    $scope.crearMensaje = function () {
        var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: 'nuevoMensaje.html',
            controller: 'modalMensajeController',
            size: 'lg',//large
            resolve: {
                url: function(){
                    return '/mensaje';
                },
                destinatarios: function(){
                    return null;
                },
                mensaje: function () {
                    return null;
                }
            }
        });
        modalInstance.result.then(function () {//EL Modal se cerró!
            $location.path( "/mensaje/" + $rootScope.consorcio);
        });
    };

    $scope.verConversacion = function(idConversacion, participantes, destinatarios, cantidadNoLeidos){
        var modalInstance = $modal.open({
        animation: true,//fade
        templateUrl: './views/verConversacion.html',
        controller: 'modalVerConversacionController',
        size: 'lg',//large
        resolve: {
                    url: function(){
                        return '/mensaje';
                    },
                    destinatarios: function(){
                        return destinatarios;
                    },
                    participantes: function(){
                        return participantes;
                    },
                    idConversacion: function(){
                        return idConversacion;
                    },
                    cantidadNoLeidos: function(){
                        return cantidadNoLeidos;
                    }
                }
        });
    
        modalInstance.result.then(function () {//EL Modal se cerró!
            auth.getCurrentUserId(function(_id){
                menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(datad){
                   $scope.listaConversaciones = datad;
                });
            });
            $location.path( "/mensaje/" + $rootScope.consorcio );
        });
    }
});

adm.controller('modalVerConversacionController', function ($cookies, $scope, $rootScope, $http, $window, $location, $modalInstance, menssageFactory, auth, participantes, idConversacion, destinatarios, $anchorScroll, url, socket) {
    $scope.viendoImagen = false;
    $scope.cargando = true;
    var titulo = "";

    $http.get('/api/countNoLeidosByConversacion/' + idConversacion).success(function(noLeidos){
        socket.updateEventByConsorcio($rootScope.consorcio, 0, noLeidos, 0);
    });

    $scope.saving = false;
	$scope.btnEnviar = "Enviar";
	
    if (participantes.length >= 4)
    {
        titulo = (participantes.length - 1).toString() + " personas";
    }
    else
    {
        titulo = destinatarios;
    }
    $scope.modalTitle = "Conversacion con " + titulo;
    $scope.mensaje = {usuariosDestinatarios : []};
    $scope.verAdjunto = false;

    menssageFactory.obtenerConversacion(idConversacion, function(mensajes){
        $scope.cargando = false;
        $scope.listaMensajes = mensajes.mensajes;

        auth.getCurrentUserId(function(_id){
            $scope.mensaje.usuarioRemitente = _id;
            $scope.mensaje.usuariosDestinatarios = $.grep(participantes, function( a ) {
                return a != _id;
            });
            menssageFactory.actualizarConversacion(idConversacion, undefined, _id , function(datac){

                $scope.scrollDown(mensajes); // Se encuentra en este callback para darle tiempo al scrolldown
            });
        });
    });

    $scope.scrollDown = function(arrayToScroll){
        $location.hash(arrayToScroll.mensajes[arrayToScroll.mensajes.length -1]._id);
        $anchorScroll();
    }

    $scope.borrarArchivo = function(indice){
        $scope.firstImage = undefined;
        $scope.verAdjunto = false;
        $scope.attach = undefined;
        document.getElementById('input').value = "";
    }

    $scope.setFileName = function(elem){
        $scope.fileType= "";
        $scope.fileType = elem.files[0].type;
        if ($scope.fileType.substring(0, 5) != 'image')
        {
            alert("El tipo del archivo que intenta subir no es soportado por la aplicacion.\nPor favor intente con otro formato." );
        }
        else
        {
            if (elem.files && elem.files[0]) 
            {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $scope.verAdjunto = true;
                    $scope.firstImage = e.target.result;
                    $scope.$apply();
                }
                reader.readAsDataURL(elem.files[0]);
            }
        }
    }

    $scope.verImagen = function(idImagen){ 
        $scope.viendoImagen = true;
        $scope.cargando = true;
        menssageFactory.obtenerImagen(idImagen, function(imagen){
            $scope.imagen = imagen;
            $scope.cargando = false;
        });
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
        menssageFactory.obtenerConversacion(idConversacion, function(mensajes){
            $scope.listaMensajes = mensajes.mensajes;
            auth.getCurrentUserId(function(_id){
                $scope.mensaje.usuarioRemitente = _id;
                $scope.mensaje.usuariosDestinatarios = $.grep(participantes, function( a ) {
                    return a != _id;
                });
                menssageFactory.actualizarConversacion(idConversacion, undefined, _id , function(datac){
                    //$scope.scrollDown(mensajes); // Se encuentra en este callback para darle tiempo al scrolldown
                });
            });
        });
    }

    $scope.ok = function () {      
        $scope.mensaje.idConversacion = idConversacion;

        if($scope.mensaje.mensaje == "" || $scope.mensaje.mensaje == undefined)
        {
            $scope.submitted = true;
        	
            $scope.saving = false;
			$scope.btnEnviar = "Enviar";
		}
    	else{
    		$scope.saving = true;
    		$scope.btnEnviar = "Enviando...";
    		
            if ($scope.attach != undefined)
            {
                $scope.mensaje.tieneImg = true;
                if ($scope.attach.type.substring(0, 5) == 'image')
                {
                    var fd = new FormData();
                    fd.append('file', $scope.attach);
                    $http.post('/api/crearArchivos',fd,{
                        transformRequest: angular.identity,
                        headers: {'Content-Type': undefined}
                    })
                    .success(function (idAdjunto) {

                        $scope.mensaje.adjuntoMensaje = idAdjunto[0];

                        menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                            auth.getCurrentUserId(function(idAdministrador){
                                menssageFactory.actualizarConversacion(idConversacion, mensaje._id, idAdministrador, function(data){
                                    $scope.attach = undefined;
                                    $scope.verAdjunto = false;
                                    $scope.mensaje.mensaje = undefined;
                                    menssageFactory.obtenerConversacion(idConversacion, function(mensajes){
                                        $scope.listaMensajes = mensajes.mensajes;
                                        $scope.scrollDown(mensajes);
                                        
                                        $scope.saving = false;
                            			$scope.btnEnviar = "Enviar";
                                    })
                                })
                            })
                        })
                    })
                }
            }
            else
            {
                $scope.mensaje.tieneImg = false;
                menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                    auth.getCurrentUserId(function(idAdministrador){
                        menssageFactory.actualizarConversacion(idConversacion, mensaje._id, idAdministrador, function(data){
                            $scope.attach = undefined;
                            $scope.verAdjunto = false;
                            $scope.mensaje.mensaje = undefined;
                            menssageFactory.obtenerConversacion(idConversacion, function(mensajes){
                                $scope.listaMensajes = mensajes.mensajes;
                                $scope.scrollDown(mensajes);
                                
                                $scope.saving = false;
                    			$scope.btnEnviar = "Enviar";
                            })
                        })
                    })
                })
            }
        }
    };

    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
      $location.path(url);
    };
});

//Controlador para modalInstance
adm.controller('modalMensajeController', function ($timeout, $cookies, $scope, $rootScope, $http, $window, $location, menssageFactory, $modalInstance, auth, mensaje, destinatarios, url) {
	var participantes = [];

	$scope.mostrandoMensaje = false;
    $scope.modalTitle = "Nuevo Mensaje";
    $rootScope.listaUsuarios =[];
    $scope.destinatarios = [];
    $scope.verAdjunto = false;
    $scope.mensaje = {
		usuariosDestinatarios: []
    }
    
    $scope.saving = false;
	$scope.btnEnviar = "Enviar";

    $scope.agregarParticipante = function(algo){
    	if(algo.esConsorcio){
    		var res = false;
			$http.get('/api/usuarioByConsorcioId/' + algo._id)
			.success(function(usuarios){
				if(usuarios.length == 0){
					$scope.errorDestinatarios = true;
					$timeout(function() {
						$scope.errorDestinatarios = false;
					}, 2000)
					res =  false;
				}
				else{
					for(var u = 0; u < usuarios.length; u++)
					{
						$scope.mensaje.usuariosDestinatarios.push(usuarios[u]._id);
						participantes.push(usuarios[u]._id);
					}
					res = true;
				}
				return res;
			});
		}
    	else{
    		$scope.mensaje.usuariosDestinatarios.push(algo._id);
			participantes.push(algo._id);
    	}
    }
    
    $scope.quitarParticipante = function(algo){
    	if(algo.esConsorcio){
			$http.get('/api/usuarioByConsorcioId/' + algo._id)
			.success(function(usuarios){
				for(var u = 0; u < usuarios.length; u++)
				{
					$scope.mensaje.usuariosDestinatarios = $.grep($scope.mensaje.usuariosDestinatarios, function(item){
																				item._id != algo._id
																			});
					
					participantes = $.grep(participantes, function(item){
												item._id != algo._id
										});
				}
			});
		}
    }
    
    if (destinatarios != null)
    {
        $scope.destinatarios.push(destinatarios);
    }

    auth.getCurrentUserId(function (idAdministrador){
        $scope.idAdministrador = idAdministrador;
    }); 

    $scope.ObtenerUsuarios = function(query){
   		return $http.get('/api/ddlUsuariosAndCByQueryAndAdmin/' + query + '/' + $scope.idAdministrador);/*AndUsuarios/' + query + "/" + $rootScope.listaUsuarios);*/
   	}

    $scope.borrarArchivo = function(indice){
        $scope.firstImage = undefined;
        $scope.verAdjunto = false;
        $scope.attach = undefined;
        document.getElementById('input').value = "";
    }

   	$scope.setFileName = function(elem){
        $scope.fileType= "";
        $scope.fileType = elem.files[0].type;
        if ($scope.fileType.substring(0, 5) != 'image')
        {
            alert("El tipo del archivo que intenta subir no es soportado por la aplicacion.\nPor favor intente con otro formato.");
        }
        else
        {
            if (elem.files && elem.files[0]) 
            {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $scope.verAdjunto = true;
                    $scope.firstImage = e.target.result;
                    $scope.$apply();
                }
        
                reader.readAsDataURL(elem.files[0]);
            }
        }
    }

    $scope.ok = function () {      

    	if($scope.mensaje.mensaje == "" || $scope.mensaje.mensaje == undefined || $scope.mensaje.usuariosDestinatarios.length == 0)
        {
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnEnviar = "Enviar";
		}
    	else{
    		$scope.saving = true;
    		$scope.btnEnviar = "Enviando...";
    		
	        auth.getCurrentUserId(function(idAdministrador){
	        	$scope.mensaje.usuarioRemitente = idAdministrador;
                
				/*for(var i = 0; i < $scope.destinatarios.length; i++)
				{
					if(!$scope.destinatarios[i].esConsorcio){
						$scope.mensaje.usuariosDestinatarios.push($scope.destinatarios[i]._id);
						participantes.push($scope.destinatarios[i]._id);
		
                }*/
				
                participantes.push($scope.mensaje.usuarioRemitente);

                menssageFactory.verificarConversacion(participantes, function(conversaciones){
                    if (conversaciones.length != 0) 
                    {
                        $scope.mensaje.idConversacion = conversaciones[0]._id;
                        if ($scope.attach != undefined)
                        {
                            $scope.mensaje.tieneImg = true;
                            if ($scope.attach.type.substring(0, 5) == 'image')
                            {
                                var fd = new FormData();
                                fd.append('file', $scope.attach);
                                $http.post('/api/crearArchivos',fd,{
                                    transformRequest: angular.identity,
                                    headers: {'Content-Type': undefined}
                                })
                                .success(function (idAdjunto) {

                                    $scope.mensaje.adjuntoMensaje = idAdjunto[0];

                                    menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                        auth.getCurrentUserId(function(idAdministrador){
                                            menssageFactory.actualizarConversacion(conversaciones[0]._id, mensaje._id, idAdministrador, function(data){
                                                $modalInstance.close();
                                                $location.path(url);
                                            })
                                        })
                                    })

                                })
                            }
                        }
                        else
                        {
                            $scope.mensaje.tieneImg = false;
                            menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                auth.getCurrentUserId(function(idAdministrador){
                                    menssageFactory.actualizarConversacion(conversaciones[0]._id, mensaje._id, idAdministrador, function(data){
                                        $modalInstance.close();
                                        $location.path(url);
                                    })
                                })
                            })
                        }
                    }
                    else
                    {
                        menssageFactory.crearConversacion($scope.mensaje.usuarioRemitente, participantes, function(conversacion){

                            $scope.mensaje.idConversacion = conversacion._id;
                            if ($scope.attach != undefined)
                            {
                                if ($scope.attach.type.substring(0, 5) == 'image')
                                {
                                    $scope.mensaje.tieneImg = true;
                                    var fd = new FormData();
                                    fd.append('file', $scope.attach);
                                    $http.post('/api/crearArchivos',fd,{
                                        transformRequest: angular.identity,
                                        headers: {'Content-Type': undefined}
                                    })
                                    .success(function (idAdjunto) {

                                        $scope.mensaje.adjuntoMensaje = idAdjunto[0];

                                        menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                            auth.getCurrentUserId(function(idAdministrador){
                                                menssageFactory.actualizarConversacion(conversacion._id, mensaje._id, idAdministrador, function(data){
                                                    $modalInstance.close();
                                                    $location.path(url);
                                                })
                                            })
                                        })
                                    })
                                }
                            }
                            else
                            {
                                $scope.mensaje.tieneImg = false;
                                menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                    auth.getCurrentUserId(function(idAdministrador){
                                        menssageFactory.actualizarConversacion(conversacion._id, mensaje._id, idAdministrador, function(data){
                                            $modalInstance.close();
                                            $location.path(url + '/' + $rootScope.consorcio);
                                        })
                                    })
                                })
                            }
                        });    
                    }
                });
                
                $scope.saving = false;
                $scope.btnEnviar = "Enviar";
	        });
    	}
    };
    //END CrearConsorcio
	$scope.cancel = function () {
        $modalInstance.dismiss('cancel');
        $location.path(url);
    };
});

adm.controller('usersMensajeController', function($scope, $location, $modal, $rootScope, $interval, menssageFactory, auth){
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }

    $scope.mostrarConsorcio = $rootScope.consorcio == 0;
    $scope.listaConversaciones = [];  
    
    function obtenerConversaciones(){
        $scope.waiting = true;
        auth.getCurrentUserId(function(_id){
            if(_id){
                menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(data){
                    $scope.waiting = false;
                    $scope.listaConversaciones = data;
                    $scope.row_collection = data;
                });
            }
        });
    }
    
    $scope.$on('seleccionarConsorcio', function() {
        $scope.listaConversaciones = [];  
        $scope.row_collection = [];  
        obtenerConversaciones();
    });

    var intervalPromise = $interval(function(){ obtenerConversaciones(); }, 30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
    auth.getCurrentUserId(function(_id){
        menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(data){
           $scope.listaConversaciones = data;
           $scope.row_collection = data;

            //Filters
            //Períodos disponibles
            $scope.filtroAnios = [];
            $scope.filtroMeses = [];
            
            for (var i = 0; i < 12; i++) {
                $scope.filtroMeses[i] = i + 1;
            };
            
            for(var i = 0; i < $scope.listaConversaciones.length; i++){
                var year = new Date($scope.listaConversaciones[i].fechaUpdate).getFullYear();
                if(!$scope.filtroAnios.some(compararAnio)){
                    $scope.filtroAnios.push(year.toString());
                }
            }
        });
    });

    function compararAnio(value, index, ar) {
        if (value == (new Date()).getFullYear()){
            return true;
        }
        else{
            return false;
        }
    }

    //Mensaje ModalInstance
    $scope.crearMensaje = function () {
        var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: 'nuevoMensaje.html',
            controller: 'userModalMensajeController',
            size: 'lg',//large
            resolve: {
                url: function(){
                    return '/users/mensaje';
                },
                destinatarios: function(){
                    return null;
                },
                mensaje: function () {
                    return null;
                }
            }
        });
        modalInstance.result.then(function () {//EL Modal se cerró!
            $location.path("/users/mensaje/" + $rootScope.consorcio);
        });
    };

    $scope.verConversacion = function(idConversacion, participantes, destinatarios, cantidadNoLeidos){     
        var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: './views/verConversacion.html',
            controller: 'modalVerConversacionController',
            size: 'lg',//large
            resolve: {
                url: function(){
                    return '/users/mensaje';
                },
                destinatarios: function(){
                    return destinatarios;
                },
                participantes: function(){
                    return participantes;
                },
                idConversacion: function(){
                    return idConversacion;
                }
            }
        });
    
        modalInstance.result.then(function () {//EL Modal se cerró!
            auth.getCurrentUserId(function(_id){
                menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(datad){
                   $scope.listaConversaciones = datad;
                });
            });
            $location.path( "/users/mensaje/" + $rootScope.consorcio);
        });
    }
});

adm.controller('userModalMensajeController', function($scope, $http, $rootScope, $location, $modalInstance, auth, menssageFactory){
    var participantes = [];

    $scope.btnEnviar = "Enviar";
    $scope.mostrandoMensaje = false;
    $scope.modalTitle = "Nuevo Mensaje";
    $rootScope.listaUsuarios =[];
    $scope.destinatarios = [];
    $scope.verAdjunto = false;
    $scope.mensaje = {
        usuariosDestinatarios: []
    }
    $scope.saving = false;

    auth.getCurrentUserId(function (idAdministrador){
        $scope.idAdministrador = idAdministrador;
    });

    $scope.administrador = $rootScope.nombreAdministrador + '(Administrador)';

    $scope.ObtenerUsuarios = function(query){
        return $http.get('/mapi/ddlUsuariosAndCByQueryAndAdmin/' + query + '/' + $scope.idAdministrador + '/' + $rootScope.consorcioCodigo);
    }

    participantes.push($rootScope.idAdministrador);
    $scope.mensaje.usuariosDestinatarios.push($rootScope.idAdministrador);

    $scope.agregarParticipante = function(algo){
        $scope.mensaje.usuariosDestinatarios.push(algo._id);
        participantes.push(algo._id);
    }

    $scope.quitarParticipante = function(algo){
        if(algo._id !== $rootScope.idAdministrador){
            $http.get('/api/usuarioByConsorcioId/' + algo._id).success(function(usuarios){
                for(var u = 0; u < usuarios.length; u++){
                    $scope.mensaje.usuariosDestinatarios = $.grep($scope.mensaje.usuariosDestinatarios, function(item){
                        item._id != algo._id
                    });

                    participantes = $.grep(participantes, function(item){
                        item._id != algo._id
                    });
                }
            });
        }
    }

    $scope.borrarArchivo = function(indice){
        $scope.firstImage = undefined;
        $scope.verAdjunto = false;
        $scope.attach = undefined;
        document.getElementById('input').value = "";
    }

    $scope.setFileName = function(elem){
        $scope.fileType= "";
        $scope.fileType = elem.files[0].type;

        if ($scope.fileType.substring(0, 5) != 'image'){
            alert("El tipo del archivo que intenta subir no es soportado por la aplicacion.\nPor favor intente con otro formato.");
        }
        else{
            if (elem.files && elem.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $scope.verAdjunto = true;
                    $scope.firstImage = e.target.result;
                    $scope.$apply();
                }
        
                reader.readAsDataURL(elem.files[0]);
            }
        }
    }

    $scope.ok = function () {
        if($scope.mensaje.mensaje == "" || $scope.mensaje.mensaje == undefined || $scope.mensaje.usuariosDestinatarios.length == 0){
            $scope.submitted = true;
            
            $scope.saving = false;
            $scope.btnEnviar = "Enviar";
        }
        else{
            $scope.saving = true;
            $scope.btnEnviar = "Enviando...";
            
            auth.getCurrentUserId(function(idAdministrador){
                $scope.mensaje.usuarioRemitente = idAdministrador;
                
                participantes.push($scope.mensaje.usuarioRemitente);

                menssageFactory.verificarConversacion(participantes, function(conversaciones){
                    if (conversaciones.length != 0){
                        $scope.mensaje.idConversacion = conversaciones[0]._id;

                        if ($scope.attach != undefined){
                            $scope.mensaje.tieneImg = true;
                            
                            if ($scope.attach.type.substring(0, 5) == 'image'){
                                var fd = new FormData();
                                fd.append('file', $scope.attach);

                                $http.post('/api/crearArchivos',fd,{
                                    transformRequest: angular.identity,
                                    headers: {'Content-Type': undefined}
                                }).success(function (idAdjunto) {
                                    $scope.mensaje.adjuntoMensaje = idAdjunto[0];

                                    menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                        auth.getCurrentUserId(function(idAdministrador){
                                            menssageFactory.actualizarConversacion(conversaciones[0]._id, mensaje._id, idAdministrador, function(data){
                                                $modalInstance.close();
                                                $location.path("/users/mensaje/");
                                            })
                                        })
                                    })

                                })
                            }
                        }
                        else{
                            $scope.mensaje.tieneImg = false;
                            menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                auth.getCurrentUserId(function(idAdministrador){
                                    menssageFactory.actualizarConversacion(conversaciones[0]._id, mensaje._id, idAdministrador, function(data){
                                        $modalInstance.close();
                                        $location.path("/users/mensaje/");
                                    })
                                })
                            })
                        }
                    }
                    else{
                        menssageFactory.crearConversacion($scope.mensaje.usuarioRemitente, participantes, function(conversacion){
                            $scope.mensaje.idConversacion = conversacion._id;
                            if ($scope.attach != undefined){
                                if ($scope.attach.type.substring(0, 5) == 'image'){
                                    $scope.mensaje.tieneImg = true;
                                    var fd = new FormData();

                                    fd.append('file', $scope.attach);
                                    $http.post('/api/crearArchivos',fd,{
                                        transformRequest: angular.identity,
                                        headers: {'Content-Type': undefined}
                                    }).success(function (idAdjunto) {

                                        $scope.mensaje.adjuntoMensaje = idAdjunto[0];

                                        menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                            auth.getCurrentUserId(function(idAdministrador){
                                                menssageFactory.actualizarConversacion(conversacion._id, mensaje._id, idAdministrador, function(data){
                                                    $modalInstance.close();
                                                    $location.path("/users/mensaje/");
                                                })
                                            })
                                        })
                                    })
                                }
                            }
                            else{
                                $scope.mensaje.tieneImg = false;

                                menssageFactory.crearMensaje($scope.mensaje, function(mensaje){
                                    auth.getCurrentUserId(function(idAdministrador){
                                        menssageFactory.actualizarConversacion(conversacion._id, mensaje._id, idAdministrador, function(data){
                                            $modalInstance.close();
                                            $location.path("/users/mensaje/" + $rootScope.consorcio);
                                        })
                                    })
                                })
                            }
                        });    
                    }
                });
            });
        }
    };

    $scope.cancel = function () {
        $modalInstance.dismiss('cancel');
        $location.path("/users/mensaje/" + $rootScope.consorcio);
    };
});