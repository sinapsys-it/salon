adm.controller('usuarioController', function ($rootScope, $scope, $http, usuarioFactory, $modal, $location, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }

    //Popover de ayuda
    var rutaImagenes = '../images/usuarios/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Propietarios" permite ver la lista de usuarios registrados en la aplicación.\nEntre los datos principales podemos ver el tipo de usuario y a traves de un indicador de color si esta activo(verde) o inactivo(amarillo).'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla propietario nos permite ver el detalle del usuario seleccionado.\nEn esta podemos ver todos sus datos, desactivarlo o activarlo según corresponda, eliminarlo o enviarle un mensaje.'
            }
        ]
    };

    //End Popover de ayuda
    $scope.pageNumber = 1;
    $scope.waiting = true;
    usuarioFactory.obtenerUsuarios($rootScope.consorcio, function(usuarios){
        $scope.listaUsuarios = usuarios;
        $scope.row_collection = usuarios;
        usuarioFactory.mostrarLotes(usuarios, function(flag){
        	$scope.mostrarLotes = flag;
        });
        $scope.waiting = false;
    });
    
    $scope.mostrarConsorcio = $rootScope.consorcio == 0;
    $scope.listaUsuarios = [];
    
    $scope.$on('seleccionarConsorcio', function() {   
    	$scope.listaUsuarios = [];
        $scope.row_collection = [];
    	$scope.waiting = true;
        usuarioFactory.obtenerUsuarios($rootScope.consorcio, function(usuarios){
            $scope.listaUsuarios = usuarios;
            $scope.row_collection = usuarios;
            usuarioFactory.mostrarLotes(usuarios, function(flag){
            	$scope.waiting = false;
            	$scope.mostrarLotes = flag;
            });
        });
        $scope.mostrarConsorcio = $rootScope.consorcio == 0;

        if($rootScope.consorcio != 0){
            socket.showNumberEvents();
        }
    });
    
    $scope.tipoUsuario = [    { id: 'P', descripcion: 'Propietario' }
                            , { id: 'I', descripcion: 'Inquilino'}
                            , { id: 'A', descripcion: 'Administrador'}
                         ];
    
    $scope.setPageInfo = function (newPage) {
        $scope.pageNumber = newPage;

        return true;
    };

    $scope.crearPropietario = function () {
        var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: 'nuevoPropietario.html',
            controller: 'modalPropietarioController',
            size: 'lg',//large
            resolve: {
                    items: function () {
                                      return $scope.mensaje;
                              }
            }
        });

        modalInstance.result.then(function () {//EL Modal se cerró!
                $location.path( "/usuario" );
        }, function () {
                $location.path( "/usuario" );
        });
    };
    
    $scope.VerUsuario = function(consorcio, _id){
    	//console.log(_id);
    	var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: 'detalleUsuario.html',
            controller: 'VerUsuarioController',
            size: 'lg',
            resolve: {
                usuario: function () {
                	for(var i = 0; i < $scope.listaUsuarios.length; i++)
                    {
                      if($scope.listaUsuarios[i].id == _id && $scope.listaUsuarios[i].consorcio.direccion == consorcio)
                      {
                        return angular.copy($scope.listaUsuarios[i]);
                      }
                    }
            	}
            }
        });

        modalInstance.result.then(function () {//EL Modal se cerró!
        	 usuarioFactory.obtenerUsuarios($rootScope.consorcio, function(usuarios){
    	        $scope.listaUsuarios = usuarios;
    	        $scope.row_collection = usuarios;
    	        usuarioFactory.mostrarLotes(usuarios, function(flag){
    	        	$scope.mostrarLotes = flag;
    	        });
    	    });
        	$location.path("/usuario/" + $rootScope.consorcio);
        });
    };
    
    $scope.printPropietarios = function print() {
    	
    	var $printSection = document.getElementById("printSection");

    	if (!$printSection) {
	        $printSection = document.createElement("div");
        	$printSection.id = "printSection";
        	document.body.appendChild($printSection);
    	}
    	else {    	
    		$printSection.innerHTML = "";
    	}
		
		var table_begin = '<table  class="table table-striped">';
		var table_header = '<thead>' +
										'<tr>' +
									   		'<th style="text-align: left; width: 20%;">Consorcio</th>' +
									   		'<th style="width: 5%;">Tipo</th>' +
									        '<th style="width: 15%;">Nombre y apellido</th>' +
									        '<th style="width: 5%;">Unidad</th>' +
									        '<th style="width: 10%;">Teléfono</th>' +
									        '<th style="width: 5%;">Celular</th>' +
									        '<th style="width: 15%;">Mail</th>' +
									        '<th style="width: 5%;" title="Estado...">Estado</th>' +
									    '</tr>' +
									'</thead>';
		
		var table_body = '<tbody class="nav nav-pills nav-stacked">';
		
		for(var i = 0; i < $scope.row_collection.length; i++){
			var piso = $scope.row_collection[i].piso;
			var telefono = $scope.row_collection[i].telefono.codigoPais + ' ' + $scope.row_collection[i].telefono.area + ' ' + $scope.row_collection[i].telefono.numero;
			var estado = $scope.row_collection[i].activo ? "A" : "I";
			var unidad = ($scope.row_collection[i].lote ? "Lote " + $scope.row_collection[i].lote : ((piso== ""  ? ' ' : (piso == 0 ? 'Local' : (piso == 1 ? 'PB' : (piso - 1)))) + ' ' + $scope.row_collection[i].depto));
			
			table_body +=
				
			"<tr>" +  
				"<td  style=\"width: 20%;\">" + ($scope.row_collection[i].consorcio.direccion != undefined ?  $scope.row_collection[i].consorcio.direccion : '-') + "</td>" +
				"<td  style=\"width: 5%;\">" + ($scope.row_collection[i].tipo == "Propietario" ? "P" : "I") + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].nombreApellido + "</td>" +
				"<td  style=\"width: 5%;\">" + unidad + "</td>" +
				"<td  style=\"width: 10%;\">" + (telefono != undefined ? telefono : '-') + "</td>" +
				"<td  style=\"width: 5%;\">" + ($scope.row_collection[i].celular != undefined ? $scope.row_collection[i].celular : '-') + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].mail + "</td>" +
				"<td  style=\"width: 5%;\">" + estado + "</td>" 
			"</tr>";
		}
		
		
		table_body += "</tbody></table>";
		
		$printSection.innerHTML = table_begin + table_header + table_body;
		window.print();	
		$printSection.remove();
    }
});

adm.controller('VerUsuarioController', function ($rootScope, $scope, $http, $window, $location, $modalInstance, $modal, auth, usuario, usuarioFactory) {
	$scope.usuario = usuario;
	$scope.mostrarLotes = usuario.piso == '' || usuario.piso == undefined;

    $scope.enviarMensaje = function () {
        auth.getCurrentUserId(function(idAdministrador){
            var participantes = [];
            participantes.push(idAdministrador);
            participantes.push($scope.usuario.id);

            $http.get('/app/verificarConversacion/' + participantes)
            .success(function (conversacion){
                if(conversacion.length == 0)
                {
                    var modalInstance = $modal.open({
                        animation: true,//fade
                        templateUrl: './views/nuevoMensaje.html',
                        controller: 'modalMensajeController',
                        size: 'lg',//large
                        resolve: {
                            destinatarios: function(){
                                return $scope.usuario;
                            },
                            mensaje: function () {
                                return null;
                            },
                            url: function(){
                                return $location.path();
                            }
                        }
                    });
                    modalInstance.result.then(function () {//EL Modal se cerró!
                        $location.path( "#/reclamo/" + $rootScope.consorcio );
                    });
                }
                else
                {
                    var modalInstance = $modal.open({
                    animation: true,//fade
                    templateUrl: './views/verConversacion.html',
                    controller: 'modalVerConversacionController',
                    size: 'lg',//large
                    resolve: {
                                participantes: function(){
                                    return participantes;
                                },
                                idConversacion: function(){
                                    return conversacion[0]._id;
                                },                                
                                destinatarios: function(){
                                    return $scope.usuario.nombreApellido;
                                },
                                url: function(){
                                    return $location.path();
                                }
                            }
                    });
                
                    modalInstance.result.then(function () {//EL Modal se cerró!
                        auth.getCurrentUserId(function(_id){
                            menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(datad){
                               $scope.listaConversaciones = datad;
                            });
                        });
                        $location.path( "#/usuario/" + $rootScope.consorcio );
                    });
                }
            });
        });
    };  

    $scope.eliminar = function(idUsuario, codigoConsorcio){
    	auth.getCurrentUserId(function(_id){
    		$http.post('/api/eliminarUsuarioById/' + idUsuario + '/' + codigoConsorcio + '/' + _id);
    	});
    	
    	usuarioFactory.obtenerUsuarios($rootScope.consorcio, function(usuarios){
            $scope.listaUsuarios = usuarios;
            usuarioFactory.mostrarLotes(usuarios, function(flag){
            	$scope.mostrarLotes = flag;
            });
        });
    	$modalInstance.close();
    }
    
    $scope.cambiarEstado = function(id){
		$http.get('/api/cambiarEstadoUsuario/' + id)
		.success(function(data){
			$scope.usuario.activo = data.activo;
	        $scope.mostrarConsorcio = $rootScope.consorcio == 0;
		});
    }
    
    $scope.cancel = function () {
    	usuarioFactory.obtenerUsuarios($rootScope.consorcio, function(usuarios){
            $scope.listaUsuarios = usuarios;
            usuarioFactory.mostrarLotes(usuarios, function(flag){
            	$scope.mostrarLotes = flag;
            });
        });
    	$modalInstance.close();
	}
});

adm.controller('modalPropietarioController', function ($scope, $http, $window, $location, $modalInstance) {
    //CrearPropietario llama a la API
    $scope.ok = function () {
        $http.post('/api/usuario', { usuario: $scope.usuario})
        .success(function(data) {
	        //Something...
	        $modalInstance.close();
	        $location.path( "/usuario" );
        })
        .error(function(data) {
            //console.log('Error:' + data);
        });
    };
    
    //END CrearPropietario
    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
      $location.path( "/usuario" );
    };
});

adm.filter('filterTelefono',function() {
    return function(listaUsuarios, telefono){
        var output = listaUsuarios;
        if(telefono != '' && telefono != undefined && listaUsuarios != undefined){
            output = $.grep(listaUsuarios, function(item, index){
                        return ((item.telefono != undefined) &&
                                (item.telefono.codigoPais.indexOf(telefono) != -1
                                || item.telefono.area.indexOf(telefono) != -1
                                || item.telefono.numero.toString().indexOf(telefono) != -1)); 
                        });
        }

        return output;
    }
});

adm.factory('usuarioFactory', function($http, auth){
    
    return{
        obtenerUsuarios: function(idConsorcio, listaUsuarios){
            if(idConsorcio == 0)
            {
                auth.getCurrentUserId(function(idAdministrador){
                    $http.get('/api/usuariosPropietariosByAdmin/' + idAdministrador)
                    .success(function(usuarios) {
                        listaUsuarios(usuarios);
                    })
                    .error(function(usuarios) {
                        //console.log('Error obteniendo consorcios:' + usuarios);
                    });
                });
            }
            else
            {
                $http.get('/api/usuariosPropietariosByConsorcioId/' + idConsorcio)
                .success(function(usuarios) {
                    listaUsuarios(usuarios);
                })
                .error(function(usuarios) {
                    //console.log('Error obteniendo consorcios:' + usuarios);
                });
            }
        },
        mostrarLotes: function(listaUsuarios, mostrarLotes){
        	var flag = ($.grep(listaUsuarios, function(item){
    			return item.piso == '' || item.piso == undefined;
	    	}).length > 0);
	    	mostrarLotes(flag);
        }
    }
});
