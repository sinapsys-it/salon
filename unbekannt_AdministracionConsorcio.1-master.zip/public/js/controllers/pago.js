adm.controller('pagoController', function ($rootScope, $interval, $scope, $modal, $location, usuarioFactory, $http, pagoFactory, auth, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }

	$scope.pageNumber = 1;
	$scope.setPageInfo = function (newPage) {
		$scope.pageNumber = newPage;
	};

    //Popover de ayuda
    var rutaImagenes = '../images/pagos/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Pagos" podemos visualizar los pagos reportados por los inquilinos/propietarios.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla de pago nos permite ver el detalle del pago reportado por el inquilino/propietario.\nEn el podemos ver el nombre del inquilino/propietario que reporto el pago, su consorcio, la unidad que corresponde, la fecha de cuando reportó, el importe, la forma de pago y las observaciones.\nTambién nos permite enviar un mensaje aal inquilino/propietario que reporto dicho pago.'
            }
        ]
    };

    //End Popover de ayuda
	 
    var intervalPromise = $interval(function(){
    	 pagoFactory.obtenerPagos(function(pagos){
    			$scope.listaPagos = pagos;
    			$scope.row_collection = pagos;
    			
    			usuarioFactory.mostrarLotes(pagos, function(flag){
    				$scope.mostrarLotes = flag;
    			});
    		});
		}, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
    pagoFactory.obtenerPagos(function(pagos){
		$scope.listaPagos = pagos;
		$scope.row_collection = pagos;
		
		usuarioFactory.mostrarLotes(pagos, function(flag){
			$scope.mostrarLotes = flag;
		});
	});
	
	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

	auth.getCurrentUserId(function(idAdministrador){
	   	//Períodos disponibles
	   	$scope.filtroAniosR = [];
	   	$scope.filtroAniosP = [];
	   	$scope.filtroMesesR = [];
	   	$scope.filtroMesesP = [];
	   	
	   	$http.get('/api/pagosFiltroAniosByAdmin/' + idAdministrador)
	   	.success(function(data){
	   		$scope.filtroAniosR = data;
	   	});
	   	$http.get('/api/pagosFiltroAniosPagosByAdmin/' + idAdministrador)
	   	.success(function(data){
	   		$scope.filtroAniosP = data;
	   	});
	   	
		for (var i = 0; i < 12; i++) {
			$scope.filtroMesesR[i] = i + 1;
		};
		for (var i = 0; i < 12; i++) {
			$scope.filtroMesesP[i] = i + 1;
		};
		//END Periodos disponibles
	});
	
	$scope.$on('seleccionarConsorcio', function() {   
    	pagoFactory.obtenerPagos(function(pagos){
    		$scope.listaPagos = pagos;
    		$scope.row_collection = pagos;
    	});
    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    	if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
	
	$scope.verPago = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: './views/detallePago.html',
	      controller: 'verPagoController',
	      size: 'lg',//large
	      resolve: {
		      	pago: function () {
		    	    for(var i = 0; i < $scope.listaPagos.length; i++){
		                 if($scope.listaPagos[i]._id == _id){
		                	 return angular.copy($scope.listaPagos[i]);
		                 }
    	  			}
      			}
      	  }
    	 });

		//EL Modal se cerró!
		modalInstance.result.then(function () {
			pagoFactory.obtenerPagos(function(pagos){
	    		$scope.listaPagos = pagos;
	    		$scope.row_collection = pagos;
	    	});
	    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;
	    	
			$location.path("/pago/" + $rootScope.consorcio);
		});
	};
	
	$scope.printPagos = function print() {
    	
    	var $printSection = document.getElementById("printSection");

    	if (!$printSection) {
	        $printSection = document.createElement("div");
        	$printSection.id = "printSection";
        	document.body.appendChild($printSection);
    	}
    	else {    	
    		$printSection.innerHTML = "";
    	}
		
		var table_begin = '<table  class="table table-striped">';
		var table_header = '<thead>' +
										'<tr>' +
									   		'<th style="text-align: left; width: 20%; font-size: 16px; vertical-align:top;">Consorcio</th>' +
											'<th style="width: 5%;font-size: 16px; vertical-align:top;">Unidad funcional</th>' +
									   		'<th style="width: 15%;font-size: 16px; vertical-align:top;">Remitente</th>' +
									        '<th style="width: 15%;font-size: 16px; vertical-align:top;">Fecha de pago</th>' +
									        '<th style="width: 5%;font-size: 16px; vertical-align:top;">Importe</th>' +
									        '<th style="width: 15%;font-size: 16px; vertical-align:top;">Forma de pago</th>' +
									        //'<th style="width: 5%;">Recibido el</th>' +
									    '</tr>' +
									'</thead>';
		
		var table_body = '<tbody class="nav nav-pills nav-stacked">';
		
		for(var i = 0; i < $scope.row_collection.length; i++){
			var fechaAlta = new Date($scope.row_collection[i].fechaAlta);
			var fechaPago = new Date($scope.row_collection[i].fechaPago);

			console.log($scope.row_collection[i].piso != undefined);

			table_body +=
			"<tr>" +  
				"<td  style=\"width: 20%;\">" + ($scope.row_collection[i].consorcio.direccion != undefined ?  $scope.row_collection[i].consorcio.direccion : '-') + "</td>";

			if( $scope.row_collection[i].piso != undefined)
			{
				var uf = $scope.row_collection[i].piso.numero == ""  ? ' ' : ($scope.row_collection[i].piso.numero == 0 ? 'Local' : ($scope.row_collection[i].piso.numero == 1 ? 'PB' : ($scope.row_collection[i].piso.numero - 1))) + " " + $scope.row_collection[i].piso.depto.nombre;
				table_body += "<td  style=\"width: 5%;\">" + uf + "</td>";
			}
			else
			{
				var uf = "Lote " + $scope.row_collection[i].lote.numero;
				table_body += "<td  style=\"width: 5%;\">" + uf + "</td>";
			}
				//"<td  style=\"width: 5%;\">" +  JSON.stringify($scope.row_collection[i]).indexOf("piso") > 0 ? $scope.row_collection[i].piso.numero == ""  ? ' ' : ($scope.row_collection[i].piso.numero == 0 ? 'Local' : ($scope.row_collection[i].piso.numero == 1 ? 'PB' : ($scope.row_collection[i].piso.numero - 1))) + " " + $scope.row_collection[i].piso.depto.nombre : "Lote " + $scope.row_collection[i].lote.numero + "</td>" +
				//"<td  style=\"width: 5%;\">" + "Lote " + row_collection[i].lote.numero + "</td>" +
			table_body +=
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].usuarioRemitente.nombreApellido + "</td>" +
				"<td  style=\"width: 15%;\">" + (fechaPago).getDate() + "/" + ((fechaPago).getMonth() + 1) + "/" + (fechaPago).getFullYear() + "</td>" +
				"<td  style=\"width: 5%;\">" + $scope.row_collection[i].importe + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].formaPago.nombre + "</td>" +
				//"<td  style=\"width: 5%;\">" + (fechaAlta).getDate() + "/" + ((fechaAlta).getMonth() + 1) + "/" + (fechaAlta).getFullYear() + "</td>" +
			"</tr>";
		}
		
		table_body += "</tbody></table>";
		
		$printSection.innerHTML = table_begin + table_header + table_body;
		window.print();	
		$printSection.remove();
    }
});

adm.controller('usersPagoController', function ($rootScope, $scope, $modal, $location, $http, usuarioFactory) {
	function obtenerPagos(){
		$http.get('/mapi/pagos/' + $rootScope.consorcioCodigo)
		.success(function(pagos){
			$scope.listaPagos = pagos;
			$scope.row_collection = pagos;
			
			usuarioFactory.mostrarLotes(pagos, function(flag){
				$scope.mostrarLotes = flag;
			});
		});
	}
	
	function obtenerFiltros(){
	   	$scope.filtroAniosP = [];
	   	$scope.filtroMesesP = [];
	   	
	   	$http.get('/api/pagosFiltroAniosPagosByAdmin/' + $rootScope.idAdministrador)
	   	.success(function(data){
	   		$scope.filtroAniosP = data;
	   	});
	   	
		for (var i = 0; i < 12; i++) {
			$scope.filtroMesesP[i] = i + 1;
		};
	}
	
	obtenerPagos();
	obtenerFiltros();
	
	$scope.newPago = function(){
		var modalInstance = $modal.open({
		      animation: true,//fade
		      templateUrl: './views/nuevoPago.html',
		      controller: 'nuevoPagoController',
		      size: 'lg',//large
    	 });

		modalInstance.result.then(function () {
			obtenerPagos();
			$location.path("/users/pago/" + $rootScope.consorcio);
		});
	}
	
	$scope.$on('seleccionarConsorcio', function() {   
		obtenerPagos();
		obtenerFiltros();
    });
	
	$scope.printPagos = function() {
    	
    	var $printSection = document.getElementById("printSection");

    	if (!$printSection) {
	        $printSection = document.createElement("div");
        	$printSection.id = "printSection";
        	document.body.appendChild($printSection);
    	}
    	else {    	
    		$printSection.innerHTML = "";
    	}
		
		var table_begin = '<table  class="table table-striped">';
		var table_header = '<thead>' +
										'<tr>' +
									        '<th style="width: 15%;">Fecha de pago</th>' +
									        '<th style="width: 5%;">Importe</th>' +
									        '<th style="width: 15%;">Forma de pago</th>' +
									        '<th style="width: 5%;">Enviado el</th>' +
									    '</tr>' +
									'</thead>';
		
		var table_body = '<tbody class="nav nav-pills nav-stacked">';
		
		for(var i = 0; i < $scope.row_collection.length; i++){
			var fechaAlta = new Date($scope.row_collection[i].fechaAlta);
			var fechaPago = new Date($scope.row_collection[i].fechaPago);

			table_body +=
			"<tr>" +  
				"<td  style=\"width: 15%;\">" + (fechaPago).getDate() + "/" + ((fechaPago).getMonth() + 1) + "/" + (fechaPago).getFullYear() + "</td>" +
				"<td  style=\"width: 5%;\">" + $scope.row_collection[i].importe + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].formaPago.nombre + "</td>" +
				"<td  style=\"width: 5%;\">" + (fechaAlta).getDate() + "/" + ((fechaAlta).getMonth() + 1) + "/" + (fechaAlta).getFullYear() + "</td>" +
			"</tr>";
		}
		
		table_body += "</tbody></table>";
		
		$printSection.innerHTML = table_begin + table_header + table_body;
		window.print();	
		$printSection.remove();
    }

	$scope.verPago = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: './views/detallePago.html',
	      controller: 'verPagoController',
	      size: 'lg',//large
	      resolve: {
		      	pago: function () {
		    	    for(var i = 0; i < $scope.row_collection.length; i++){
		                 if($scope.row_collection[i]._id == _id){
		                	 return angular.copy($scope.row_collection[i]);
		                 }
		  			}
	  			}
	  	  }
		 });
	
		//EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerPagos();
			obtenerFiltros();
			$location.path("/users/pago/" + $rootScope.consorcio);
		});
	};
});

adm.controller('nuevoPagoController', function($rootScope, $scope, $http, $modalInstance, $location){
	$scope.modalTitle = "Informar un Pago";
	$scope.pago = {
		usuarioRemitente: $rootScope.globals.currentUser.id,
		consorcio: $rootScope.consorcio,
		formaPago: '',
		piso: '',
		lote: '',
		codigos: $rootScope.consorcioCodigo,
		leido: false,
		importe: '',
		fechaPago: new Date(),
		observaciones: '',
		tieneImg: false,
		fechaAlta: new Date()
	}
	
	$http.get('/mapi/pagosForma/' + $rootScope.consorcio)
	.success(function(consorcio){
		$scope.formaPagoList = consorcio.formaspago;
	});
	
	if($rootScope.usuarioPisoSeleccionado){
		$scope.pago.piso = {
			numero: $rootScope.usuarioPisoSeleccionado.piso.numero,
			depto: {
				nombre: $rootScope.usuarioPisoSeleccionado != undefined ? $rootScope.usuarioPisoSeleccionado.piso.dpto.nombre : '',
			}
		}
	}
	else{
		$scope.pago.lote = {
			numero: $rootScope.usuarioLoteSeleccionado.lote.numero
		}
	}
	
	$http.get('/mapi/getConsorcio?codigoConsorcio=' + $rootScope.consorcioCodigo)
    .success(function(consorcio) {
        $scope.pago.consorcio = {_id: consorcio[0]._id, direccion: consorcio[0].direccion };
    });
	
	$scope.mostrandoPago = false;
	
    $scope.viendoImagen = false;
    $scope.cargando = true;
    $scope.modalTitle = "Nuevo Reclamo";
    
    $scope.saving = false;
	$scope.btnEnviar = "Enviar";
	
	$scope.imagenes = [];
	$scope.verImagenes = [];

	$scope.borrarArchivo = function(indice){
		$scope.imagenes.splice(indice,1);
		$scope.verImagenes.splice(indice,1);
	}

	$scope.fileNameChanged = function(ele){
		var tipoValidado = true;
		var tipoValidadoWord = true;

		if(ele.files.length + $scope.imagenes.length > 1)
		{
			alert("A superado la cantidad maxima de adjuntos.\nSólo puede adjuntar un archivo!")
		} 
		else
		{
			for (var i = 0; i < ele.files.length; i++)
	        {
	        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
	        	{
	        		if (ele.files[i].type.indexOf("word"))
	        		{
	        			tipoValidadoWord = false;
	        		}
	        		tipoValidado = false;
	        	}
	        }

			if (!tipoValidadoWord)
			{
				$scope.tutorial();
			}
			else if (tipoValidado)
			{

		        for (var i = 0; i < ele.files.length; i++)
		        {
		        	$scope.imagenes.push(ele.files[i]);
		        	var reader  = new FileReader();
		        	reader.addEventListener("load",function(event){
		                var picFile = event.target;
		                
		             	$scope.verImagenes.push({
		             								imagen: picFile.result,
		             								nombre: $scope.imagenes[$scope.verImagenes.length].name
		             							});
		             	$scope.$apply();
		            });
		        	reader.readAsDataURL(ele.files[i]);
		        	$scope.imagenesCargadas = true;
		        }
		    }
		    else
		    {
		    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
		    }
		}
    };
    
    $scope.ok = function () {
    	if($scope.formPago.$invalid)
		{
			$scope.submitted = true;
			$scope.saving = false;
			$scope.btnEnviar = "Enviar";
		}
		else{
			$scope.saving = true;
			$scope.btnEnviar = "Enviando...";

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				var fdimagenes = new FormData() 
				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}
				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {
		        	$scope.pago.usuarioRemitente = $rootScope.globals.currentUser.id;

		    		$scope.pago.adjuntoPago = idsImagenes;
		    		$scope.pago.tieneImg = true;
		    		$scope.pago.consorcio = $scope.pago.consorcio._id;
					
					$http.post('/mapi/pagoNuevo', $scope.pago);
					$modalInstance.close();
					$scope.subiendoImagenes = false;
				});
			}
			else
			{
	        	$scope.pago.usuarioRemitente = $rootScope.globals.currentUser.id;
				$scope.pago.consorcio = $scope.pago.consorcio._id;

				$http.post('/mapi/pagoNuevo', $scope.pago)
				.success(function(){
					$modalInstance.close();
					$location.path("/users/pago/" +  $scope.pago.consorcio._id);
				});
			}
    	}
	};
    
	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/users/pago/" +  $rootScope.consorcio);
	};	
});

adm.controller('verPagoController', function ($rootScope, $scope, $modalInstance, $modal, $location, $http, pago, auth, socket, pagoFactory) {
	$scope.pago = pago;
	$scope.verImagenes = [];
    $scope.myInterval = 4000;//intervalo para la galería

	if ($scope.pago.adjuntoPago != undefined)
	{
		$scope.imagenesCargadas = false;

		for (var i = 0; i < $scope.pago.adjuntoPago.length; i++) 
		{
			$http.get('/api/obtenerArchivoById/' + $scope.pago.adjuntoPago[i])
			.success(function(imagen){
				$scope.verImagenes.push(imagen);
				if($scope.verImagenes.length == $scope.pago.adjuntoPago.length)
				{
					$scope.imagenesCargadas = true;
				}
			})
		}
	}

	$http.post('/api/markRead', {pagoId: $scope.pago._id, leido: true}).success(function(data){
		socket.updateEventByConsorcio($rootScope.consorcio, 0, 0, 1);
	});

	$scope.verImagen = function(){ 
        $scope.viendoImagen = true;
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
    }

	$scope.enviarMensaje = function () {

		auth.getCurrentUserId(function(idAdministrador){
			var participantes = [];
			participantes.push(idAdministrador);
			participantes.push($scope.pago.usuarioRemitente._id);

			$http.get('/app/verificarConversacion/' + participantes)
			.success(function (conversacion){

				if(conversacion.length == 0)
				{
			        var modalInstance = $modal.open({
			            animation: true,//fade
			            templateUrl: 'nuevoMensaje.html',
			            controller: 'modalMensajeController',
			            size: 'lg',//large
			            resolve: {
		            	 	mensaje: function () {
			                    return null;
			                },
			                destinatarios: function(){
			                    return $scope.pago.usuarioRemitente;
			                },
			                url: function(){
			                	return $location.path();
			                }
			            }
			        });
			        modalInstance.result.then(function () {//EL Modal se cerró!
			            $location.path( "/pago/" + $rootScope.consorcio );
			        });
			    }
			    else
			    {
			        var modalInstance = $modal.open({
			        animation: true,//fade
			        templateUrl: './views/verConversacion.html',
			        controller: 'modalVerConversacionController',
			        size: 'lg',//large
			        resolve: {
			                    destinatarios: function(){
			                        return $scope.pago.usuarioRemitente.nombreApellido;
			                    },
			                    participantes: function(){
			                        return participantes;
			                    },
			                    idConversacion: function(){
			                        return conversacion[0]._id;
			                    },
		                     	url: function(){
			                		return $location.path();
			                	}
			                }
			        });
			    
			        modalInstance.result.then(function () {//EL Modal se cerró!
			            auth.getCurrentUserId(function(_id){
			                menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(datad){
			                   $scope.listaConversaciones = datad;
			                });
			            });
			            $location.path( "/pago/" + $rootScope.consorcio );
			        });
				}
			});
		});
	};	

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		pagoFactory.obtenerPagos(function(pagos){
    		$scope.listaPagos = pagos;
    		$scope.row_collection = pagos;
    	});

		$location.path( "/pago/" + $rootScope.consorcio);
	};	
});

adm.factory('pagoFactory', function($http, $rootScope, auth){
	return {
		obtenerPagos: function(cb){
			var uri = '';
			if($rootScope.consorcio != 0){
				uri = '/api/pagosByConsorcioId/' + $rootScope.consorcio;
			}
			else{
				auth.getCurrentUserId(function(idAdministrador){
					uri = '/api/pagosByAdmin/' + idAdministrador;
				});
			}
			
			$http.get(uri)
		    .success(function(data) {
		    	cb(data);
		    })
		    .error(function(data) {
		    	//console.log('Error obteniendo consorcios:' + data);
		    	cb([]);
		    });
		}
	}
});

adm.filter('mesesPagoP', function(){
	return function(listaPagos, meses){
		var output = listaPagos;
		if(meses != '' && meses != undefined && listaPagos != undefined){
			output = $.grep(listaPagos, function(item, index){
				//console.log(item);
				return ((item.fechaPago != undefined) &&
						($.grep(meses, function(mes){
							return mes == (new Date(item.fechaPago).getMonth() + 1);
						})).length > 0);
			});
		}
		
		return output;
	}
});

adm.filter('mesesPagoR', function(){
	return function(listaPagos, meses){
		var output = listaPagos;
		if(meses != '' && meses != undefined && listaPagos != undefined){
			output = $.grep(listaPagos, function(item, index){
				//console.log(item);
				return ((item.fechaAlta != undefined) &&
						($.grep(meses, function(mes){
							return mes == (new Date(item.fechaAlta).getMonth() + 1);
						})).length > 0);
			});
		}
		
		return output;
	}
});

adm.filter('aniosPagoP', function(){
	return function(listaPagos, anios){
		var output = listaPagos;
		if(anios != '' && anios != undefined && listaPagos != undefined){
            output = $.grep(listaPagos, function(item, index){
                        return ((item.fechaPago != undefined) &&
                                ($.grep(anios, function(anio){
                                	return anio == (new Date(item.fechaPago).getFullYear());
                                })).length > 0);
                        });
        }

        return output;
	}
});

adm.filter('aniosPagoR', function(){
	return function(listaPagos, anios){
		var output = listaPagos;
		if(anios != '' && anios != undefined && listaPagos != undefined){
            output = $.grep(listaPagos, function(item, index){
                        return ((item.fechaAlta != undefined) &&
                                ($.grep(anios, function(anio){
                                	return anio == (new Date(item.fechaAlta).getFullYear());
                                })).length > 0);
                        });
        }

        return output;
	}
});
