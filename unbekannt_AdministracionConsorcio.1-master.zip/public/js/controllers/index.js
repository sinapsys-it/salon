adm.controller('indexController', function ($window, $rootScope, $scope, $http, $location, $modal, $route, auth, menssageFactory) {
	$scope.selected = '';
	
	$rootScope.$watch('globals', function() {
		if($rootScope.globals.currentUser && $rootScope.globals.currentUser.isAdmin){
			$rootScope.urlExpensa = 'expensa';
			$rootScope.urlTelefono = 'telefono'
			$rootScope.urlNovedad  = 'novedad';
			$rootScope.urlUsuario = 'usuario';
			$rootScope.urlMensaje = 'mensaje';
			$rootScope.urlReclamo = 'reclamo';
			$rootScope.urlVotacion = 'votacion';
			$rootScope.urlPago = 'pago';
			$rootScope.urlGeneralidad = 'generalidad'; 
		}
		else{
			$rootScope.urlExpensa = 'users/expensa';
			$rootScope.urlTelefono = 'users/telefono'
			$rootScope.urlNovedad  = 'users/novedad';
			$rootScope.urlUsuario = 'users/usuario';
			$rootScope.urlMensaje = 'users/mensaje';
			$rootScope.urlReclamo = 'users/reclamo';
			$rootScope.urlVotacion = 'users/votacion';
			$rootScope.urlPago = 'users/pago';
			$rootScope.urlGeneralidad = 'users/generalidad'; 
		}
    });
	
    $scope.$on('seleccionarConsorcio', function() {   
        $scope.consorcioSeleccionado = $rootScope.consorcio;
    });
    
    $scope.nuevoContacto = function(){
    	var modalInstance = $modal.open({
			animation: true,//fade
			templateUrl: 'contacto.html',
			controller: 'contactoController',
			size: 'lg',//large
			resolve: {
				consorcio: function () {
					return null;
		  		}
			}
	    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			ObtenerConsorcios();
			$location.path( "/mensaje/" + $rootScope.consorcio );
		});
    }
    
    $scope.configuracion = function(){
    	var modalInstance = $modal.open({
			animation: true,//fade
            backdrop: 'static',
			templateUrl: 'configuracion.html',
			controller: 'configuracionController',
			size: 'lg',//large
			resolve: {
				consorcio: function () {
					return null;
		  		}
			}
    	});
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
            $route.reload();
		});
    }

    //la función logout que llamamos en la vista llama a la función
    //logout de la factoria auth
    $scope.logout = function()
    {
        auth.logout();
    }
});




adm.controller('tutorialWordToPdfController', function ($window, $rootScope, $scope, $http, $modalInstance, $location, $modal, auth, menssageFactory) {
    $scope.slides = [
        {
            imagen: "../images/tutorial_1.png",
            nombre: "Los documentos de tipo Word no son soportados por la aplicación. Como alternativa puede convertir su archivo a PDF para poder adjuntarlo."
        },
        {
            imagen: "../images/tutorial_2.png",
            nombre: "Para ello dirijase al menu Archivo. Luego a la opcion Exportar."
        },
        {
            imagen: "../images/tutorial_3.png",
            nombre: "Seleccione la opción Crear documento PDF/XPS."
        },
        {
            imagen: "../images/tutorial_4.png",
            nombre: "Por último seleccione la ubicacion del nuevo archivo. Para completar la operación haga click en Publicar."
        }
    ]
    $scope.cancel = function () {
    	$modalInstance.dismiss('cancel');
    };
});

adm.filter('range', function() {
    return function(val, range) {
    range = parseInt(range);
    for (var i=1; i<=range; i++)
        val.push(i);
    return val;
    };
});

adm.service('uploadFileService', ['$http', function ($http) {
	this.uploadFileToUrl = function(formData, url){
        var fd = formData;
        
        $http.post(url, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function(data){
        	//console.log("MESSAGE_SAVED=TRUE");
        })
        .error(function(data){
        	//console.log(data);
        });
	};
}]);

adm.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);


