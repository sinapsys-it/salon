adm.controller('configuracionController', function ($rootScope, $window, $scope, $timeout, $modal, $location, $http, $modalInstance, auth) {
	var idAdmin = '';
	$scope.modalTitle = "Administración";
	$scope.configuracion = {
			especialidad: '',
			formaPago: ''
	}

	auth.getCurrentUserId(function(_id){
		idAdmin = _id;
	});
	
	function obtenerFormasPago(){
		$http.get('/api/formaspagos/' + idAdmin)
		.success(function(formasPago){
			$scope.row_collection_fp = formasPago;
			$scope.listaFormasPago = formasPago;
		});
	}
	
	function obtenerEspecialidades(){
		$http.get('/api/especialidades/' + idAdmin)
		.success(function(especialidades){
			$scope.row_collection_e = especialidades;
			$scope.listaEspecialidades = especialidades;
		});
	}
	
	obtenerFormasPago();
	obtenerEspecialidades();
	
	$scope.saveEspecialidad = function(nombre){
		$http.post('/api/especialidades/' + nombre + '/' + idAdmin)
		.success(function(res){
			$scope.configuracion.especialidad = '';
			obtenerEspecialidades();
		});
	}
	
	$scope.eliminarEspecialidad = function(idEspecialidad){
		$http.get('/api/telefonosByEspecialidad/' + idEspecialidad)
		.success(function(telefonos){
			if(telefonos.length > 0){
				$scope.errorEliminarEspecialidad = true;
				$timeout(function() {
					$scope.errorEliminarEspecialidad = false;
				}, 3000)
			}
			else{
				$http.post('/api/especialidades/' + idEspecialidad)
				.success(function(telefonos){
					obtenerEspecialidades();
				});
			}
		});
	}

	$scope.saveFormaPago = function(nombre){
		$http.post('/api/formaspago/' + nombre + '/' + idAdmin)
		.success(function(res){
			$scope.configuracion.formaPago = '';
			obtenerFormasPago();
		});
	}
	
	$scope.eliminarFormaPago = function(idFormaPago){
		$http.get('/api/consorcioByFormaPago/' + idFormaPago)
		.success(function(consorcios){
			if(consorcios.length > 0){
				$scope.errorEliminarFormaPago = true;
				$timeout(function() {
					$scope.errorEliminarFormaPago = false;
				}, 3000)
			}
			else{
				$http.post('/api/formaspago/' + idFormaPago)
				.success(function(){
					obtenerFormasPago();
				});
			}
		});
	}
	
	$scope.cerrar = function(){
		$modalInstance.close();
	}
});