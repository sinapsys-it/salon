adm.controller('expensaController', function ($rootScope, $scope, $modal, $interval, $location, $http, $window, $routeParams, auth, expensaFactory, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }
     $scope.pageNumber = 1;
	$scope.mostrarConsorcio = $rootScope.consorcio == $routeParams.id;
   	$scope.coleccionExpensas = [];
   	$scope.filtroConsorcios = [];
   	
   	expensaFactory.obtenerExpensas($rootScope.consorcio, function(expensas){
		$scope.coleccionExpensas = expensas;
		$scope.row_collection = expensas;
	});

    //Popover de ayuda
    var rutaImagenes = '../images/expensas/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Expensas" permite mostrar la lista de expensas publicadas por el administrador.\nDesde el botón "Crear expensa" accedemos a la pantalla de creación.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla "Nueva expensa" nos permite crear publicaciones de expensas para un consorcio determinado.\nEn esta podemos asignar el periodo de la expensa, el consorcio destinatario, adjuntar la liquidacion en archivos y adjuntar imagenes extras a la expensa.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla de expensas nos permite realizar un seguimiento de la expensa publicada.\nPodemos visualizar el periodo de la expensa, el consorcio destinatario, los documentos de liquidación y las imagenes adjuntas.'
            }
        ]
    };

    //End Popover de ayuda

	$scope.setPageInfo = function (newPage) {
		$scope.pageNumber = newPage;
	};
   	
    var intervalPromise = $interval(function(){
    	expensaFactory.obtenerExpensas($rootScope.consorcio, function(expensas){
    		$scope.coleccionExpensas = expensas;
    		$scope.row_collection = expensas;
    	});
	}, 30000);
   	
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
   	function loadFilters(){
		auth.getCurrentUserId(function(idAdministrador){
			$http.get('/api/ddlConsorciosByAdmin/' + idAdministrador)
			.success(function(data){
				for (var i = 0; i < data.length; i++) {
					$scope.filtroConsorcios.push(data[i].direccion);
				};
			});
	
		   	//Períodos disponibles
		   	$scope.filtroAnios = [];
		   	$scope.filtroMeses = [];
		   	$http.get('/api/expensaFiltroAniosByAdmin/' + idAdministrador)
		   	.success(function(data){
		   		$scope.filtroAnios = data;
		   	});
			for (var i = 0; i < 12; i++) {
				$scope.filtroMeses[i] = i + 1;
			};
			//END Periodos disponibles
		});
   	}
   	
   	loadFilters();
    
    $scope.$on('seleccionarConsorcio', function() {   
    	expensaFactory.obtenerExpensas($rootScope.consorcio, function(expensas){
			$scope.coleccionExpensas = expensas;
		});
    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    	if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
    
    //ModalInstance - Muestra modal para crear expensa
    $scope.crearExpensa = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: 'nuevaExpensa.html',
						      controller: 'modalExpensaController',
						      size: 'lg',//medium
						      resolve: {
							      items: function () {
							    	  		return $scope.expensa;
							      		}
						      }
						    });
	    
	    //EL Modal se cerr�!
		modalInstance.result.then(function () {
			expensaFactory.obtenerExpensas($rootScope.consorcio, function(expensas){
				$scope.coleccionExpensas = expensas;
				loadFilters();
			});
			$location.path("/expensa/" + $rootScope.consorcio);
		});
	};
	//END ModalInstance

    //ModalInstance - Muestra modal para crear consorcio
    $scope.verExpensa = function (_id) {
	    var modalInstance = $modal.open({
                                    animation: true,//fade
                                    templateUrl: 'nuevaExpensa.html',
                                    controller: 'modalVerExpensaController',
                                    size: 'lg',//medium
                                    resolve: {
                                        expensa: function() {
                                        	return _id;
                                        }
                                    }
                                });
	    
	    //EL Modal se cerr�!
		modalInstance.result.then(function () {
			expensaFactory.obtenerExpensas($rootScope.consorcio, function(expensas){
				$scope.coleccionExpensas = expensas;
			});
			$location.path("/expensa/" + $rootScope.consorcio);
		});
	};
	//END ModalInstance
});

adm.controller('usersExpensaController', function ($rootScope, $scope, $modal, $http, $location) {
	function obtenerExpensas(){
		$http.get('/mapi/expensas/' + $rootScope.consorcio + '/' + $rootScope.globals.currentUser.id)
		.success(function(expensas){
			$scope.coleccionExpensas = expensas;
			$scope.row_collection = expensas;
		});
	}
	
	function loadFilters(){
	   	//Períodos disponibles
	   	$scope.filtroAnios = [];
	   	$scope.filtroMeses = [];
	   	$http.get('/api/expensaFiltroAniosByAdmin/' + $rootScope.idAdministrador)
	   	.success(function(data){
	   		$scope.filtroAnios = data;
	   	});
		for (var i = 0; i < 12; i++) {
			$scope.filtroMeses[i] = i + 1;
		};
		//END Periodos disponibles
   	}
	
	obtenerExpensas();
	loadFilters();
	
	$scope.$on('seleccionarConsorcio', function() {   
		obtenerExpensas();
		loadFilters();
    });
	
	//ModalInstance - Muestra modal para crear consorcio
    $scope.verExpensa = function (_id) {
	    var modalInstance = $modal.open({
            animation: true,//fade
            templateUrl: 'nuevaExpensa.html',
            controller: 'modalVerExpensaController',
            size: 'lg',//medium
            resolve: {
                expensa: function() {
                	return _id;
                }
            }
        });
	    
	    //EL Modal se cerr�!
		modalInstance.result.then(function () {
			obtenerExpensas();
			$location.path("/users/expensa/" + $rootScope.consorcio);
		});
	};
});

//Controlador para modalInstance
adm.controller('modalExpensaController', function ($rootScope, $scope, $modal, $cookies, $http, $location, $modalInstance, uploadFileService, auth, expensaFactory) {
	$scope.verGaleriaLiquidacion = false;
	$scope.verGaleriaAdjuntos = false;
	$scope.imagenesCargadas = false;
	$scope.liquidacionCargada = false;
    $scope.modalTitle = "Nueva expensa";
	$scope.mostrandoExpensa = false;
	$scope.subiendoImagenes = false;
	$scope.enviandoMails = false;
	$scope.expensa = {imagenesExpensa: []};
	$scope.imagenes = [];
	$scope.liquidaciones = [];
	$scope.verImagenes = [];
	$scope.verLiquidaciones = [];
	auth.getCurrentUserId(function (idAdministrador){
		$scope.idAdministrador = idAdministrador;
	});
	
	$scope.saving = false;
	$scope.btnGuardarCambios = "Guardar cambios";
	$scope.btnEnviar = "Enviar";
	
	//Periodos disponibles
	//Año actual menos 1
	//Todos los meses
	$scope.anios = new Array();
	$scope.meses = new Array();
	var date = new Date();
	for (var i = 0; i < 6; i++) {
		$scope.anios[i] = date.getFullYear() + i - 1;
	};
	for (var i = 0; i < 12; i++) {
		$scope.meses[i] = i + 1;
	};
	//END Periodos disponibles

	$scope.tutorial = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: 'tutorialWordToPdf.html',
						      controller: 'tutorialWordToPdfController',
						      size: 'lg'//large
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			novedadFactory.obtenerNovedades($rootScope.consorcio, function(novedades){
	    		$scope.coleccionNovedades = novedades;
	    		$scope.row_collection = novedades;
	    	});
			$location.path("/expensa/" + $rootScope.consorcio);
		});
	};
	
	//Obtiene los consorcios existentes
    $scope.ObtenerConsorcios = 	function(query){
								   	return $http.get('/api/ddlConsorciosByQueryAndAdmin/' + query + "/" + $scope.idAdministrador);
								};
   	$scope.consorcios = [];
   	
	if($rootScope.consorcio != 0)
	{
		$http.get('/api/consorcios/' + $rootScope.consorcio)
	    .success(function(consorcio) {
	        $scope.consorcios.push({_id: consorcio._id, direccion: consorcio.direccion });
	    });
    }
    //END obtenerConsorcios
    $scope.borrarArchivo = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				$scope.imagenes.splice(i,1);
				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('input').value = "";
	}

    $scope.fileNameChanged = function(ele){

		var lista = [];
		var tipoValidado = true;
		var tipoValidadoWord = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		if (ele.files[i].type.indexOf("word"))
        		{
        			tipoValidadoWord = false;
        		}
        		tipoValidado = false;
        	}
        }

		if (!tipoValidadoWord)
		{
			$scope.tutorial();
		}
		else if (tipoValidado)
		{
			for (var i = 0; i < ele.files.length; i++)
	        {

	        	$scope.imagenes.push(ele.files[i]);

	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	                var picFile = event.target;
	                
	             	$scope.verImagenes.push({
	             								imagen: picFile.result,
	             								nombre: $scope.imagenes[$scope.verImagenes.length].name
	             							});
	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);
							
	        	$scope.imagenesCargadas = true;
	        }
	    }
	    else
	    {
	    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };

    $scope.borrarArchivoLiquidacion = function(lista){
    	var remainingFiles = []
    	for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				$scope.liquidaciones.splice(i,1);
				$scope.verLiquidaciones.splice(i,1);
			}
		};
		document.getElementById('inputLiquidacion').value = "";
	}

    $scope.fileNameChangedLiquidacion = function(ele){
		var lista = [];
		var tipoValidado = true;
		var tipoValidadoWord = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		if (ele.files[i].type.indexOf("word"))
        		{
        			tipoValidadoWord = false;
        		}
        		tipoValidado = false;
        	}
        }

		if (!tipoValidadoWord)
		{
			$scope.tutorial();
		}
		else if (tipoValidado)
		{

	        for (var i = 0; i < ele.files.length; i++)
	        {

				$scope.liquidaciones.push(ele.files[i]);

	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	                var picFile = event.target;
	                lista.push(picFile.result);      
	             	$scope.verLiquidaciones.push({
	             								imagen: picFile.result,
	             								nombre: $scope.liquidaciones[$scope.verLiquidaciones.length].name
	             							});
	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);

	        	$scope.liquidacionCargada = true;
							
	        }
        }
	    else
	    {
	    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };

    $scope.galeriaLiquidacion = function(){
    	$scope.verGaleriaLiquidacion = true;
    };

    $scope.galeriaAdjuntos = function(){
    	$scope.verGaleriaAdjuntos = true;
    };

    $scope.volver = function(){
    	$scope.verGaleriaAdjuntos = false;
    	$scope.verGaleriaLiquidacion = false;
    };

	$scope.ok = function () {
		var expensaExistente;
		$scope.listaUsuarios = new Array();
		if (!angular.isUndefined($scope.consorcios[0]))
		{
			$scope.expensa.consorcio = $scope.consorcios[0]._id;
		}

		if($scope.formNuevaExpensa.$invalid || $scope.liquidacionCargada == false)
		{
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnGuardarCambios = "Guardar cambios";
			$scope.btnEnviar = "Enviar";
		}
		else
		{
			$scope.saving = true;
			$scope.btnGuardarCambios = "Guardando cambios...";
			$scope.btnEnviar = "Enviando...";
			
			$http({
			    method: "GET",
			    url: "/api/expensaByExpensa",
			    params: {
			        anio : $scope.expensa.periodo.anio,
			        mes : $scope.expensa.periodo.mes,
			        consorcio : $scope.expensa.consorcio
			    }
			})
			.success(function(data) {
			expensaExistente = data;	
				if (expensaExistente == "") 
				{
					$scope.subiendoImagenes = true;

					var fd = new FormData() 

					for (var i = 0; i < $scope.liquidaciones.length; i++) {
						fd.append("archivo" + i, $scope.liquidaciones[i]);
					}

					$http.post('/api/crearArchivos',fd,{
			            transformRequest: angular.identity,
			            headers: {'Content-Type': undefined}
			        })
					.success(function (idsLiquidacion) {
						$scope.expensa.liquidacion = idsLiquidacion;

						if ($scope.imagenes.length != 0)
						{
							var fdimagenes = new FormData() 

							for (var i = 0; i < $scope.imagenes.length; i++) {
								fdimagenes.append("archivo" + i, $scope.imagenes[i]);
							}

							$http.post('/api/crearArchivos',fdimagenes,{
					            transformRequest: angular.identity,
					            headers: {'Content-Type': undefined}
					        })
							.success(function (idsImagenes) {
								$scope.expensa.adjuntosExpensa = idsImagenes;
								expensaFactory.crearExpensa($scope, $modalInstance);
							});
						}
						else
						{
							expensaFactory.crearExpensa($scope, $modalInstance);
						}
						
					})
			        .error(function(data) {
					    //console.log('Error:' + data);
					    $location.path( "/error" );
					});
				}
				else
				{
					alert("La expensa que intenta ingresar ya existe.\nPor favor, intente nuevamente.");
				}	
			})
			.error(function(data) {
	            //console.log('Error obteniendo expensa:' + JSON.stringify($scope.expensa));
	        });
	    }
	};
	//END CrearConsorcio
	
	$scope.cancel = function () {
	  $modalInstance.dismiss('cancel');
	  $location.path("/expensa/" + $rootScope.consorcio);
	};
});

adm.controller('modalVerExpensaController', function ($rootScope, $scope, $cookies, $window, $http, $location, uploadFileService, $modalInstance, expensa) {
	
	$scope.imagenes = [];

	$scope.subiendoImagenes = false;

	$scope.verGaleriaLiquidacion = false;
	$scope.verGaleriaAdjuntos = false;

    $scope.modalTitle = "Edicion de expensa";

	$scope.mostrandoExpensa = true;

	$scope.liquidacionCargada = false;

	$scope.imagenesCargadas = false;

	$scope.verLiquidaciones = [];

	$scope.verImagenes = [];
	$scope.verImagenes2 = [];

	$scope.imagenesEliminadas = [];

	$scope.saving = false;
	$scope.btnGuardarCambios = "Guardar cambios";
	$scope.btnEnviar = "Enviar";
	
   	$scope.consorcios = [];
	//Periodos disponibles
	//Año actual menos 1
	//Todos los meses
	$scope.anios = new Array();
	$scope.meses = new Array();
	var date = new Date();
	for (var i = 0; i < 6; i++) {
		$scope.anios[i] = date.getFullYear() + i - 1;
	};
	for (var i = 0; i < 12; i++) {
		$scope.meses[i] = i + 1;
	};
	//END Periodos disponibles

	//Obtiene los consorcios existentes
    $http.get('/api/expensas/' + expensa)
    .success(function (data){

    	$scope.expensa = data;
    	$scope.expensa.periodo.anio = data.periodo.anio.toString();
    	$scope.expensa.periodo.mes = data.periodo.mes.toString();
    	$scope.expensa.adjuntosExpensa = data.adjuntosExpensa;
    	$scope.expensa.liquidacion = data.liquidacion;
    	$scope.consorcios.push(
    		{
    			_id: data.consorcio._id,
    			direccion: data.consorcio.direccion
    		}
    	);
		for (var i = 0; i < $scope.expensa.liquidacion.length; i++)
		{
	    	$http.get('/api/obtenerArchivoById/' + $scope.expensa.liquidacion[i])
			.success(function(liquidacion){
				$scope.verLiquidaciones.push(liquidacion);
				if($scope.verLiquidaciones.length == $scope.expensa.liquidacion.length)
				{
					$scope.liquidacionCargada = true;
				}
			})
		}
		if ($scope.expensa.adjuntosExpensa.length > 0)
		{
			for (var i = 0; i < $scope.expensa.adjuntosExpensa.length; i++)
			{
				$http.get('/api/obtenerArchivoById/' + $scope.expensa.adjuntosExpensa[i])
				.success(function(imagen){
					$scope.verImagenes.push(imagen);
					if($scope.verImagenes.length == $scope.expensa.adjuntosExpensa.length)
					{
						$scope.imagenesCargadas = true;
					}
				})
			};
		}
    });
    
    
    //END obtenerConsorcios

    //Seteo galeria de imagenes
    $scope.myInterval = 4000;

	//Fin del seteo de la galeria de imagenes

	$scope.borrarArchivo = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				if(lista[i].order)
				{
					$scope.imagenes.splice(lista[i].order,1);
					$scope.verImagenes2.splice(lista[i].order);
				}
				else if (lista[i].id)
				{
					$scope.imagenesEliminadas.push(lista[i].id);
				}

				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('input').value = "";
	}

    $scope.fileNameChanged = function(ele){

		var lista = [];
		var tipoValidado = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		tipoValidado = false;
        	}
        }
		
		if (tipoValidado)
		{
			for (var i = 0; i < ele.files.length; i++)
	        {

	        	$scope.imagenes.push(ele.files[i]);

	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	        		
	                var picFile = event.target;

	             	$scope.verImagenes2.push({
	             								order: $scope.verImagenes2.length,
	             								imagen: picFile.result,
	             								nombre: $scope.imagenes[$scope.verImagenes2.length].name
	             							});

	        		$scope.verImagenes.push($scope.verImagenes2[$scope.verImagenes2.length-1]);

	        		$scope.imagenes[$scope.verImagenes2.length-1].order = $scope.verImagenes2[$scope.verImagenes2.length-1].order;

	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);
	        }

	        $scope.imagenesCargadas = true;
	    }
	    else
	    {
	    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };

	$scope.galeriaLiquidacion = function(){
    	$scope.verGaleriaLiquidacion = true;
    };

    $scope.galeriaAdjuntos = function(){
    	$scope.verGaleriaAdjuntos = true;
    };

    $scope.volver = function(){
    	$scope.verGaleriaAdjuntos = false;
    	$scope.verGaleriaLiquidacion = false;
    };

	$scope.ok = function () {

		$scope.expensa.adjuntosExpensa = [];

		for (var i = 0; i < $scope.imagenesEliminadas.length; i++) {

			$http.post('api/eliminarArchivo',{id: $scope.imagenesEliminadas[i]})
			.success(function(data){

			})
			.error(function(data) {
			    //console.log('Error:' + data);
			    $location.path( "/error" );
			    $scope.subiendoImagenes = false;
			});
		}

		if ($scope.imagenes.length != 0)
		{
			$scope.subiendoImagenes = true;

			var fdimagenes = new FormData() 

			for (var i = 0; i < $scope.imagenes.length; i++) {
				fdimagenes.append("archivo" + i, $scope.imagenes[i]);
			}

			$http.post('/api/crearArchivos',fdimagenes,{
	            transformRequest: angular.identity,
	            headers: {'Content-Type': undefined}
	        })
			.success(function (idsImagenes) {

				for (var i = 0; i < idsImagenes.length; i++)
				{
					$scope.expensa.adjuntosExpensa.push(idsImagenes[i]);
				}

				for (var i = 0; i < $scope.verImagenes.length; i++) {
					if ($scope.verImagenes[i].id)
					{
						$scope.expensa.adjuntosExpensa.push($scope.verImagenes[i].id);
					}
				}

				$http.put('/api/updateAdjuntosExpensas/' + $scope.expensa._id, { expensa: $scope.expensa })
				.success(function(data) {
					//Something...
					$modalInstance.close();
					$location.path("/expensa/" + $rootScope.consorcio);
					$scope.subiendoImagenes = false;
				})
				.error(function(data) {
				    //console.log('Error:' + data);
				    $location.path( "/error" );
				    $scope.subiendoImagenes = false;
				});
			});
		}
		else
		{
			for (var i = 0; i < $scope.verImagenes.length; i++) {
				if ($scope.verImagenes[i].id)
				{
					$scope.expensa.adjuntosExpensa.push($scope.verImagenes[i].id);
				}
			}

			$http.put('/api/updateAdjuntosExpensas/' + $scope.expensa._id, { expensa: $scope.expensa })
			.success(function(data) {
				//Something...
				$modalInstance.close();
				$location.path("/expensa/" + $rootScope.consorcio);
				$scope.subiendoImagenes = false;
			})
			.error(function(data) {
			    //console.log('Error:' + data);
			    $location.path( "/error" );
			    $scope.subiendoImagenes = false;
			});
		}
	};
	//END CrearConsorcio
	
	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
	};
});

adm.factory('expensaFactory', function($rootScope, $location, $http, auth){
   	
	return{
		obtenerExpensas: function(idConsorcio, coleccionExpensas){
	        if(idConsorcio == 0)
	        {
	        	auth.getCurrentUserId(function(idAdministrador){
		            $http.get('/api/expensasByAdmin/' + idAdministrador)
		            .success(function(expensas) {
		                coleccionExpensas(expensas);
		            })
		            .error(function(expensas) {
		                //console.log('Error obteniendo las novedades! ' + expensas);
		            });
	        	});
	        }
	        else
	        {
	            $http.get('/api/expensaByConsorcioId/' + idConsorcio)
	            .success(function(expensas) {
	                coleccionExpensas(expensas);
	            })
	            .error(function(expensas) {
	                //console.log('Error obteniendo las novedades! ' + expensas);
	            });
	        }
	   	},
	   	crearExpensa: function($scope, $modalInstance){
	   		var listaMail = new Array();
	   		$http.post('/api/expensas',{ expensa: $scope.expensa})
			.success(function (expensa){
				$scope.idExpensa = expensa._id;
				$scope.subiendoImagenes = false;
				$scope.enviandoMails = true;
				
				//Obtiene los usuarios para el id de consorcio específico para extraer sus direcciones de email
	            $http.get('/api/usuarioByConsorcioId/' + $scope.expensa.consorcio)
	            .success(function(data) {
	                $scope.listaUsuarios = data;
	                if (!angular.isUndefined(data[0]))
	                {
		                for (var i = 0; i < $scope.listaUsuarios.length; i++) {
			           		listaMail.push($scope.listaUsuarios[i].mail);
			           	}

			           	//Obtiene los detalles del consorcio para agregarlos al email
			           	$http.get('/api/consorcios/' + $scope.expensa.consorcio)
			           	.success(function(data) {

			           		var protocol = $location.protocol();

							var host = $location.host();

			           		$scope.consorcio = data;
			           		var body = $scope.consorcio.codigo + "|" + $scope.consorcio.direccion;
			           		body += "<br>Ya se encuentran disponibles las expensas del periodo " + $scope.expensa.periodo.anio + "/" + $scope.expensa.periodo.mes;
			           		body += "<br><a target='_blank' href='" + protocol + "://" + host + "/#/" + "galeriaExpensa/" + $scope.idExpensa + "'>Mire la galería de imagenes aquí</a>";

				           	//Mando email!
							$.get("/api/sendMail",{
								to: listaMail,
								subject:'Aviso de nueva expensa disponible',
								html: body
							}
							,function(data)
							{
						        if(data=="sent")
						        {
									alert("La expensa ha sido creada.");
				        		}
				        		else
				        		{
				        			alert("La expensa se ha creado correctamente pero ha ocurrido un error al intentar enviar los mails a los usuarios correspondientes.\nPor favor revise su conexion a internet.");
				        		}
					            $modalInstance.close();
					            $location.path("/expensa/");
							});
						})
						.error(function(data) {
		                	//console.log('Error obteniendo consorcios:' + data);
		                });
		            }	
		            else
		            {
		            	$scope.enviandoMails = false;
						alert("La expensa ha sido creada.");
						$modalInstance.close();
						$location.path("/expensa/");
		            }
	            })
	            .error(function(data) {
	                //console.log('Error obteniendo consorcios:' + data);
	            });
	            //END obtenerConsorcios
           	
				$location.path("/expensa/" + $rootScope.consorcio);
			})
	   	}
	}
});

	
	
adm.filter('expensaConsorcios', function(){
    return function(listaExpensas, direcciones){
        var output = listaExpensas;
        if(direcciones != '' && direcciones != undefined && listaExpensas != undefined){
            output = $.grep(listaExpensas, function(item, index){
                        return ((item.consorcio.direccion != undefined) &&
                                ($.grep(direcciones, function(direccion){
                                	return direccion == item.consorcio.direccion;
                                })).length > 0); 
                        });
        }

        return output;
    }
});

adm.filter('anios', function(){
	return function(listaExpensas, anios){
		var output = listaExpensas;
		if(anios != '' && anios != undefined && listaExpensas != undefined){
            output = $.grep(listaExpensas, function(item, index){
                        return ((item.periodo.anio != undefined) &&
                                ($.grep(anios, function(anio){
                                	return anio == item.periodo.anio;
                                })).length > 0);
                        });
        }

        return output;
	}
});

adm.filter('meses', function(){
	return function(listaExpensas, meses){
		var output = listaExpensas;
		if(meses != '' && meses != undefined && listaExpensas != undefined){
            output = $.grep(listaExpensas, function(item, index){
                        return ((item.periodo.mes != undefined) &&
                                ($.grep(meses, function(mes){
                                	return mes == item.periodo.mes;
                                })).length > 0);
                        });
        }

        return output;
	}
});