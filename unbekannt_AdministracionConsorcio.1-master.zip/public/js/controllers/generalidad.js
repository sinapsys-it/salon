adm.controller('generalidadController', function ($rootScope, $scope, $modal, $location, $http, $window, auth, generalidadFactory, socket) {
   	$scope.mostrarConsorcio = $rootScope.consorcio == 0;
	$scope.coleccionGeneralidades = [];
	$scope.date = new Date();

    //Popover de ayuda
    var rutaImagenes = '../images/generalidades/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Documentos" permite mostrar la lista de documentos que el administrador desea publicar para el uso general de los propietarios/inquilinos.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla "Nuevo documento" nos permite crear publicaciones de documentos. Podemos ingresar un asunto, los consorcios que podran verla, adjuntar los documentos y colocar una descripción.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla de documento permite ver el detalle de la publicacion de documentos que seleccionamos, esta inclye el nombre, los consorcios que pueden ver dicha publicación, los documentos adjuntos y la descripción.'
            }
        ]
    };

    //End Popover de ayuda

	$scope.pageNumber = 1;
	$scope.setPageInfo = function (newPage) {
	 $scope.pageNumber = newPage;
	};
	
	function loadFilters(){
		auth.getCurrentUserId(function(idAdministrador){
		   	//Períodos disponibles
		   	$scope.filtroAnios = [];
		   	$scope.filtroMeses = [];
		   	$http.get('/api/generalidadFiltroAniosByAdmin/' + idAdministrador)
		   	.success(function(data){
		   		$scope.filtroAnios = data;
		   	});
			for (var i = 0; i < 12; i++) {
				$scope.filtroMeses[i] = i + 1;
			};
			//END Periodos disponibles
		});
	};
	
	loadFilters();
	
	generalidadFactory.obtenerGeneralidades($rootScope.consorcio, function(generalidades){
		$scope.coleccionGeneralidades = generalidades;
		$scope.row_collection = generalidades;
	});

    $scope.$on('seleccionarConsorcio', function() {   
    	generalidadFactory.obtenerGeneralidades($rootScope.consorcio, function(generalidades){
    		$scope.coleccionGeneralidades = generalidades;
    		$scope.row_collection = generalidades;
    	});
    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    	if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
    
    //ModalInstance - Muestra modal para crear consorcio
    $scope.crearGeneralidad = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: './views/nuevaGeneralidad.html',
						      controller: 'modalCrearGeneralidadController',
						      size: 'lg'
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			generalidadFactory.obtenerGeneralidades($rootScope.consorcio, function(generalidades){
	    		$scope.coleccionGeneralidades = generalidades;
	    		$scope.row_collection = generalidades;
	    	});
			$location.path("/generalidad/" + $rootScope.consorcio);
		});
	};
	//END ModalInstance

    //ModalInstance - Muestra modal para crear consorcio
    $scope.verGeneralidad = function (_id) {
	    var modalInstance = $modal.open({
						      animation: true,//fade
							  backdrop: 'static',
						      templateUrl: './views/nuevaGeneralidad.html',
						      controller: 'modalVerGeneralidadController',
						      size: 'lg',//large
						      resolve: {
							      generalidad: function () {
						    	  		for(var i = 0; i < $scope.coleccionGeneralidades.length; i++)
			                            {
			                              if($scope.coleccionGeneralidades[i]._id == _id)
			                              {
			                                return $scope.coleccionGeneralidades[i];
			                              }
			                            }
						      		}
						      }
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			generalidadFactory.obtenerGeneralidades($rootScope.consorcio, function(generalidades){
	    		$scope.coleccionGeneralidades = generalidades;
	    		$scope.row_collection = generalidades;
	    	});
		});
	};
	//END ModalInstance
});

//Controlador para modalInstance
adm.controller('modalCrearGeneralidadController', function ($route, $rootScope, $scope, $modal, $cookies, $http, $location, auth, generalidadFactory, uploadFileService, $modalInstance) {
	auth.getCurrentUserId(function (idAdministrador){
		$scope.idAdministrador = idAdministrador;
	});
	
	$scope.saving = false;
	$scope.btnGuardar = "Guardar";
	
   	$scope.ObtenerConsorcios = 	function(query){
							   		return $http.get('/api/ddlConsorciosByQueryAndAdmin/' + query + "/" + $scope.idAdministrador)
							   				.success(function(data){
							   					data.unshift({ _id: "0", direccion: "Todos" });
									   			return data;
									   		});
							   	}
   	
	$scope.seleccionarTodos = function(tag){
   		var res = false;
   		if(tag._id == 0){//Serian todos...
   			$scope.consorcios = [];
			auth.getCurrentUserId(function(_id){
				if(_id){
					$http.get('/api/consorciosByAdmin/' + _id)
					.success(function(consorcios){
						if(consorcios.length > 0){
			    			for(var i = 0; i < consorcios.length; i++){
			    				$scope.consorcios.push({ _id: consorcios[i]._id, direccion: consorcios[i].direccion});
			    			}
		    				res =true;
		    			}
						else{
							res = false;
						}
				    });
				}
				else{
					res = false;
				}
		    });
   		}
   		$scope.algo = '';
   		//console.log($scope.consorcios);
   		return res;
   	}
   	
   	$scope.consorcios = [];
   	
	if($rootScope.consorcio != 0)
	{
		$http.get('/api/consorcios/' + $rootScope.consorcio)
	    .success(function(consorcio) {
	        $scope.consorcios.push({_id: consorcio._id, direccion: consorcio.direccion });
	    });
    }

	$scope.modalTitle = "Nuevo documento"

	$scope.mostrandoGeneralidad = false;

	$scope.imagenes = [];

	$scope.verImagenes = [];

	$scope.tutorial = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: 'tutorialWordToPdf.html',
						      controller: 'tutorialWordToPdfController',
						      size: 'lg'//large
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			novedadFactory.obtenerNovedades($rootScope.consorcio, function(novedades){
	    		$scope.coleccionNovedades = novedades;
	    		$scope.row_collection = novedades;
	    	});
			$location.path("/generalidad/" + $rootScope.consorcio);
		});
	};

	$scope.borrarArchivo = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				$scope.imagenes.splice(i,1);
				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('input').value = "";
	}

	$scope.fileNameChanged = function(ele){

		var lista = [];
		var tipoValidado = true;
		var tipoValidadoWord = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		if (ele.files[i].type.indexOf("word"))
        		{
        			tipoValidadoWord = false;
        		}
        		tipoValidado = false;
        	}
        }

		if (!tipoValidadoWord)
		{
			$scope.tutorial();
		}
		else if (tipoValidado)
		{
			for (var i = 0; i < ele.files.length; i++)
	        {

	        	$scope.imagenes.push(ele.files[i]);

	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	                var picFile = event.target;
	                
	             	$scope.verImagenes.push({
	             								imagen: picFile.result,
	             								nombre: $scope.imagenes[$scope.verImagenes.length].name
	             							});
	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);
							
	        	$scope.imagenesCargadas = true;
	        }
	    }
	    else
	    {
	    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };

	$scope.ok = function () {
		
    	if($scope.formNuevaGeneralidad.$invalid)
		{
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnGuardar = "Guardar";
		}
		else{
			$scope.saving = true;
			$scope.btnGuardar = "Guardando...";

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				
				var fdimagenes = new FormData() 

				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}

				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {

					auth.getCurrentUserId(function(_id){
			        	$scope.generalidad.usuarioRemitente = _id;
			        });

		    		$scope.generalidad.adjuntoGeneralidad = idsImagenes;
		    		$scope.generalidad.tieneImg = true;
					
					$scope.generalidad.consorcios = [];
					for(var i = 0; i < $scope.consorcios.length; i++)
					{
						$scope.generalidad.consorcios.push($scope.consorcios[i]._id);
					}
					
					$http.post('/api/generalidades', { generalidad: $scope.generalidad});
					$modalInstance.close();
					$scope.subiendoImagenes = false;
				});
			}
			else
			{
				$scope.generalidad.tieneImg = false;

				auth.getCurrentUserId(function(_id){
		        	$scope.generalidad.usuarioRemitente = _id;
		        });
				
				$scope.generalidad.consorcios = [];
				for(var i = 0; i < $scope.consorcios.length; i++)
				{
					$scope.generalidad.consorcios.push($scope.consorcios[i]._id);
				}
				
				$http.post('/api/generalidades', { generalidad: $scope.generalidad});
				$modalInstance.close();
			}
    	}
	};
	//END CrearConsorcio

	$scope.cancel = function () {
		$route.reload();
		$modalInstance.close();
	};
});

adm.controller('usersGeneralidadController', function ($route, $rootScope, $scope, $http, $location, $modal){
	function obtenerGeneralidades(){
		$http.get('/mapi/generalidades/' + $rootScope.consorcio + '/' + $rootScope.globals.currentUser.id)
		.success(function(generalidades){
			$scope.coleccionGeneralidades = generalidades;
			$scope.row_collection = generalidades;
		});
	}
	
	obtenerGeneralidades();
	
	$scope.verGeneralidad = function (_id) {
	    var modalInstance = $modal.open({
		      animation: true,//fade
		      templateUrl: './views/nuevaGeneralidad.html',
		      controller: 'modalVerGeneralidadController',
		      size: 'lg',//large
		      resolve: {
			      generalidad: function () {
		    	  		for(var i = 0; i < $scope.row_collection.length; i++)
	                    {
		                      if($scope.row_collection[i]._id == _id)
		                      {
		                    	  return $scope.row_collection[i];
		                      }
	                    }
		      		}
		      }
	    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerGeneralidades();
			$location.path("/users/generalidad/" + $rootScope.consorcio);
		});
	};
});

adm.controller('modalVerGeneralidadController', function ($route, $rootScope, $scope, $cookies, $http, $location, auth, uploadFileService, $modalInstance, generalidad){

	$scope.verImagenes = [];

	$scope.imagenes = [];

	$scope.imagenesCargadas = false;

	$scope.ObtenerConsorcios = function(query){
   		return $http.get('/api/ddlConsorcios');
   	}
	
    $http.get('/api/ddlConsorcios').success(function(data){ 
	  $scope.consorcios = $.grep(data, function(element, index){
				   					return ($.grep(generalidad.consorcios, function(n) { return n._id == element._id; }).length > 0);
							 });
	});
	
    $scope.modalTitle = generalidad.asunto;

	$scope.generalidad = generalidad;
	
	$scope.mostrandoGeneralidad = true;

	if ($scope.generalidad.adjuntoGeneralidad.length > 0)
	{
		for (var i = 0; i < $scope.generalidad.adjuntoGeneralidad.length; i++)
		{
			$http.get('/api/obtenerArchivoById/' + $scope.generalidad.adjuntoGeneralidad[i])
			.success(function(imagen){
				$scope.verImagenes.push(imagen);
				if($scope.verImagenes.length == $scope.generalidad.adjuntoGeneralidad.length)
				{
					$scope.imagenesCargadas = true;
				}
			})
		}
	}
	else
	{
		$scope.imagenesCargadas = true;
	}

	$scope.republicar = function(){ 
		$scope.mostrandoGeneralidad = false;
	}

	$scope.verImagen = function(){ 
        $scope.viendoImagen = true;
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
    }

	$scope.fileNameChanged = function(ele){

		var lista = [];
		var tipoValidado = true;

		if(ele.files.length > 3)
		{
			alert("A superado la cantidad maxima de adjuntos.\nEl maximo es hasta 4 archivos.")
		} 
		else
		{
			for (var i = 0; i < ele.files.length; i++)
	        {
	        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
	        	{
	        		tipoValidado = false;
	        	}
	        }
			
			if (tipoValidado)
			{
				$scope.imagenes = ele.files;

		        for (var i = 0; i < ele.files.length; i++)
		        {
		        	var reader  = new FileReader();

		        	reader.addEventListener("load",function(event){
		                var picFile = event.target;
		                lista.push(picFile.result);      
		             	$scope.verImagenes = lista;
		             	$scope.$apply();
		            });

		        	reader.readAsDataURL(ele.files[i]);
								
		        	$scope.imagenesCargadas = true;
		        }
		    }
		    else
		    {
		    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
		    }
		}
    };

	$scope.ok = function () {
		
    	if($scope.formNuevaGeneralidad.$invalid)
		{
			$scope.submitted = true;
		}
    	else{

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				
				var fdimagenes = new FormData() 

				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}

				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {

					auth.getCurrentUserId(function(_id){
			        	$scope.generalidad.usuarioRemitente = _id;
			        });

		    		$scope.generalidad.adjuntoGeneralidad = idsImagenes;
		    		$scope.generalidad.tieneImg = true;
					
					$scope.generalidad.consorcios = [];
					for(var i = 0; i < $scope.consorcios.length; i++)
					{
						$scope.generalidad.consorcios.push($scope.consorcios[i]._id);
					}
					
					$http.post('/api/generalidades', { generalidad: $scope.generalidad});
					$modalInstance.close();
					$scope.subiendoImagenes = false;
				});
			}
			else
			{
				$scope.generalidad.tieneImg = false;

				auth.getCurrentUserId(function(_id){
		        	$scope.generalidad.usuarioRemitente = _id;
		        });
				
				$scope.generalidad.consorcios = [];
				for(var i = 0; i < $scope.consorcios.length; i++)
				{
					$scope.generalidad.consorcios.push($scope.consorcios[i]._id);
				}
				
				$http.post('/api/generalidades', { generalidad: $scope.generalidad});

				$modalInstance.close();
			}
    	}
	};
	
	$scope.cancel = function () {
		$modalInstance.close();
		$route.reload();
	};

	$scope.eliminar = function () {
		var r = confirm("¿Esta seguro que desea eliminar esta publicación?");
		if (r == true)
		{
		    $http.post('/api/eliminarGeneralidad/' + $scope.generalidad._id)
		    .success(function () {
		    	alert("La publicación ha sido eliminada correctamente");
		    	$modalInstance.close();
		    })
		}
	};
});

adm.factory('generalidadFactory', function($http, auth){
   	
	return{
		obtenerGeneralidades: function(idConsorcio, coleccionGeneralidades){
					        if(idConsorcio == 0 || !idConsorcio){
					        	auth.getCurrentUserId(function(idAdministrador){
						            $http.get('/api/generalidadesByAdmin/' + idAdministrador)
						            .success(function(generalidades) {
						                coleccionGeneralidades(generalidades);
						            })
						            .error(function(generalidades) {
						                //console.log('Error obteniendo las generalidades! ' + generalidades);
						            });
					        	});
					        }
					        else{
					            $http.get('/api/generalidadesByConsorcioId/' + idConsorcio)
					            .success(function(generalidades) {
					                coleccionGeneralidades(generalidades);
					            })
					            .error(function(generalidades) {
					                //console.log('Error obteniendo las generalidades! ' + generalidades);
					            });
					        }
					   	}
	}
});