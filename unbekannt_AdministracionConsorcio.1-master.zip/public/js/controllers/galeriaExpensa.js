adm.controller('galeriaExpensaController', function ($rootScope, $scope, $modal, $location, $http, $window, $routeParams, auth, expensaFactory) {

	$scope.verLiquidaciones = [];

	$scope.verImagenes = [];

	$http.get('/api/expensas/' + $routeParams.id)
    .success(function (data){

		for (var i = 0; i < data.liquidacion.length; i++)
		{
	    	$http.get('/api/obtenerArchivoById/' + data.liquidacion[i])
			.success(function(liquidacion){
				$scope.verLiquidaciones.push(liquidacion);
				if($scope.verLiquidaciones.length == data.liquidacion.length)
				{
					$scope.liquidacionCargada = true;
				}
			})
		}
		
		if (data.adjuntosExpensa.length > 0)
		{
			for (var i = 0; i < data.adjuntosExpensa.length; i++)
			{
				$http.get('/api/obtenerArchivoById/' + data.adjuntosExpensa[i])
				.success(function(imagen){
					$scope.verImagenes.push(imagen);
					if($scope.verImagenes.length == data.adjuntosExpensa.length)
					{
						$scope.imagenesCargadas = true;
					}
				})
			}
		}
    });
});