adm.controller('reclamoController', function ($rootScope, $interval, $scope, $modal, $location, $http, reclamoFactory, auth, usuarioFactory, commonFactory, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }

    //Popover de ayuda
    var rutaImagenes = '../images/reclamos/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Reclamos" permite mostrar la lista de reclamos realizados por los inquilinos/propietarios.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla reclamo nos permite visualizar el detalle del reclamo realizado por el inquilinos/propietarios que incluye el nombre y apellido del remitente, su direccion, la imagen adjunta del reclamo y el detalle del mismo.'
            }
        ]
    };

    //End Popover de ayuda
	$scope.pageNumber = 1;
	$scope.mostrarConsorcio = $rootScope.consorcio == 0;
	$scope.listaReclamos = [];
	$scope.pages_to_display = 0;
	$scope.dropdownLabel = "Años: Todos";
	$scope.distinctItems = [];
	
	reclamoFactory.obtenerReclamos(function(reclamos){
		$scope.row_collection = reclamos;
		$scope.listaReclamos = reclamos;
		
		usuarioFactory.mostrarLotes(reclamos, function(flag){
			$scope.mostrarLotes = flag;
		});
	});

	$scope.setPageInfo = function (newPage) {
		$scope.pageNumber = newPage;
	};

    var intervalPromise = $interval(function(){
    		reclamoFactory.obtenerReclamos(function(reclamos){
	    		$scope.row_collection = reclamos;
	    		$scope.listaReclamos = reclamos;
	    		
	    		usuarioFactory.mostrarLotes(reclamos, function(flag){
	    			$scope.mostrarLotes = flag;
	    		});
	    	});
	}, 30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
	$scope.getFiltroAnios = function(){
		return 
		auth.getCurrentUserId(function(idAdministrador){
		   	$http.get('/api/reclamoFiltroAniosByAdmin/' + idAdministrador)
		   	.success(function(data){
		   		return data;
		   	});
		});
	}
	
	function loadFilters(){
		auth.getCurrentUserId(function(idAdministrador){
		   	//Períodos disponibles
		   	$scope.filtroAnios = [];
		   	$scope.filtroMeses = [];
		   	$http.get('/api/reclamoFiltroAniosByAdmin/' + idAdministrador)
		   	.success(function(data){
		   		$scope.filtroAnios = data;
		   	});
			for (var i = 0; i < 12; i++) {
				$scope.filtroMeses[i] = i + 1;
			};
			//END Periodos disponibles
		});
   	}
	
   	loadFilters();

	$scope.$on('seleccionarConsorcio', function() {   
		$scope.mostrarConsorcio = $rootScope.consorcio == 0;
		reclamoFactory.obtenerReclamos(function(reclamos){
			$scope.row_collection = reclamos;
			$scope.listaReclamos = reclamos;
			
			usuarioFactory.mostrarLotes(reclamos, function(flag){
	    			$scope.mostrarLotes = flag;
			});
		});

		if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
	
	$scope.verReclamo = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: './views/detalleReclamo.html',
	      controller: 'verReclamoController',
	      size: 'lg',//large
	      resolve: {
		      	reclamo: function () {
		    	    for(var i = 0; i < $scope.listaReclamos.length; i++){
		                 if($scope.listaReclamos[i]._id == _id){
		                	 return angular.copy($scope.listaReclamos[i]);
		                 }
    	  			}
      			}
      	  }
    	 });

		//EL Modal se cerró!
		modalInstance.result.then(function () {
			reclamoFactory.obtenerReclamos(function(reclamos){
				$scope.listaReclamos = reclamos;
			});
			
			$location.path("/reclamo/" + $rootScope.consorcio);
		});
	};
});

adm.directive('stSelectMultiple',function(){
	return {
        restrict: 'E',
        require: '^stTable',
        scope: {
        	searchFilter: '=',
        	ngModel: '=',
        	selectLabel: '@',
        	searchField: '@',
        	searchComparator: '@'
        },
        template: '<multiselect st-search="fechaAlta" class="input-xlarge" ms-header="{{ selectLabel }}" ng-model="ngModel" multiple="true" options="c for c in searchFilter"></multiselect>',
        link: function(scope, element, attr, table) {
    	scope.$watch('ngModel',
			function (newVal) {
    			initialize();
	
				function initialize() {
					if(newVal != undefined && newVal != []){
						var query = {
							matchAny: {
							  items: [],
							  all: false,
							  comparator: scope.searchComparator
						  	}
						};
						
						query.matchAny.items = newVal;
						var numberOfItems = 0;
						if(query.matchAny.items){
							numberOfItems = query.matchAny.items.length;
						}
						
						if (numberOfItems === 0 || numberOfItems === scope.searchFilter.length) {
						  query.matchAny.all = true;
						} else {
						  query.matchAny.all = false;
						}
						
						table.search(query, scope.searchField);
					}
				}
    		});
		}
	}
});
  
adm.filter('customFilter', ['$filter', function($filter) {
    var filterFilter = $filter('filter');
    var output = [];
    
    return function customFilter(array, expression) {
    	var comparators = {
    			filtroBruto: 	     function filtroBruto(actual, collection){
    		    	for (var i = 0; i < collection.length; i++) {
    		    		if (actual.toString() == collection[i].toString()) {
    						return true;
    					}
    				}
				},
    	    	dateYearComparator:  function dateYearComparator(actual, expected){
    	    		if(!(angular.isObject(expected))){
    	    			return comparators.standardComparator(actual, expected);
    	    		}
    	    		
    	    		expected = getComparatorObject(expected);
    				return  expected.matchAny.items == undefined
					|| expected.matchAny.items.length == 0
					|| comparators.filtroBruto((new Date(actual)).getFullYear(), expected.matchAny.items)
				},
				dateMonthComparator: function dateMonthComparator(actual, expected){
					if(!(angular.isObject(expected))){
    	    			return comparators.standardComparator(actual, expected);
    	    		}
					
					expected = getComparatorObject(expected);
					return expected.matchAny.items == undefined
					|| expected.matchAny.items.length == 0
					|| comparators.filtroBruto((new Date(actual)).getMonth() + 1, expected.matchAny.items)
				},
			 	stringLitComparator: function stringLitComparator(actual, expected){
			 		if(!(angular.isObject(expected))){
    	    			return comparators.standardComparator(actual, expected);
    	    		}
    	    		
					expected = getComparatorObject(expected);
			 		return expected.matchAny.items == undefined
					|| expected.matchAny.items.length == 0
					|| comparators.filtroBruto(actual, expected.matchAny.items)
			 	},
				stringLitArrayComparator: function stringLitArrayComparator(actual, expected){
					//console.log(actual);
					//console.log(expected);
				},
				standardComparator:  function standardComparator(obj, text) {
								        text = ('' + text).toLowerCase();
								        return ('' + obj).toLowerCase().indexOf(text) > -1;
								     }
    	}

    	/*Sin importar cuál sea la property a filtrar obtenemos el comparador*/
    	function getComparatorObject (initObject){
	    	for (var key in initObject) {
	    		/*Corte*/
	    		if((key == "matchAny" && initObject.hasOwnProperty(key)) || !(angular.isObject(initObject[key]))){
	    			return initObject;
	    		}
	    		else{
	    			return getComparatorObject(initObject[key]);
	    		}
	    	}
    	}
    	
    	var comparatorObject  = getComparatorObject(expression);
    	if(comparatorObject == undefined){
    		return array;
    	}
    	if(comparatorObject.matchAny == undefined){
		/*¡Estamos buscando desde un input type text!*/
    		output = filterFilter(array, expression, comparators['standardComparator']);
    	}
    	else{
		/*¡Estamos buscando desde un multiselect o algo más complejo!*/
    		output = filterFilter(array, expression, comparators[comparatorObject.matchAny.comparator.toString()]);
    	}
    	
		return output;
    };
}]);

adm.controller("usersReclamoController", function($rootScope, $scope, reclamoFactory, $modal, $http, $location){
	
	function ObtenerReclamos(){
		$http.get('/mapi/reclamos?idConsorcio=' + $rootScope.consorcio + '&idUsuario=' + $rootScope.globals.currentUser.id)
		.success(function(reclamos){
			$scope.row_collection = reclamos;
			$scope.listaReclamos = reclamos;
		});
	}
	
	ObtenerReclamos();
	
	$scope.$on('seleccionarConsorcio', function() {   
		$scope.mostrarConsorcio = false
		ObtenerReclamos();
    });
	
	$scope.newReclamo = function(){
		var modalInstance = $modal.open({
		      animation: true,//fade
		      templateUrl: './views/nuevoReclamo.html',
		      controller: 'nuevoReclamoController',
		      size: 'lg',//large
    	 });

		//EL Modal se cerró!
		modalInstance.result.then(function () {
			ObtenerReclamos();
			$location.path( "/users/reclamo/" + $rootScope.consorcio);
		});
	}
	
	$scope.verReclamo = function(_id){
		var modalInstance = $modal.open({
		      animation: true,//fade
		      templateUrl: './views/detalleReclamo.html',
		      controller: 'verReclamoController',
		      size: 'lg',//large
		      resolve: {
			      	reclamo: function () {
			    	    for(var i = 0; i < $scope.listaReclamos.length; i++){
			                 if($scope.listaReclamos[i]._id == _id){
			                	 return angular.copy($scope.listaReclamos[i]);
			                 }
	    	  			}
	      			}
	      	  }
		});

		//EL Modal se cerró!
		modalInstance.result.then(function () {
			ObtenerReclamos();
			$location.path( "/users/reclamo/" + $rootScope.consorcio);	
		});
	}
});

adm.controller('nuevoReclamoController', function($scope, $rootScope, $modalInstance, $http, $location){
	$scope.reclamo = {
			usuarioRemitente: $rootScope.globals.currentUser.id,
			consorcio: '',
			leido: false,
			mensaje: '',
			piso: {
				numero: '',
				dpto: {
					nombre: '',
				}
			},
			lote: {
				numero: ''
			},
			adjuntoReclamo: [],
			fechaAlta: new Date()
	}
	
	if($rootScope.usuarioPisoSeleccionado){
		$scope.reclamo.piso = $rootScope.usuarioPisoSeleccionado;
	}
	else{
		$scope.reclamo.lote =$rootScope.usuarioLoteSeleccionado;
	}
	
    $scope.viendoImagen = false;
    $scope.cargando = true;
    $scope.modalTitle = "Nuevo Reclamo";
    
    $scope.saving = false;
	$scope.btnEnviar = "Enviar";
	
	$http.get('/mapi/getConsorcio?codigoConsorcio=' + $rootScope.consorcioCodigo)
    .success(function(consorcio) {
        $scope.reclamo.consorcio = {_id: consorcio[0]._id, direccion: consorcio[0].direccion };
    });
	
	$scope.mostrandoReclamo = false;

	$scope.imagenes = [];
	$scope.verImagenes = [];

	$scope.borrarArchivo = function(indice){
		$scope.imagenes.splice(indice,1);
		$scope.verImagenes.splice(indice,1);
	}

	$scope.fileNameChanged = function(ele){
		var tipoValidado = true;
		var tipoValidadoWord = true;

		if(ele.files.length + $scope.imagenes.length > 4)
		{
			alert("A superado la cantidad maxima de adjuntos.\nEl maximo es hasta 4 archivos.")
		} 
		else
		{
			for (var i = 0; i < ele.files.length; i++)
	        {
	        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
	        	{
	        		if (ele.files[i].type.indexOf("word"))
	        		{
	        			tipoValidadoWord = false;
	        		}
	        		tipoValidado = false;
	        	}
	        }

			if (!tipoValidadoWord)
			{
				$scope.tutorial();
			}
			else if (tipoValidado)
			{

		        for (var i = 0; i < ele.files.length; i++)
		        {
		        	$scope.imagenes.push(ele.files[i]);
		        	var reader  = new FileReader();
		        	reader.addEventListener("load",function(event){
		                var picFile = event.target;
		                
		             	$scope.verImagenes.push({
		             								imagen: picFile.result,
		             								nombre: $scope.imagenes[$scope.verImagenes.length].name
		             							});
		             	$scope.$apply();
		            });
		        	reader.readAsDataURL(ele.files[i]);
		        	$scope.imagenesCargadas = true;
		        }
		    }
		    else
		    {
		    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
		    }
		}
    };
    
    $scope.ok = function () {
    	if($scope.formReclamo.$invalid)
		{
			$scope.submitted = true;
			$scope.saving = false;
			$scope.btnEnviar = "Enviar";
		}
		else{
			$scope.saving = true;
			$scope.btnEnviar = "Enviando...";

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				var fdimagenes = new FormData() 
				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}
				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {
		        	$scope.reclamo.usuarioRemitente = $rootScope.globals.currentUser.id;

		    		$scope.reclamo.adjuntoReclamo = idsImagenes;
		    		$scope.reclamo.tieneImg = true;
		    		$scope.reclamo.consorcio = $scope.reclamo.consorcio._id;
					
					$http.post('/mapi/reclamoNuevo', $scope.reclamo);
					$modalInstance.close();
					$scope.subiendoImagenes = false;
				});
			}
			else
			{
	        	$scope.reclamo.usuarioRemitente = _id;
				$scope.reclamo.consorcio = $scope.reclamo.consorcio._id;

				$http.post('/mapi/reclamoNuevo', $scope.reclamo)
				.success(function(){
					$modalInstance.close();
					$location.path("/users/reclamo/" +  $scope.reclamo.consorcio._id);
				});
			}
    	}
	};
	
	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/users/reclamo/" +  0);
	};	
});
	
adm.controller('verReclamoController', function ($rootScope, $scope, $modalInstance, $modal, $location, $http, reclamo, auth, socket) {
	$scope.reclamo = reclamo;

	if (reclamo.piso != undefined)
	{
		$scope.reclamo.usuarioRemitente.nombreApellido += " - Piso " + $scope.reclamo.piso.numero + " Dpto " + $scope.reclamo.piso.depto.nombre;
	}
	else
	{
		$scope.reclamo.usuarioRemitente.nombreApellido += " - Lote " + $scope.reclamo.lote.numero;
	}

	$http.post('/api/markReadReclamo', {reclamoId: $scope.reclamo._id, leido: true}).success(function(data){
		socket.updateEventByConsorcio($rootScope.consorcio, 1, 0, 0);
	});

	$scope.reclamo.usuarioRemitente.nombreApellido +=

	$scope.verImagenes = [];

    $scope.myInterval = 4000;//intervalo para la galería

	if ($scope.reclamo.adjuntoReclamo != undefined)
	{
		$scope.imagenesCargadas = false;

		for (var i = 0; i < $scope.reclamo.adjuntoReclamo.length; i++) 
		{
			$http.get('/api/obtenerArchivoById/' + $scope.reclamo.adjuntoReclamo[i])
			.success(function(imagen){
				$scope.verImagenes.push(imagen);
				if($scope.verImagenes.length == $scope.reclamo.adjuntoReclamo.length)
				{
					$scope.imagenesCargadas = true;
				}
			})
		}
	}

	$scope.verImagen = function(){ 
        $scope.viendoImagen = true;
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
    }

	$scope.enviarMensaje = function () {

		auth.getCurrentUserId(function(idAdministrador){
			var participantes = [];
			participantes.push(idAdministrador);
			participantes.push($scope.reclamo.usuarioRemitente._id);

			$http.get('/app/verificarConversacion/' + participantes)
			.success(function (conversacion){

				if(conversacion.length == 0)
				{
			        var modalInstance = $modal.open({
			            animation: true,//fade
			            templateUrl: './views/nuevoMensaje.html',
			            controller: 'modalMensajeController',
			            size: 'lg',//large
			            resolve: {
			                destinatarios: function(){
			                    return $scope.reclamo.usuarioRemitente;
			                },
			                mensaje: function () {
			                    return null;
			                },
			                url: function(){
			                	return $location.path();
			                }
			            }
			        });
			        modalInstance.result.then(function () {//EL Modal se cerró!
			            $location.path( "#/reclamo/" + $rootScope.consorcio );
			        });
			    }
			    else
			    {
			        var modalInstance = $modal.open({
			        animation: true,//fade
			        templateUrl: './views/verConversacion.html',
			        controller: 'modalVerConversacionController',
			        size: 'lg',//large
			        resolve: {
			                    destinatarios: function(){
			                        return $scope.reclamo.usuarioRemitente.nombreApellido;
			                    },
			                    participantes: function(){
			                        return participantes;
			                    },
			                    idConversacion: function(){
			                        return conversacion[0]._id;
			                    },
                                url: function(){
                                    return $location.path();
                                }
			                }
			        });
			    
			        modalInstance.result.then(function () {//EL Modal se cerró!
			            auth.getCurrentUserId(function(_id){
			                menssageFactory.obtenerConversaciones(_id, $rootScope.consorcio, function(datad){
			                   $scope.listaConversaciones = datad;
			                });
			            });
			            $location.path( "/reclamo/" + $rootScope.consorcio );
			        });
				}
			});
		});
	};	

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		if($rootScope.globals.currentUser.isAdmin){
			$location.path( "/reclamo/" +  $rootScope.consorcio);
		}
	};	
});

adm.factory('reclamoFactory', function($http, $rootScope, auth){
	
	return {
		obtenerReclamos: function(cb){
			var uri = '';
			if($rootScope.consorcio != 0 && $rootScope.consorcio != undefined){
				uri = '/api/reclamosByConsorcioId/' + $rootScope.consorcio;
			}
			else{
				auth.getCurrentUserId(function(idAdministrador){
					uri = '/api/reclamosByAdmin/' + idAdministrador;
				});
			}
			
			$http.get(uri)
		    .success(function(data) {
		    	cb(data);
		    })
		    .error(function(data) {
		    	//console.log('Error obteniendo reclamos:' + data);
		    	cb([]);
		    });
		}
	};
});