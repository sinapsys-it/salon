adm.controller('loginController', function ($rootScope, $scope, $timeout, $location, $modal, $http, auth, $window) {
	$scope.login ={
		username: '',
		password: ' ',
		usercode: '',
		userEmail: '',
		userPass: ''
	};

	/*Path al cual se redirecciona un usuario al ejecutar el login*/
	$scope.resetFields = function resetFields(){
		$scope.login ={
			username: '',
			password: '',
			usercode: '',
			userEmail: '',
			userPass: ''
		};
	}
	
    $scope.loginAdmin = function(){
		if($scope.loginForm.$invalid){
			$scope.submitted = true;
		}
		else{
			$scope.submitted = false;
			auth.login($scope.login.username, sha256_digest($scope.login.password), function(isAuthorized){
	    		if(isAuthorized){
	    			$scope.authFailed = false;
	    		    auth.getUserName(function(username){
	    		        $rootScope.username = username;
	    		    });
	    			
		        	$location.path("/mensaje");
		    	}
		    	else{
		    		$scope.submitted = true;
		    		$scope.authFailed = true;
		    	}
	    	});
		}

		$timeout(function(){
			$scope.submitted = false;
			$scope.authFailed = false;
		}, 2000);
    }

    $scope.logUser = function(){
    	if($scope.loginForm.$invalid){
			$scope.submitted = true;
		}
		else{
			$scope.submitted = false;
			auth.loginPropInq($scope.login.userEmail, sha256_digest($scope.login.userPass), function(isAuthorized){
	    		if(isAuthorized){
	    			$scope.authFailed = false;
	    		    auth.getUserName(function(username){
	    		        $rootScope.username = username;
	    		    });
	    			
		        	$location.path("/users/mensaje");
		    	}
		    	else{
		    		$scope.submitted = true;
		    		$scope.authFailed = true;
		    	}
	    	});
		}

		$timeout(function(){
			$scope.submitted = false;
			$scope.authFailed = false;
		}, 2000);
    }

	$scope.crearAdministrador = function(){
		var modalInstance = $modal.open({
							      animation: true,//fade
							      templateUrl: 'nuevoAdministrador.html',
							      controller: 'modalNuevoAdministradorController',
							      size: 'lg',//large
							      resolve: {
								      	items: function () {
							    	  		return $scope.mensaje;
							      		}
							      }
							    });
			modalInstance.result.then(function () {
				$location.path( "/login" );
			}, function () {
				$location.path( "/login" );
			});
	}
});

adm.controller('modalNuevoAdministradorController', function ($scope, $http, $window, $location, $modalInstance, auth) {
	$scope.usuario = {
			esPersonaFisica: true,
			domicilio:{
				pais : "Argentina"
			}
	};

	$scope.saving = false;
	$scope.btnIngresar = "Ingresar";
	
	$http.get('/api/paises')
	.success(function(data) {
		$scope.listaPaises = data;
	});

	$scope.inputType = 'password';

	$scope.hideShowPassword = function(){
		if ($scope.inputType == 'password')
		{
			$scope.inputType = 'text';
		}
		else
		{
			$scope.inputType = 'password';
		}
	};

	$scope.setIntNumber = function(){
		$scope.usuario.telefono = {
			codigoPais: '',
			area: '',
			numero: $("#telefono").intlTelInput("getNumber")
		}
	}

	$scope.ok = function () {
		if($scope.formAdministrador.$invalid || $scope.usuario.mail != $scope.usuario.remail || $scope.usuario.contrasenia != $scope.contrasenia2)
		{
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnIngresar = "Ingresar";
		}
		else
		{
			$scope.saving = true;
			$scope.btnIngresar = "Iniciando sesión...";
			
			if ($scope.usuario.esPersonaFisica) 
			{
				$scope.usuario.cuit = $scope.usuario.cuil;
				$scope.usuario.razonSocial = "";
			}
			else
			{
				$scope.usuario.cuil = "";
				$scope.usuario.nombre = $scope.usuario.razonSocial;
				$scope.usuario.apellido = "";
			}

			$scope.usuario.contrasenia = sha256_digest($scope.usuario.contrasenia);

			$http.post('/api/usuarios', { usuario: $scope.usuario})
			.success(function(data) {
				//Something...
				$modalInstance.close();
				auth.login(data.mail, data.contrasenia, function(isAuthorized){
		    		if(isAuthorized)
		    		{
		    			//console.log("Acceso autorizado");
		    			$scope.authFailed = false;
			        	$location.path("/mensaje");
			        	auth.is_logged();
			    	}
			    	else
			    	{
			    		//console.log("Acceso denegado! Redirecciono al path...");
			    		$scope.submitted = true;
			    		$scope.authFailed = true;
			    		$location.path("/login");
			    	}
		    	});
			})
			.error(function(data) {
			    //console.log('Error:' + data);
			});
		}
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/login" );
	};
});

adm.controller('modalNuevoUsuarioController', function($scope, $modalInstance, $location, $timeout, $rootScope, auth){
	$scope.usuario = {
		propietario: true,
		password: '',
		usercode: ''
	};
	$scope.waiting = false;

	$scope.ok = function()
    {
    	$scope.waiting = true;

		if($scope.usuarioForm.$invalid){
			$scope.submitted = true;
		}
		else{
			$scope.submitted = false;
			var cods_array = new Array();
			$scope.saving = true;
	    	cods_array.push($scope.usuario.usercode.slice(0, 5));//codigo de consorcio
	    	cods_array.push($scope.usuario.usercode.slice(5, 8));//codigo de dpto o lote

	    	auth.loginUser(cods_array, $scope.usuario, function(correct){
	    		if(correct){
					$scope.authFailed = false;

	    		    auth.getUserName(function(username){
	    		        $rootScope.username = username;
	    		    });

	    			$modalInstance.close();
	    		}
	    		else{
	    			$scope.submitted = true;
		    		$scope.authFailed = true;
	    		}

	    		$scope.waiting = false;
	    	});
		}

		$timeout(function(){
			$scope.submitted = false;
			$scope.authFailed = false;
		}, 2000);
    }

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/login" );
	};
});