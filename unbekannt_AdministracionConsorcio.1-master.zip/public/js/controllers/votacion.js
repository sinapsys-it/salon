adm.controller('votacionController', function ($rootScope, $interval, $scope, $modal, $location, $http, votacionFactory, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }
    
    $scope.pageNumber = 1;
    $scope.setPageInfo = function (newPage) {
		$scope.pageNumber = newPage;
	};

	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    //Popover de ayuda
    var rutaImagenes = '../images/votaciones/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Votaciones" permite mostrar la lista de votaciones que el administrador mantiene con los inquilinos/propietarios.\nDesde el botón "Crear votación" accedemos a la pantalla de creación de votación.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla "Nueva votación" nos permite crear una votación.\nEn esta podemos indicar el asunto, el consorcio destinatario, la fecha de finalización, una descripción y adjuntar una imagen general.\nTambién podemos crear las opciones que estarán disponibles para que los propietarios/inquilinos voten, indicando su titulo e imagen descriptiva.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla de votacion nos permite visualizar los datos de las votaciones ya creadas.\nDentro de la pestaña "Datos principales" podemos ver el asunto, el consorcio destinatario, la fecha de finalización, la descripción y la imagen general.'
            },
            {
                route: rutaImagenes + 'Imagen4.png',
                description: 'En la pestaña "Resultados" tenemos el detalle de estos en porcentaje y en votos sobre el total.'
            },
            {
                route: rutaImagenes + 'Imagen5.png',
                description: 'En la pestaña "Comentarios" veremos los comentarios realizados por los votantes de dicha votacion.'
            }
        ]
    };

    //End Popover de ayuda
	
	function obtenerVotaciones(){
		votacionFactory.obtenerVotaciones(function(votaciones){
			$scope.listaVotaciones = votaciones;
			$scope.row_collection = votaciones;
		});
	}

	obtenerVotaciones();
	
    $interval(function(){
    	obtenerVotaciones();
	}, 60000);
	
	//Cuando cambia el consorcio que está seleccionado
	$scope.$on('seleccionarConsorcio', function() {   
		obtenerVotaciones();
    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    	if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
	
	$scope.crearVotacion = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: 'nuevaVotacion.html',
	      controller: 'nuevaVotacionController',
	      size: 'lg'
		});
		
		//EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerVotaciones()
			$location.path("/votacion/" + $rootScope.consorcio);
		});
	};
	
	$scope.verVotacion = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: 'nuevaVotacion.html',
	      controller: 'verVotacionController',
	      size: 'lg',//large
	      resolve: {
		      	id: function () {
					return _id
      			}
      	  	}
    	});
		//EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerVotaciones();
			$location.path("/votacion/" + $rootScope.consorcio);
		});
	};
});

adm.controller('verVotacionController', function ($rootScope, $scope, $modalInstance, $location, $http, auth, id) {

	$scope.mostrandoVotacion = true;
	$scope.verOpciones = false;
	$scope.verImagenes = [];

	$http.get('/api/votacion/' + id)
	.success(function (votacion){
		$scope.votacion = votacion;

		$scope.consorcios = [];
		
		$scope.consorcios.push(
			{
				_id: votacion.consorcio._id,
				direccion: votacion.consorcio.direccion
			}
		);

		$scope.modalTitle = votacion.asunto;

		for (var i = 0; i < $scope.votacion.opciones.length; i++)
		{
			$scope.votacion.opciones[i].porcentaje = Math.round($scope.votacion.opciones[i].porcentaje *100)/100 ;

			$scope.votacion.opciones[i].votos = 0;

			for(var j = 0; j < $scope.votacion.votos.length; j++)
			{
				if($scope.votacion.votos[j].idOpcion == $scope.votacion.opciones[i].idOpcion)
				{
					$scope.votacion.opciones[i].votos++;
				}
			}

			if (!angular.isUndefined($scope.votacion.opciones[i].imagen))
			{
				var idImagen = $scope.votacion.opciones[i].imagen;

				$scope.bajarArchivos(idImagen, i, function (objetoImagen)
				{
					$scope.votacion.opciones[objetoImagen.posicion].verImagen = objetoImagen.data;
				})
			}
		}
		for (var i = 0; i < $scope.votacion.adjuntosVotacion.length; i++)
		{
	    	$http.get('/api/obtenerArchivoById/' + $scope.votacion.adjuntosVotacion[i])
			.success(function(imagen){
				$scope.verImagenes.push(imagen);
				if($scope.verImagenes.length == $scope.votacion.adjuntosVotacion.length)
				{
					$scope.imagenesCargadas = true;
				}
			})
		}
	})

	$scope.mostrarOpciones = function(){
		$scope.verOpciones = true;
	};

	$scope.ocultarOpciones = function(){
		$scope.verOpciones = false;
	};

	$scope.bajarArchivos = function(archivo, indice, cb){
		$http.get('/api/obtenerArchivoById/' + archivo)
		.success(function(imagen){
			cb({
        		data: imagen.imagen,
        		posicion: indice
        	});
		})
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/votacion/" + $rootScope.consorcio);
	};
});

adm.controller('nuevaVotacionController', function ($rootScope, $modal, $scope, $modalInstance, $location, $http, auth, votacionFactory) {

	$scope.saving = false;
	$scope.btnGuardar = "Comenzar votación";
	
	$scope.modalTitle = "Nueva votacion"

	$scope.mostrandoVotacion = false;

	$scope.verOpciones = true;

	$scope.verImagenes = [];

	$scope.saving = false;
	$scope.btnEnviar = "Comenzar votación";
	
	auth.getCurrentUserId(function (idAdministrador){
		$scope.idAdministrador = idAdministrador;
	});

	$scope.imagenes = [];
	$scope.today =  new Date();
	$scope.votacion = {
		multiple: true,
		comentarioActivo: false,
		opciones: [
			{ imagen:'', active:true },
			{ imagen:'' }
		]
	}

	//Obtiene los consorcios existentes
    $scope.ObtenerConsorcios = 	function(query){
								   	return $http.get('/api/ddlConsorciosByQueryAndAdmin/' + query + "/" + $scope.idAdministrador);
								};
   	$scope.consorcios = [];
   	
	if($rootScope.consorcio != 0)
	{
		$http.get('/api/consorcios/' + $rootScope.consorcio)
	    .success(function(consorcio) {
	        $scope.consorcios.push({_id: consorcio._id, direccion: consorcio.direccion });
	    });
    }
    //END obtenerConsorcios
	
	$scope.status = {
		opened: false
	}

	$scope.tutorial = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: 'tutorialWordToPdf.html',
						      controller: 'tutorialWordToPdfController',
						      size: 'lg'//large
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			novedadFactory.obtenerNovedades($rootScope.consorcio, function(novedades){
	    		$scope.coleccionNovedades = novedades;
	    		$scope.row_collection = novedades;
	    	});
			$location.path("/votacion/" + $rootScope.consorcio);
		});
	};

	$scope.agregarOpcion = function() {
		$scope.votacion.opciones.push({imagen:''});
		$scope.votacion.opciones[$scope.votacion.opciones.length -1].active = true;
	};

	$scope.eliminarOpcion = function(indice){
		$scope.votacion.opciones.splice(indice, 1);
		$scope.votacion.opciones[$scope.votacion.opciones.length -1].active = true;
	}
	
	$scope.open = function($event) {
		$scope.status.opened = true;
	};

	$scope.borrarArchivo = function(){
		opcionActiva = $.grep($scope.votacion.opciones, function(opcion){
      					return opcion.active == true;
					});
		opcionActiva[0].dataImagen = undefined;
		opcionActiva[0].verImagen = undefined;
		document.getElementById('inputOpcion').value = "";
	}

	$scope.borrarArchivoDescripcion = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				$scope.imagenes.splice(i,1);
				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('inputDescripcion').value = "";
	}

	$scope.fileNameChangedDescripcion = function(ele){
		var cantidadImagenes = 0;
		var lista = [];
		var tipoValidado = true;
		var tipoValidadoWord = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		if (ele.files[i].type.indexOf("word"))
        		{
        			tipoValidadoWord = false;
        		}
        		tipoValidado = false;
        	}
        }

        cantidadImagenes = $scope.verImagenes.length + ele.files.length;

        if (cantidadImagenes > 4)
		{
			alert("Solo se pueden adjuntar hasta 4 imagenes en la descripcion de la votación.")
		}
		else if (!tipoValidadoWord)
		{
			$scope.tutorial();
		}		 
		else if (tipoValidado)
		{
			for (var i = 0; i < ele.files.length; i++)
	        {

	        	$scope.imagenes.push(ele.files[i]);

	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	                var picFile = event.target;
	                
	             	$scope.verImagenes.push({
	             								imagen: picFile.result,
	             								nombre: $scope.imagenes[$scope.verImagenes.length].name
	             							});
	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);
							
	        	$scope.imagenesCargadas = true;
	        }
	    }
	    else
	    {
	    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };
	
	$scope.fileNameChanged = function(ele){

		var tipoValidado = true;
		var tipoValidadoWord = true;

		for (var i = 0; i < ele.files.length; i++)
        {
        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
        	{
        		if (ele.files[i].type.indexOf("word"))
        		{
        			tipoValidadoWord = false;
        		}
        		tipoValidado = false;
        	}
        }

		if (!tipoValidadoWord)
		{
			$scope.tutorial();
		}
		else if (tipoValidado)
		{
			opcionActiva = $.grep($scope.votacion.opciones, function(opcion){
      					return opcion.active == true;
					});

			opcionActiva[0].dataImagen = ele.files;

	        for (var i = 0; i < ele.files.length; i++)
	        {
	        	var reader  = new FileReader();

	        	reader.addEventListener("load",function(event){
	                var picFile = event.target;
	                
	             	opcionActiva[0].verImagen = picFile.result;
	             	$scope.$apply();
	            });

	        	reader.readAsDataURL(ele.files[i]);
							
	        	$scope.imagenesCargadas = true;
	        }
	    }
	    else
	    {
	    	alert("El tipo del archivo ingresado no es soportado por la aplicación.\nPor favor, intente nuevamente.");
	    }
    };

	$scope.ok = function(){

		if($scope.formVotacion.$invalid)
		{
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnGuardar = "Comenzar votación";
		}
    	else{
    		$scope.saving = true;
    		$scope.btnGuardar = "Iniciando votación...";
    		
			if ($scope.imagenes.length > 0)
			{
				$scope.votacion.tieneImg = true;

				$scope.subiendoImagenes = true;

				var fd = new FormData();

				for (var i = 0; i < $scope.imagenes.length; i++) {
					fd.append("archivo" + i, $scope.imagenes[i]);
				}

				$http.post('/api/crearArchivos',fd,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {

					$scope.votacion.adjuntosVotacion = idsImagenes;
					guardarVotacion();
					
				})
			}
			else
			{
				guardarVotacion();
			}
		}
	};

	function guardarVotacion(){

		var cantidadImagenes = 0;

		var cantidadImagenesSubidas = 0;

		if (!angular.isUndefined($scope.consorcios[0]))
		{
			$scope.votacion.consorcio = $scope.consorcios[0]._id;
		}

		for (var i = 0; i < $scope.votacion.opciones.length; i++)
		{
			$scope.votacion.opciones[i].idOpcion = i + 1;

			if($scope.votacion.opciones[i].dataImagen != undefined)
			{
				cantidadImagenes++;
			}
		}

		if (cantidadImagenes > 0)
		{

			for (var i = 0; i < $scope.votacion.opciones.length; i++) 
			{
				if($scope.votacion.opciones[i].dataImagen != undefined)
				{
					var dataImagen = $scope.votacion.opciones[i].dataImagen;

					//console.log(dataImagen);
					
					$scope.subirArchivos(dataImagen, i, function (objetoImagen)
					{
						$scope.votacion.opciones[objetoImagen.posicion].imagen = objetoImagen.id;
						cantidadImagenesSubidas++;
						if (cantidadImagenes == cantidadImagenesSubidas)
						{
							var opciones = [];

							for (var i = 0; i < $scope.votacion.opciones.length; i++) 
							{
								opciones.push({
									idOpcion: $scope.votacion.opciones[i].idOpcion,
									descripcion: $scope.votacion.opciones[i].descripcion,
									imagen: $scope.votacion.opciones[i].imagen==""?undefined:$scope.votacion.opciones[i].imagen
								})
							}

							$scope.votacion.opciones = opciones;

							$http.post('/api/crearVotacion',{ votacion: $scope.votacion})
							.success(function (votacion){
								$scope.subiendoImagenes = false;
								$modalInstance.close();
								$location.path("/votacion/" + $rootScope.consorcio);
							})
						}
					})
				}
			}
		}
		else
		{
			var opciones = [];

			for (var i = 0; i < $scope.votacion.opciones.length; i++) 
			{
				opciones.push({
					idOpcion: $scope.votacion.opciones[i].idOpcion,
					descripcion: $scope.votacion.opciones[i].descripcion
				})
			}

			$scope.votacion.opciones = opciones;

			$http.post('/api/crearVotacion',{ votacion: $scope.votacion})
			.success(function (votacion){
				$scope.subiendoImagenes = false;
				$modalInstance.close();
				$location.path("/votacion/" + $rootScope.consorcio);
			})
		}
	};

	$scope.subirArchivos = function(archivos, indice, cb){
			
		//console.log(archivos);
		var fd = new FormData() 

		for (var i = 0; i < archivos.length; i++) {
			fd.append("archivo" + i, archivos[i]);
		}

		$http.post('/api/crearArchivos',fd,{
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function (idsImagenes) {
        	cb({
        		id: idsImagenes[0],
        		posicion: indice
        	});
		});
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/votacion/" + $rootScope.consorcio);
	};
});

adm.controller('usersVotacionController', function($scope, $http, $location, $modal, $rootScope, auth){
	auth.esPropietario($rootScope.consorcioCodigo);

	obtenerVotaciones = function(){
		$http.get('/mapi/votosVigentes/' + $rootScope.consorcio).success(function(data){
			$scope.listaVotaciones = data;
		});
	};

	$scope.verVotacion = function(_id){
		var modalInstance = $modal.open({
	      animation: true,//fade
	      templateUrl: 'votacionUsuario.html',
	      controller: 'usersVerVotacionController',
	      size: 'lg',//large
	      resolve: {
		      	id: function () {
					return _id
      			}
      	  	}
    	});
		//EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerVotaciones();
			$location.path("/users/votacion/" + $rootScope.consorcio);
		});
	};

	obtenerVotaciones();
});

adm.controller('usersVerVotacionController', function($scope, $http, $modalInstance, $location, $rootScope, tipoHabitanteFactory, id){
	$scope.verImagenes = [];
	$scope.mostrarOpciones = false;
	$scope.buttonTitle = 'Ver opciones';
	$scope.voto = [];
	$scope.esPropietario = tipoHabitanteFactory.esPropietario();
	var ids = [];

	$http.get('/mapi/votacionDetalle/' + id).success(function(data){
		$scope.votacion = data;
		$scope.votacion.comentario = '';
		$scope.adjuntos = [];

		if(data.tieneImg){
			for(var id = 0; id < data.adjuntosVotacion.length; id++){
				$http.get('/mapi/obtenerImagen/' + data.adjuntosVotacion[id]).success(function(archivo){
					var tipo = ((archivo.imagen.split(';')[0]).split('/')[1]);

					var adjunto = {
						archivo: archivo.imagen,
						imagen: tipo != 'pdf' ? archivo.imagen : '../images/pdf.png'
					};

					$scope.adjuntos.push(adjunto);
				});
			}
		}

		for(var a = 0; a < $scope.votacion.votos.length; a++){
			if($rootScope.globals.currentUser.id == $scope.votacion.votos[a].idUsuario){
				ids.push($scope.votacion.votos[a].idOpcion);
			}
		}

		for(var vts = 0; vts < $scope.votacion.opciones.length; vts++){
			if(ids.indexOf($scope.votacion.opciones[vts].idOpcion) == -1){
				$scope.votacion.opciones[vts].checked = false;
			}
			else{
				$scope.votacion.opciones[vts].checked = true;
				$scope.voto.push($scope.votacion.opciones[vts]);
			}
		}

		for(var i = 0; i < data.opciones.length; i++){
			if(data.opciones[i].imagen != '' && data.opciones[i].imagen != undefined){
				$http.get('/mapi/obtenerImagen/' + data.opciones[i].imagen).success(function(archivo){
					for(var d = 0; d < data.opciones.length; d++){
						if(data.opciones[d].imagen == archivo.idImagen){
							$scope.votacion.opciones[d].imagen = archivo.imagen;
						}
					}
				});
			}
			else{
				$scope.votacion.opciones[i].imagen = '';
			}
		}
	});

	$scope.votar = function(){
		$scope.buttonTitle = 'Cancelar';

		if($scope.mostrarOpciones){
			$scope.mostrarOpciones = false;
			$scope.buttonTitle = 'Ver opciones';
			$scope.voto.length = 0;

			for(var vts = 0; vts < $scope.votacion.opciones.length; vts++){
				if(ids.indexOf($scope.votacion.opciones[vts].idOpcion) == -1){
					$scope.votacion.opciones[vts].checked = false;
				}
				else{
					$scope.votacion.opciones[vts].checked = true;
				}
			}
		}
		else{
			$scope.mostrarOpciones = true;
		}
	};

	$scope.check = function(opcion, index, e){
		//Lo usamos para que aparezca el ícono de la tilde cuando seleccionamos o deseleccinamos.
		if (angular.element(e.currentTarget).prop('tagName') === 'INPUT') {
	        e.stopPropagation();
	    }

		if($scope.voto.indexOf(opcion) != -1){
			$scope.votacion.opciones[index].checked = false;

			$scope.voto.splice($scope.voto.indexOf(opcion), 1);
		}
		else{
			$scope.votacion.opciones[index].checked = true;
			var lote = $rootScope.usuarioLoteSeleccionado != undefined ? $rootScope.usuarioLoteSeleccionado.lote.numero : undefined;
			var dpto = $rootScope.usuarioPisoSeleccionado != undefined ? $rootScope.usuarioPisoSeleccionado.dpto.nombre : undefined;

			$scope.voto.push(opcion);
		}
		//console.log($scope.voto);
	};

	$scope.seleccionar = function(opcion, e){
		//Lo usamos para que aparezca el ícono de la tilde cuando seleccionamos o deseleccinamos.
		if (angular.element(e.currentTarget).prop('tagName') === 'INPUT') {
	        e.stopPropagation();
	    }

		var lote = $rootScope.usuarioLoteSeleccionado != undefined ? $rootScope.usuarioLoteSeleccionado.lote.numero : undefined;
		var dpto = $rootScope.usuarioPisoSeleccionado != undefined ? $rootScope.usuarioPisoSeleccionado.dpto.nombre : undefined;

		$scope.voto.length = 0;
		$scope.voto.push(opcion);
	};

	$scope.comentar = function(comentario){
		var comentario = {
			idVotacion: id,
			idUsuario: $rootScope.globals.currentUser.id,
			comentario: comentario,
			fechaAlta: new Date()
		}
		
		$http.post('/mapi/comentar', comentario).success(function(data){
			$scope.votacion.comentario = '';

			$http.get('/mapi/votacionDetalle/' + id).success(function(data){
				$scope.votacion.comentarios = data.comentarios;
			});
		});
	};

	$scope.enviarVoto = function(opcion){
		var lote = $rootScope.usuarioLoteSeleccionado != undefined ? $rootScope.usuarioLoteSeleccionado.lote.numero : undefined;
		var dpto = $rootScope.usuarioPisoSeleccionado != undefined ? $rootScope.usuarioPisoSeleccionado.dpto.nombre : undefined;
		var votos = [];

		if($scope.voto.length < 2){
			votos.push({
				idOpcion: $scope.voto[0].idOpcion,
				unidad: lote != undefined ? lote : dpto,
				idUsuario: $rootScope.globals.currentUser.id
			});
		}
		else{
			for(var vts = 0; vts < $scope.voto.length; vts++){
				votos.push({
					idOpcion: $scope.voto[vts].idOpcion,
					unidad: lote != undefined ? lote : dpto,
					idUsuario: $rootScope.globals.currentUser.id
				});
			}
		}
		$http.post(server + '/mapi/votar', {votos: votos, idVotacion: id}).success(function(data){
			$modalInstance.close();
		});
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/users/votacion/" + $rootScope.consorcio);
	};
});

adm.factory('votacionFactory', function($http, $rootScope, auth){
	return {
		obtenerVotaciones: function(cb){
			var uri = '';
			if($rootScope.consorcio != 0){
				uri = '/api/votacionesByConsorcioId/' + $rootScope.consorcio;
			}
			else{
				auth.getCurrentUserId(function(idAdministrador){
					uri = '/api/votacionesByAdmin/' + idAdministrador;
				});
			}
			
			$http.get(uri)
		    .success(function(data) {
		    	cb(data);
		    })
		    .error(function(data) {
		    	//console.log('Error obteniendo sugerencias:' + data);
		    	cb([]);
		    });
		}
	}
});