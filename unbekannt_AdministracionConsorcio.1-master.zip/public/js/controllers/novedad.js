adm.controller('novedadController', function ($rootScope, $scope, $modal, $location, $http, $window, auth, novedadFactory, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }

   	$scope.mostrarConsorcio = $rootScope.consorcio == 0;
	$scope.coleccionNovedades = [];
	$scope.row_collection = [];
	$scope.date = new Date();
 	$scope.pageNumber = 1;

    //Popover de ayuda
    var rutaImagenes = '../images/novedades/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Novedades" permite mostrar la lista de novedades que el administrador ha creado.\nDesde el botón "Crear novedad" accedemos a la pantalla de creación de novedades.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla "Nueva novedad" nos permite crear novedades.\nEn esta podemos adjuntar imágenes, escribir texto y seleccionar los consorcios que recibirán dicha novedad.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla de novedad nos permite visualizar los datos de una novedad ya creada.\nPodemos visualizar las imágenes adjuntas de la novedad y ver su contenido.'
            }
        ]
    };
    //End Popover de ayuda
	
	$scope.setPageInfo = function (newPage) {
 		$scope.pageNumber = newPage;
	};

	function loadFilters(){
		auth.getCurrentUserId(function(idAdministrador){
		   	//Períodos disponibles
		   	$scope.filtroAnios = [];
		   	$scope.filtroMeses = [];
		   	$http.get('/api/novedadFiltroAniosByAdmin/' + idAdministrador)
		   	.success(function(data){
		   		$scope.filtroAnios = data;
		   	});
			for (var i = 0; i < 12; i++) {
				$scope.filtroMeses[i] = i + 1;
			};
			//END Periodos disponibles
		});
	}
	
	
	loadFilters();
	
	$scope.waiting = true;

	function ObtenerNovedades() {
		novedadFactory.obtenerNovedades($rootScope.consorcio, function (novedades) {
			$scope.waiting = false;
			$scope.coleccionNovedades = novedades;
			$scope.row_collection = novedades;
		});
	}
	ObtenerNovedades();

    $scope.$on('seleccionarConsorcio', function() {
    	$scope.waiting = true;
    	$scope.coleccionNovedades = [];
		$scope.row_collection = [];
    	novedadFactory.obtenerNovedades($rootScope.consorcio, function(novedades){
    		$scope.waiting = false;
    		$scope.coleccionNovedades = novedades;
    		$scope.row_collection = novedades;
    	});
    	$scope.mostrarConsorcio = $rootScope.consorcio == 0;

    	if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
    
    //ModalInstance - Muestra modal para crear consorcio
    $scope.crearNovedad = function () {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: './views/nuevaNovedad.html',
						      controller: 'modalCrearNovedadController',
						      size: 'lg'
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			ObtenerNovedades();
		});
	};
	//END ModalInstance

    //ModalInstance - Muestra modal para crear consorcio
    $scope.verNovedad = function (_id) {
	    var modalInstance = $modal.open({
						      animation: true,//fade
						      templateUrl: './views/nuevaNovedad.html',
						      controller: 'modalVerNovedadController',
						      size: 'lg',//large
						      resolve: {
							      novedad: function () {
						    	  		for(var i = 0; i < $scope.coleccionNovedades.length; i++)
			                            {
			                              if($scope.coleccionNovedades[i]._id == _id)
			                              {
			                                return $scope.coleccionNovedades[i];
			                              }
			                            }
						      		}
						      }
						    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			ObtenerNovedades();
		});
	};
	//END ModalInstance
});

//Controlador para modalInstance
adm.controller('modalCrearNovedadController', function ($modal, $rootScope, $scope, $cookies, $http, $location, auth, novedadFactory, uploadFileService, $modalInstance) {
	$scope.saving = false;
	$scope.btnEnviar = "Enviar";
	
	auth.getCurrentUserId(function (idAdministrador){
		$scope.idAdministrador = idAdministrador;
	});
	
   	$scope.ObtenerConsorcios = 	function(query){
   		return $http.get('/api/ddlConsorciosByQueryAndAdmin/' + query + "/" + $scope.idAdministrador)
   				.success(function(data){
   					data.unshift({ _id: "0", direccion: "Todos" });
		   			return data;
		   		});
   	}
   	
   	$scope.seleccionarTodos = function(tag){
   		var res = false;
   		if(tag._id == 0){//Serian todos...
   			$scope.consorcios = [];
			auth.getCurrentUserId(function(_id){
				if(_id){
					$http.get('/api/consorciosByAdmin/' + _id)
					.success(function(consorcios){
						if(consorcios.length > 0){
			    			for(var i = 0; i < consorcios.length; i++){
			    				$scope.consorcios.push({ _id: consorcios[i]._id, direccion: consorcios[i].direccion});
			    			}
		    				res =true;
		    			}
						else{
							res = false;
						}
				    });
				}
				else{
					res = false;
				}
		    });
   		}
   		$scope.algo = '';
   		//console.log($scope.consorcios);
   		return res;
   	}
   	
   	$scope.tutorial = function () {
	    var modalInstance = $modal.open({
		  animation: true,//fade
		  templateUrl: 'tutorialWordToPdf.html',
		  controller: 'tutorialWordToPdfController',
		  size: 'lg'//large
		});
	};

   	$scope.consorcios = [];
   	
	if($rootScope.consorcio != 0)
	{
		$http.get('/api/consorcios/' + $rootScope.consorcio)
	    .success(function(consorcio) {
	        $scope.consorcios.push({_id: consorcio._id, direccion: consorcio.direccion });
	    });
    }

	$scope.modalTitle = "Nueva novedad"

	$scope.mostrandoNovedad = false;

	$scope.imagenes = [];
	$scope.verImagenes = [];

	$scope.borrarArchivo = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				$scope.imagenes.splice(i,1);
				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('input').value = "";
	}

	$scope.fileNameChanged = function(ele){

		var tipoValidado = true;
		var tipoValidadoWord = true;

		//console.log(ele.files);

		if(ele.files.length + $scope.imagenes.length > 4)
		{
			alert("A superado la cantidad maxima de adjuntos.\nEl maximo es hasta 4 archivos.")
		} 
		else
		{
			for (var i = 0; i < ele.files.length; i++)
	        {
	        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
	        	{
	        		if (ele.files[i].type.indexOf("word"))
	        		{
	        			tipoValidadoWord = false;
	        		}
	        		tipoValidado = false;
	        	}
	        }

			if (!tipoValidadoWord)
			{
				$scope.tutorial();
			}
			else if (tipoValidado)
			{
		        for (var i = 0; i < ele.files.length; i++)
		        {

		        	$scope.imagenes.push(ele.files[i]);

		        	var reader  = new FileReader();

		        	reader.addEventListener("load",function(event){
		                var picFile = event.target;
		                
		             	$scope.verImagenes.push({
		             								imagen: picFile.result,
		             								nombre: $scope.imagenes[$scope.verImagenes.length].name
		             							});
		             	$scope.$apply();
		            });

		        	reader.readAsDataURL(ele.files[i]);
								
		        	$scope.imagenesCargadas = true;
		        }
		    }
		    else
		    {
		    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
		    }
		}
    };

	$scope.ok = function () {
		
    	if($scope.formNuevaNovedad.$invalid)
		{
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnEnviar = "Enviar";
		}
		else{
			$scope.saving = true;
			$scope.btnEnviar = "Enviando...";

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				
				var fdimagenes = new FormData();

				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}

				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {

					auth.getCurrentUserId(function(_id){
			        	$scope.novedad.usuarioRemitente = _id;
			        });

		    		$scope.novedad.adjuntoNovedad = idsImagenes;
		    		$scope.novedad.tieneImg = true;
					
					$scope.novedad.consorcios = [];
					for(var i = 0; i < $scope.consorcios.length; i++)
					{
						$scope.novedad.consorcios.push($scope.consorcios[i]._id);
					}
					
					$http.post('/api/novedades', { novedad: $scope.novedad});
					$modalInstance.close();
					$scope.subiendoImagenes = false;
					$location.path("/novedad/" +  $rootScope.consorcio);
				});
			}
			else
			{
				$scope.novedad.tieneImg = false;

				auth.getCurrentUserId(function(_id){
		        	$scope.novedad.usuarioRemitente = _id;
		        });
				
				$scope.novedad.consorcios = [];
				for(var i = 0; i < $scope.consorcios.length; i++)
				{
					$scope.novedad.consorcios.push($scope.consorcios[i]._id);
				}
				
				$http.post('/api/novedades', { novedad: $scope.novedad})
				.success(function(){
					$modalInstance.close();
					$location.path("/novedad/" +  $rootScope.consorcio);
				});
			}
    	}
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path("/novedad/" +  $rootScope.consorcio);
	};
});

adm.controller('usersNovedadController', function ($rootScope, $scope, $modal, $http, $location, $interval) {
	function loadFilters(){
		$scope.waiting = true;
	   	//Períodos disponibles
	   	$scope.filtroAnios = [];
	   	$scope.filtroMeses = [];
	   	$http.get('/api/novedadFiltroAniosByAdmin/' + $rootScope.idAdministrador)
	   	.success(function(data){
	   		$scope.waiting = false;
	   		$scope.filtroAnios = data;
	   	});
	   	
		for (var i = 0; i < 12; i++) {
			$scope.filtroMeses[i] = i + 1;
		};
	}
	
	function obtenerNovedades(){
		$scope.waiting = true;
		$http.get('/mapi/novedades/' + $rootScope.consorcio)
		.success(function(novedades){
			$scope.waiting = false;
			$scope.coleccionNovedades = novedades;
			$scope.row_collection = novedades;
		});
	}
	
	loadFilters();
	obtenerNovedades();
	
   $scope.$on('seleccionarConsorcio', function() {   
    	loadFilters();
    	obtenerNovedades();
    });
	
    var intervalPromise =$interval(function(){ obtenerNovedades();	},  30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
    
    $scope.verNovedad = function (_id) {
	    var modalInstance = $modal.open({
		      animation: true,//fade
		      templateUrl: './views/nuevaNovedad.html',
		      controller: 'modalVerNovedadController',
		      size: 'lg',//large
		      resolve: {
			      novedad: function () {
		    	  		for(var i = 0; i < $scope.coleccionNovedades.length; i++)
	                    {
		                      if($scope.coleccionNovedades[i]._id == _id)
		                      {
		                        return angular.copy($scope.coleccionNovedades[i]);
		                      }
	                    }
	      		  }
		      }
	    });
	    
	    //EL Modal se cerró!
		modalInstance.result.then(function () {
			obtenerNovedades();
			loadFilters();
			$location.path("/users/novedad/" + $rootScope.consorcio);
		});
	};
});

adm.controller('modalVerNovedadController', function ($rootScope, $scope, $cookies, $http, $location, auth, uploadFileService, $modalInstance, novedad) {

	$scope.verImagenes = [];
	$scope.verImagenes2 = [];

	$scope.imagenes = [];

	$scope.imagenesEliminadas = [];

	$scope.imagenesCargadas = false;

	$scope.saving = false;
	$scope.btnRepublicar = "Republicar";

	$scope.ObtenerConsorcios = function(query){
   		return $http.get('/api/ddlConsorcios');
   	}
	
    $http.get('/api/ddlConsorcios').success(function(data){ 
	  $scope.consorcios = $.grep(data, function(element, index){
				   					return ($.grep(novedad.consorcios, function(n) { return n._id == element._id; }).length > 0);
							 });
	});
	
    $scope.modalTitle = novedad.asunto;

	$scope.novedad = novedad;
	
	$scope.mostrandoNovedad = true;

	if ($scope.novedad.adjuntoNovedad.length > 0)
	{
		for (var i = 0; i < $scope.novedad.adjuntoNovedad.length; i++)
		{
			$http.get('/api/obtenerArchivoById/' + $scope.novedad.adjuntoNovedad[i])
			.success(function(imagen){
				$scope.verImagenes.push(imagen);
				if($scope.verImagenes.length == $scope.novedad.adjuntoNovedad.length)
				{
					$scope.imagenesCargadas = true;
				}
			})
		}
	}
	else
	{
		$scope.imagenesCargadas = true;
	}

	$scope.republicar = function(){ 
		$scope.mostrandoNovedad = false;
		$scope.btnEnviar = 'Republicar';
	}

	$scope.verImagen = function(){ 
        $scope.viendoImagen = true;
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
    }

    $scope.borrarArchivo = function(lista){
		for (var i = 0; i < lista.length; i++) {
			if(lista[i].active)
			{
				if(lista[i].order)
				{
					$scope.imagenes.splice(lista[i].order,1);
					$scope.verImagenes2.splice(lista[i].order);
				}
				else if (lista[i].id)
				{
					$scope.imagenesEliminadas.push(lista[i].id);
				}

				$scope.verImagenes.splice(i,1);
			}
		};
		document.getElementById('input').value = "";
	}

	$scope.fileNameChanged = function(ele){

		var lista = [];
		var tipoValidado = true;

		if(ele.files.length > 4)
		{
			alert("A superado la cantidad maxima de adjuntos.\nEl maximo es hasta 4 archivos.")
		} 
		else
		{
			for (var i = 0; i < ele.files.length; i++)
	        {
	        	if (ele.files[i].type.indexOf("application/pdf") == -1 && ele.files[i].type.indexOf("image/") == -1)
	        	{
	        		tipoValidado = false;
	        	}
	        }
			
			if (tipoValidado)
			{

		    //     for (var i = 0; i < ele.files.length; i++)
		    //     {
		    //     	$scope.imagenes.push(ele.files[i]);
		    //     	var reader  = new FileReader();

		    //     	reader.addEventListener("load",function(event){
		    //             var picFile = event.target;
		    //             $scope.verImagenes.push({
		    //          		imagen: picFile.result,
						// 	nombre: $scope.imagenes[$scope.verImagenes.length].name
						// });
		    //             lista.push(picFile.result);
		    //          	$scope.$apply();
		    //         });

		    //     	reader.readAsDataURL(ele.files[i]);
								
		    //     	$scope.imagenesCargadas = true;
		    //     }
			    for (var i = 0; i < ele.files.length; i++)
		        {

		        	$scope.imagenes.push(ele.files[i]);

		        	var reader  = new FileReader();

		        	reader.addEventListener("load",function(event){
		        		
		                var picFile = event.target;

		             	$scope.verImagenes2.push({
		             								order: $scope.verImagenes2.length,
		             								imagen: picFile.result,
		             								nombre: $scope.imagenes[$scope.verImagenes2.length].name
		             							});

		        		$scope.verImagenes.push($scope.verImagenes2[$scope.verImagenes2.length-1]);

		        		$scope.imagenes[$scope.verImagenes2.length-1].order = $scope.verImagenes2[$scope.verImagenes2.length-1].order;

		             	$scope.$apply();
		            });

		        	reader.readAsDataURL(ele.files[i]);
		        }

	        	$scope.imagenesCargadas = true;
		    }
		    else
		    {
		    	alert("El tipo de uno o mas de los archivos ingresados no es soportado por la aplicación.\nPor favor, intente nuevamente.");
		    }
		}
    };

	$scope.ok = function () {


		$scope.novedad.adjuntoNovedad = [];
		
    	if($scope.formNuevaNovedad.$invalid)
		{
			$scope.submitted = true;
		
			$scope.saving = false;
			$scope.btnRepublicar = "Republicar";
		}
		else
		{
			//No debemos eliminar las imagenes
			/*for (var i = 0; i < $scope.imagenesEliminadas.length; i++) {

				$http.post('api/eliminarArchivo',{id: $scope.imagenesEliminadas[i]})
				.success(function(data){

				})
				.error(function(data) {
				    //console.log('Error:' + data);
				    $location.path( "/error" );
				    $scope.subiendoImagenes = false;
				});
			}*/

			$scope.saving = true;
			$scope.btnRepublicar = "Republicando...";

    		if ($scope.imagenes.length != 0)
			{
				$scope.subiendoImagenes = true;
				
				var fdimagenes = new FormData() 

				for (var i = 0; i < $scope.imagenes.length; i++) {
					fdimagenes.append("archivo" + i, $scope.imagenes[i]);
				}

				$http.post('/api/crearArchivos',fdimagenes,{
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
				.success(function (idsImagenes) {
					auth.getCurrentUserId(function(_id){
			        	$scope.novedad.usuarioRemitente = _id;
			        	//$scope.novedad.adjuntoNovedad = idsImagenes;
			    		$scope.novedad.tieneImg = true;

			    		for (var i = 0; i < idsImagenes.length; i++)
						{
							$scope.novedad.adjuntoNovedad.push(idsImagenes[i]);
						}

						for (var i = 0; i < $scope.verImagenes.length; i++) {
							if ($scope.verImagenes[i].id)
							{
								$scope.novedad.adjuntoNovedad.push($scope.verImagenes[i].id);
							}
						}
						
						$scope.novedad.consorcios = [];
						for(var i = 0; i < $scope.consorcios.length; i++)
						{
							$scope.novedad.consorcios.push($scope.consorcios[i]._id);
						}
						
						$http.post('/api/novedades', { novedad: $scope.novedad}).success(function(){
							$modalInstance.close();
							$scope.subiendoImagenes = false;
							$location.path( "/novedad/" +  $rootScope.consorcio);
						});
			        });
				});
			}
			else
			{

				if($scope.verImagenes.length > 0)
				{
					for (var i = 0; i < $scope.verImagenes.length; i++) 
					{
						if ($scope.verImagenes[i].id)
						{
							$scope.novedad.adjuntoNovedad.push($scope.verImagenes[i].id);
						}
					}
				}
				else
				{
					$scope.novedad.tieneImg = false;
				}

				auth.getCurrentUserId(function(_id){

		        	$scope.novedad.usuarioRemitente = _id;

		        	$scope.novedad.consorcios = [];

					for(var i = 0; i < $scope.consorcios.length; i++)
					{
						$scope.novedad.consorcios.push($scope.consorcios[i]._id);
					}
					
					$http.post('/api/novedades', { novedad: $scope.novedad}).success(function(){
						$modalInstance.close();
						$location.path( "/novedad/" +  $rootScope.consorcio);
					});
		        });
			}

			$location.path("/novedad/" +  $rootScope.consorcio);
    	}
	};
	
	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path("/novedad/" +  $rootScope.consorcio);
	};

	$scope.eliminar = function () {
		var r = confirm("¿Esta seguro que desea eliminar esta novedad?");
		if (r == true)
		{
		    $http.post('/api/eliminarNovedad/' + $scope.novedad._id)
		    .success(function () {
		    	alert("La novedad ha sido eliminada correctamente");
		    	$modalInstance.close();
		 		$location.path("/novedad/" +  $rootScope.consorcio);
		    })
		}
	};

});

adm.factory('novedadFactory', function($http, auth){
	return{
		obtenerNovedades: function(idConsorcio, coleccionNovedades){
	        if(idConsorcio == 0){
	        	console.log(idConsorcio);
	        	auth.getCurrentUserId(function(idAdministrador){
		            $http.get('/api/novedadesByAdmin/' + idAdministrador)
		            .success(function(novedades) {
		                coleccionNovedades(novedades);
		            })
		            .error(function(novedades) {
		                //console.log('Error obteniendo las novedades! ' + novedades);
		            });
	        	});
	        }
	        else{
	            $http.get('/api/novedadesByConsorcioId/' + idConsorcio)
	            .success(function(novedades) {
	                coleccionNovedades(novedades);
	            })
	            .error(function(novedades) {
	                //console.log('Error obteniendo las novedades! ' + novedades);
	            });
	        }
	   	}
	}
});

adm.filter('aniosReclamo', function(){
	return function(listaNovedades, anios){
		var output = listaNovedades;
		if(anios != '' && anios != undefined && listaNovedades != undefined){
            output = $.grep(listaNovedades, function(item, index){
                        return ((item.fechaAlta != undefined) &&
                                ($.grep(anios, function(anio){
                                	return anio == (new Date(item.fechaAlta).getFullYear());
                                })).length > 0);
                        });
        }

        return output;
	}
});

adm.filter('mesesReclamo', function(){
	return function(listaNovedades, meses){
		var output = listaNovedades;
		if(meses != '' && meses != undefined && listaNovedades != undefined){
            output = $.grep(listaNovedades, function(item, index){
                        return ((item.fechaAlta != undefined) &&
                                ($.grep(meses, function(mes){
                                	return mes == (new Date(item.fechaAlta).getMonth() + 1);
                                })).length > 0);
                        });
        }

        return output;
	}
});