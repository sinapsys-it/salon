adm.controller('contactoController', function($rootScope, $scope, $modal, $modalInstance, $location, $http, auth){
	auth.getUserMail(function(data){
		$scope.contacto = {
			from: data,
			to: '',
			asunto:'',
			mensaje: ''
		};
	});
	
	$scope.ok = function(){
		$http.post('/api/sendContacto', { contacto: $scope.contacto });
		  $modalInstance.dismiss('cancel');
		  $location.path( "/mensaje/" + $rootScope.consorcio );
	}
	
	$scope.cancel = function () {
		  $modalInstance.dismiss('cancel');
		  $location.path( "/mensaje/" + consorcio._id );
	};
});