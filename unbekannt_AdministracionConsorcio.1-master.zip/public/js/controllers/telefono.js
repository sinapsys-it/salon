adm.controller('telefonoController', function ($rootScope, $interval, $scope, $location, $modal, $http, auth, socket) {
    if (angular.isUndefined($rootScope.consorcio)){
        $rootScope.consorcio = 0;
    }
 	$scope.pageNumber = 1;
    $scope.setPageInfo = function (newPage) {
		$scope.pageNumber = newPage;
	};

    //Popover de ayuda
    var rutaImagenes = '../images/telefonos/';

    $scope.dynamicPopover = {
        templateUrl: 'views/templateAyuda.html',
        images: [
            {
                route: rutaImagenes + 'Imagen1.png',
                description: 'La pantalla "Telefonos" permite mostrar la lista de telefenos utiles para el uso común de los inquilinos/propietarios.'
            },
            {
                route: rutaImagenes + 'Imagen2.png',
                description: 'La pantalla telefono nos permite visualizar los detalles del contratista seleccionado.\nEn esta podemos ver el nombre y apellido del contratista, mail, telefono fijo, celular, el consorcio al que esta asignado y la especialidad.'
            },
            {
                route: rutaImagenes + 'Imagen3.png',
                description: 'La pantalla "Nuevo telefono" crear un contratista.\nEn esta podemos ingresar el nombre y apellido del contratista, mail, telefono fijo, celular, el consorcio al que esta asignado y la especialidad.'
            }
        ]
    };

    //End Popover de ayuda
	
	$scope.listaEspecialidades = [];
	$scope.listaConsorcios = [];
	$scope.row_collection = [];
	
	auth.getCurrentUserId(function(idAdministrador){
		$http.get('/api/ddlConsorciosByAdmin/' + idAdministrador)
		.success(function(data){
			$scope.consorcios = data;
			for (var i = 0; i < data.length; i++) {
				$scope.listaConsorcios.push(data[i].direccion);
			};
		});
	});

	auth.getCurrentUserId(function(_id){
		$http.get('/api/especialidades/' + _id)
		.success(function(data){
			for (var i = 0; i < data.length; i++) {
				$scope.listaEspecialidades.push(data[i].nombre);
			};
			$scope.especialidades = data;
		});
	});

    var intervalPromise =$interval(function(){ ObtenerTelefonosByConsorcioId();	},  30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

	function ObtenerTelefonosByConsorcioId(){
		$scope.waiting = true;
		$scope.listaTelefonos = [];
    	$scope.row_collection = [];

		var uri = '';
		if($rootScope.consorcio != 0){
			uri = '/api/telefonoByConsorcioId/' + $rootScope.consorcio;
		}
		else{
			auth.getCurrentUserId(function(idAdministrador){
				uri = '/api/telefonosByAdmin/' + idAdministrador;
			});
		}
		
		$http.get(uri)
	    .success(function(data) {
	    	$scope.listaTelefonos = data;
	    	$scope.row_collection = data;
	    	$scope.waiting = false;
	    })
	    .error(function(data) {
	    	//console.log('Error obteniendo consorcios:' + data);
	    });
	}
	
	ObtenerTelefonosByConsorcioId();
	
	
    $scope.$on('seleccionarConsorcio', function() {   
		ObtenerTelefonosByConsorcioId();

		if($rootScope.consorcio != 0){
    		socket.showNumberEvents();
	    }
    });
    
    $scope.printTelefonos = function(){
    	var $printSection = document.getElementById("printSection");

    	if (!$printSection) {
	        $printSection = document.createElement("div");
        	$printSection.id = "printSection";
        	document.body.appendChild($printSection);
    	}
    	else {    	
    		$printSection.innerHTML = "";
    	}
		
		var table_begin = '<table  class="table table-striped">';
		var table_header = '<thead>' +
										'<tr>' +
									   		'<th style="text-align: left; width: 30%;">Nombre y apellido</th>' +
									   		'<th style="width: 15%;">Teléfono</th>' +
									        '<th style="width: 15%;">Celular</th>' +
									        '<th style="width: 30%;">E-Mail</th>' +
									        '<th style="width: 10%;">Estado</th>' +
									    '</tr>' +
									'</thead>';
		
		var table_body = '<tbody class="nav nav-pills nav-stacked">';
		
		for(var i = 0; i < $scope.row_collection.length; i++){
			var estado = $scope.row_collection[i].activo ? "A" : "I";
			
			table_body +=
				
			"<tr>" +  
				"<td  style=\"width: 30%;\">" + $scope.row_collection[i].nombreApellido + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].telefono + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].celular + "</td>" +
				"<td  style=\"width: 30%;\">" + $scope.row_collection[i].mail + "</td>" +
				"<td  style=\"width: 10%;\">" + estado + "</td>" 
			"</tr>";
		}
		
		
		table_body += "</tbody></table>";
		
		$printSection.innerHTML = table_begin + table_header + table_body;
		window.print();	
		$printSection.remove();
    }
	
	$scope.crearTelefono = function(){
	    var modalInstance = $modal.open({
	        animation: true,
	        templateUrl: './views/nuevoTelefono.html',
	        controller: 'modalTelefonoController',
	        size: 'lg',
	        resolve: {
                listaEspecialidades: function () {
                    return $scope.especialidades;
	            },
	            listaConsorcios: function(){
	                    return $scope.consorcios;
	            }
	        }
	    });
	    
        modalInstance.result.then(function () {
        	ObtenerTelefonosByConsorcioId();
            $location.path( "/telefono/" +  $rootScope.consorcio);
        });
	};

	$scope.editarTelefono = function(telefono){
		var modalInstance = $modal.open({
            animation: true,
            templateUrl: './views/nuevoTelefono.html',
            controller: 'modalEditarTelefonoController',
            size: 'lg',//large
            resolve: {
                      listaEspecialidades: function () {
                              return $scope.especialidades;
                      },
                      listaConsorcios: function(){
                              return $scope.consorcios;
                      },
                      telefono: function(){
                    	  var aux_telefono = angular.copy(telefono);
                    	  aux_telefono.especialidades = [];
                    	  aux_telefono.consorcios = [];
                    	  
                    	  for (var i = 0; i < telefono.especialidades.length; i++) {
                    		  aux_telefono.especialidades.push(telefono.especialidades[i]._id);
                    	  };
                    	  
                    	  for (var i = 0; i < telefono.consorcios.length; i++) {
                    		  aux_telefono.consorcios.push(telefono.consorcios[i]._id);
                    	  };
                    	  
                          return aux_telefono;
                      }
            }
        });
        modalInstance.result.then(function () {
        	ObtenerTelefonosByConsorcioId();
        	$location.path( "/telefono/" +  $rootScope.consorcio);
        });
	};
	
	$scope.eliminar = function(_id){
		$http.post('/api/eliminarTelefono/' + _id)
		.success(function(){
			ObtenerTelefonosByConsorcioId();
		});
	}
});

//Controlador para modalInstance
adm.controller('modalTelefonoController', function ($rootScope, $scope, $http, $window, $location, $modalInstance, listaConsorcios, listaEspecialidades) {
    $scope.modalTitle = "Nuevo teléfono";
    $scope.listaEspecialidades = listaEspecialidades;
    $scope.listaConsorcios = listaConsorcios;
    $scope.submitted = false;
    $scope.saving = false;
	$scope.btnGuardar = "Guardar";

    $scope.$watch('especialidades', function (newValue) {
    	$scope.mostrarEspecialidades = [];
    	if(newValue){
	    	for (var i = 0; i < newValue.length; i++) {
	    		var especialidad = $.grep(listaEspecialidades, function(item){
					return newValue[i] == item._id;
				});
	    		$scope.mostrarEspecialidades.push(especialidad[0]);
	    	};
    	}
	});

	$scope.$watch('consorcios', function (newValue) {
    	$scope.mostrarConsorcios = [];
    	if(newValue){
    		for (var i = 0; i < newValue.length; i++) {
    			var consorcio = $.grep(listaConsorcios, function(item){
    				return newValue[i] == item._id;
    			});
    			$scope.mostrarConsorcios.push(consorcio[0]);
    		};
    	}
	});
    
    $scope.ok = function () {
    	if($scope.formTelefono.$invalid){
    		$scope.submitted = true;
    		
    		$scope.saving = false;
			$scope.btnGuardar = "Guardar";
		}
    	else{
    		$scope.saving = true;
    		$scope.btnGuardar = "Guardando...";

    		$scope.telefono.especialidades = [];
    		$scope.telefono.consorcios = [];    		
    		
    		for(var i = 0; i < $scope.especialidades.length; i++)
			{
    			$scope.telefono.especialidades.push($scope.especialidades[i]);
			}
    		for(var i = 0; i < $scope.consorcios.length; i++)
			{
    			$scope.telefono.consorcios.push($scope.consorcios[i]);
			}

	        $http.post('/api/telefonos', { telefono: $scope.telefono })
	        .success(function(data) {
	            $modalInstance.close();
	            $location.path( "/telefono/" +  $rootScope.consorcio);
	        })
	        .error(function(data) {
	            //console.log('Error:' + data);
	        });
    	}
    };
    $scope.cancel = function () {
      $modalInstance.dismiss('cancel');
      $location.path( "/telefono/" +  $rootScope.consorcio);
    };	
    
});

adm.controller('modalEditarTelefonoController', function ($rootScope, $scope, $http, $window, $location, $modalInstance, listaConsorcios, listaEspecialidades, telefono) {
    $scope.modalTitle = "Edición de teléfono";
    $scope.listaEspecialidades = listaEspecialidades;
    $scope.listaConsorcios = listaConsorcios;
    $scope.submitted = false;
    $scope.isUpdate = true;

    $scope.telefono = telefono;
    $scope.especialidades = telefono.especialidades;
    $scope.consorcios = telefono.consorcios;
    
    $scope.saving = false;
	$scope.btnGuardar = "Guardar";

    $scope.cambiarEstado = function(_id){
    	$http.put('/api/cambiarEstadoTelefono/' + _id)
    	.success(function(data){
			$scope.telefono = data;
    	});
    }

    $scope.$watch('especialidades', function (newValue) {
    	$scope.mostrarEspecialidades = [];
    	for (var i = 0; i < newValue.length; i++) {
    		var especialidad = $.grep(listaEspecialidades, function(item){
				return newValue[i] == item._id;
			});
    		$scope.mostrarEspecialidades.push(especialidad[0]);
    	};
	});

	$scope.$watch('consorcios', function (newValue) {
    	$scope.mostrarConsorcios = [];
    	for (var i = 0; i < newValue.length; i++) {
    		var consorcio = $.grep(listaConsorcios, function(item){
				return newValue[i] == item._id;
			});
    		$scope.mostrarConsorcios.push(consorcio[0]);
    	};
	});

    //CrearConsorcio llama a la API
    $scope.ok = function () {
    	if($scope.formTelefono.$invalid){
    		$scope.submitted = true;
    		
    		$scope.saving = false;
			$scope.btnGuardar = "Guardar";
		}
    	else{
    		$scope.saving = true;
    		$scope.btnGuardar = "Guardando...";
			
    		$scope.telefono.especialidades = [];
			$scope.telefono.consorcios = [];
			
	    	for(var i = 0; i < $scope.especialidades.length; i++)
			{
				$scope.telefono.especialidades.push($scope.especialidades[i]);
			}
			for(var i = 0; i < $scope.consorcios.length; i++)
			{
				$scope.telefono.consorcios.push($scope.consorcios[i]);
			}
			
	        $http.put('/api/updateTelefono/' + telefono._id, { telefono: $scope.telefono })
	        .success(function(data) {
	            $modalInstance.close();
	            $location.path( "/telefono/" +  $rootScope.consorcio);
	        })
	        .error(function(data) {
	            //console.log('Error:' + data);
	            $location.path( "/error" );
	        });
	
	        $location.path( "/telefono/" +  $rootScope.consorcio);
    	}
	};

    $scope.cancel = function () {
    	$modalInstance.close();
    };
});

adm.controller('usersTelefonoController', function ($rootScope, $interval, $scope, $location, $modal, $http, auth) {
	function obtenerTelefonos(){
		$http.get('/mapi/telefonosUtiles/' + $rootScope.consorcio)
		.success(function(telefonos){
			$scope.listaTelefonos = telefonos;
	    	$scope.row_collection = telefonos;
		});
	}

	function ObtenerTelefonosByConsorcioId(){
		$scope.waiting = true;
		$scope.listaTelefonos = [];
    	$scope.row_collection = [];
    	
		var uri = '';
		if($rootScope.consorcio != 0){
			uri = '/api/telefonoByConsorcioId/' + $rootScope.consorcio;
		}
		else{
			auth.getCurrentUserId(function(idAdministrador){
				uri = '/api/telefonosByAdmin/' + idAdministrador;
			});
		}
		
		$http.get(uri)
	    .success(function(data) {
	    	$scope.listaTelefonos = data;
	    	$scope.row_collection = data;
	    	$scope.waiting = false;
	    })
	    .error(function(data) {
	    	//console.log('Error obteniendo consorcios:' + data);
	    });
	}
	
	function obtenerEspecialidades(){
		$scope.listaEspecialidades = [];
		
		$http.get('/api/especialidades/' + $rootScope.idAdministrador)
		.success(function(data){
			for (var i = 0; i < data.length; i++) {
				$scope.listaEspecialidades.push(data[i].nombre);
			};
			$scope.especialidades = data;
		});
	}
	
	obtenerTelefonos();
	obtenerEspecialidades();
	
	$scope.$on('seleccionarConsorcio', function() {   
		obtenerTelefonos();
		obtenerEspecialidades();
	});
	
    var intervalPromise =$interval(function(){ obtenerTelefonos();	},  30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
	
	$scope.editarTelefono = function(telefono){
		var modalInstance = $modal.open({
            animation: true,
            templateUrl: './views/nuevoTelefono.html',
            controller: 'modalEditarTelefonoController',
            size: 'lg',//large
            resolve: {
                      listaEspecialidades: function () {
                              return $scope.especialidades;
                      },
                      listaConsorcios: function(){
                              return [];
                      },
                      telefono: function(){
                    	  var aux_telefono = angular.copy(telefono);
                    	  aux_telefono.especialidades = [];
                    	  aux_telefono.consorcios = [];
                    	  
                    	  for (var i = 0; i < telefono.especialidades.length; i++) {
                    		  aux_telefono.especialidades.push(telefono.especialidades[i]._id);
                    	  };
                    	  
                          return aux_telefono;
                      }
            }
        });
        modalInstance.result.then(function () {
        	ObtenerTelefonosByConsorcioId();
        	$location.path( "/users/telefono/" +  $rootScope.consorcio);
        });
	};
	
	$scope.printTelefonos = function(){
    	var $printSection = document.getElementById("printSection");

    	if (!$printSection) {
	        $printSection = document.createElement("div");
        	$printSection.id = "printSection";
        	document.body.appendChild($printSection);
    	}
    	else {    	
    		$printSection.innerHTML = "";
    	}
		
		var table_begin = '<table  class="table table-striped">';
		var table_header = '<thead>' +
										'<tr>' +
									   		'<th style="text-align: left; width: 30%;">Nombre y apellido</th>' +
									   		'<th style="width: 15%;">Teléfono</th>' +
									        '<th style="width: 15%;">Celular</th>' +
									        '<th style="width: 30%;">E-Mail</th>' +
									    '</tr>' +
									'</thead>';
		
		var table_body = '<tbody class="nav nav-pills nav-stacked">';
		
		for(var i = 0; i < $scope.row_collection.length; i++){
			table_body +=
			"<tr>" +  
				"<td  style=\"width: 30%;\">" + $scope.row_collection[i].nombreApellido + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].telefono + "</td>" +
				"<td  style=\"width: 15%;\">" + $scope.row_collection[i].celular + "</td>" +
				"<td  style=\"width: 30%;\">" + $scope.row_collection[i].mail + "</td>" +
			"</tr>";
		}
		
		
		table_body += "</tbody></table>";
		
		$printSection.innerHTML = table_begin + table_header + table_body;
		window.print();	
		$printSection.remove();
    }
});

adm.filter('especialidades',function() {
	return function(listaTelefonos, especialidades){
		var output = listaTelefonos;
		if(especialidades != '' && especialidades != undefined && listaTelefonos != undefined){
			output = $.grep(listaTelefonos, function(telefono){
						return	($.grep(telefono.especialidades, function(especialidad){
									return ($.grep(especialidades, function(e){ return e == especialidad }).length > 0);
								}).length > 0);
				 	});
		}

	    return output;
	}
});

adm.filter('consorcios',function() {
	return function(listaTelefonos, consorcios){
		var output = listaTelefonos;
		if(consorcios != '' && consorcios != undefined && listaTelefonos != undefined){
			output = $.grep(listaTelefonos, function(telefono){
						return	($.grep(telefono.consorcios, function(consorcio){
									return ($.grep(consorcios, function(e){ return e == consorcio }).length > 0);
								}).length > 0);
				 	});
		}

	    return output;
	}
});

adm.filter('especialistas', function(){
	return function(listaTelefonos, txtNombreApellido){
		var output = listaTelefonos;
		if(txtNombreApellido != '' && txtNombreApellido != undefined && listaTelefonos != undefined){
			output = $.grep(listaTelefonos, function(telefono){
						return (telefono.nombreApellido.replace(' ', '').toUpperCase().indexOf(txtNombreApellido.replace(' ', '').toUpperCase()) > -1);
					 });
		}

	    return output;
	}
});
