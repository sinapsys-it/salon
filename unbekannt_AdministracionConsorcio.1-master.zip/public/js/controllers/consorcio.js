adm.controller('consorcioController', function ($rootScope, $window, $scope, $modal, $location, $http, auth, consorcioFactory, socket) {
	/*Inicializa cantidad de pisos y deptos disponible para seleccionar*/
	$scope.maxPisos = 60;
	$scope.maxDeptos = 10;

	function ObtenerConsorcios(){
		if($rootScope.globals.currentUser.isAdmin){
			consorcioFactory.obtenerConsorciosByAdmin($rootScope.globals.currentUser.id, function(consorcios){
				$scope.coleccionConsorcios = consorcios;
				$scope.tituloConsorcio();

				//Seteamos la clase a los "li" para los consorcios con nuevos eventos
				if(parseInt(localStorage.getItem('login')) == 1){
				    for(var x = 0; x < $scope.coleccionConsorcios.length; x++){
						for(var y = 0; y < localStorage.getItem('idsConsorcios').split(',').length; y++){
							if($scope.coleccionConsorcios[x]._id == localStorage.getItem('idsConsorcios').split(',')[y]){
								$scope.coleccionConsorcios[x].oNuevoReclamo = 'nuevoEvento';
							}
						}
					}
				}
			});
		}
		else{
			$http.get('/mapi/getMisConsorcios?idUsuario=' + $rootScope.globals.currentUser.id)
			.success(function(consorcios){
				$scope.coleccionConsorcios = consorcios;
				$scope.filtrarBandeja(consorcios[0]._id, consorcios[0].codigo, consorcios[0].administrador);
				$rootScope.consorcioUnidad = [];
				
				for(var i=0; i < consorcios.length; i++){
					if(consorcios[i].lotes.length){
						for(var l=0; l < consorcios[i].lotes.length; l++){
							for(var p=0; p < consorcios[i].lotes[l].propietarios.length; p++){
								if(consorcios[i].lotes[l].propietarios[p].idUsuario == $rootScope.globals.currentUser.id){
									$rootScope.consorcioUnidad.push(consorcios[i].lotes[l]);
								}
							}
						}
						
						consorcios[i].lotes = [];
						consorcios[i].lotes = cosnsorcios[i].lotes.concat($rootScope.consorcioUnidad);
						$rootScope.consorcioUnidad= [];
					}
					else{
						for(var pi=0; pi < consorcios[i].pisos.length; pi++){
							for(var d=0; d < consorcios[i].pisos[pi].deptos.length; d++){
								for(var p=0; p < consorcios[i].pisos[pi].deptos[d].propietarios.length; p++){
									if(consorcios[i].pisos[pi].deptos[d].propietarios[p].idUsuario == $rootScope.globals.currentUser.id){
										$rootScope.consorcioUnidad.push({ numero: consorcios[i].pisos[pi].numero,
																							_id: consorcios[i].pisos[pi]._id , 
																							depto: {
																								nombre: consorcios[i].pisos[pi].deptos[d].nombre, 
																								codigo: consorcios[i].pisos[pi].deptos[d].codigo
																							}});
										
										break;
									}
								}
							}
						}
						consorcios[i].pisos = [];
						consorcios[i].pisos = consorcios[i].pisos.concat($rootScope.consorcioUnidad);
						$rootScope.consorcioUnidad= [];
					}
				}
				
				$scope.coleccionConsorcios = consorcios;
				$scope.filtrarBandeja(consorcios[0]._id, consorcios[0].codigo, consorcios[0].administrador, consorcios[0].lotes, consorcios[0].pisos);
			});
		}
    }
    
    $scope.filtrarBandeja = function(_id, codigo, administrador, lotes, pisos, index){
    	$scope.tituloConsorcio();

        if(codigo && administrador){
            $rootScope.consorcioCodigo = codigo;
            $rootScope.idAdministrador = administrador._id;
            $rootScope.nombreAdministrador = administrador.nombreApellido;
        }

        $rootScope.usuarioLoteSeleccionado = undefined;
        $rootScope.usuarioPisoSeleccionado = undefined;
        
        if(lotes && lotes.length){
        	$rootScope.usuarioLoteSeleccionado = { lote: { numero: lotes[0].numero } };
        }
        if(pisos && pisos.length){
        	$rootScope.usuarioPisoSeleccionado = { piso: { numero: pisos[0].numero, dpto: { nombre: pisos[0].depto.nombre } }};
        }
    	
    	$rootScope.consorcio = _id;
        $window.sessionStorage.consorcio = _id;
        $rootScope.$broadcast("seleccionarConsorcio");

        //Validamos que no se haya seleccionado el item "Todos"
        if($scope.coleccionConsorcios[index] != undefined){
        	$scope.coleccionConsorcios[index].oNuevoReclamo = '';

        	var array = localStorage.getItem('idsConsorcios').split(',');
        	var i = array.indexOf(_id);
        	array.splice(i, 1);
        	localStorage.setItem('idsConsorcios', array);

        	$rootScope.showEvents = true;
        }
        else{
        	$rootScope.showEvents = false;
        }
    };

    $scope.tituloConsorcio = function(){
    	var todos = true;
        for (var i = 0; i < $scope.coleccionConsorcios.length; i++) {
        	if ($scope.coleccionConsorcios[i].active) 
        	{
       			$rootScope.consorcioNombre = $scope.coleccionConsorcios[i].direccion;
       			todos = false;
        	}
        }
        if (todos)
        {
        	$rootScope.consorcioNombre = "Todos"
        }
    }
    
    ObtenerConsorcios();

    $scope.crearConsorcio = function () {
		var modalInstance = $modal.open({
			  animation: true,//fade
			  templateUrl: './views/nuevoConsorcio.html',
			  controller: 'modalCrearConsorcioController',
			  size: 'lg',//large
			  resolve: {
			  		maxPisos: function(){
			  			return $scope.maxPisos;
			  		},
			  		maxDeptos: function(){
			  			return $scope.maxDeptos;
			  		},
			  		consorcioSeleccionado: function(){
			  			return $rootScope.consorcio;
			  		}
			  }
	    });

		//EL Modal se cerró!
		modalInstance.result.then(function () {
		   	ObtenerConsorcios();
		});
	}
	
    $scope.editarConsorcio = function(_id){
    	$http.get('/api/consorcios/' + _id)
    	.success(function(consorcio_data){
    		var modalInstance = $modal.open({
    			animation: true,//fade
    			templateUrl: './views/nuevoConsorcio.html',
    			controller: 'modalEditarConsorcioController',
    			size: 'lg',//large
    			resolve: {
    				consorcio: function () {
    					return consorcio_data;
    				}
    			}
    		});
    		
    		//EL Modal se cerró!
    		modalInstance.result.then(function () {
    			//console.log("traigo consorcios");
				ObtenerConsorcios();
    		});
    	});
    }

    $scope.registrarConsorcio = function () {
		var modalInstance = $modal.open({
			animation: true,//fade
			templateUrl: './views/registrarConsorcio.html',
			controller: 'userModalRegistrarConsorcioController',
			size: 'lg',//large
			resolve: {
				consorcio: function(){
					return $rootScope.consorcio;
				}
			}
	    });

		//EL Modal se cerró!
		modalInstance.result.then(function () {
		   	ObtenerConsorcios();
			$location.path( "/users/mensaje/" + $rootScope.consorcio );
		});
	}

	socket.on('oNuevoReclamo', function(data){
		socket.updateEvents(data.idConsorcio, 1, 0, 0);
		setCssNewEvent(data);
	});

	socket.on('oNuevoMensaje', function(data){
		socket.updateEvents(data.idConsorcio, 0, 1, 0);
		setCssNewEvent(data);
	});

	socket.on('oNuevoPago', function(data){
		socket.updateEvents(data.idConsorcio, 0, 0, 1);
		setCssNewEvent(data);
	});

	function setCssNewEvent(data_aux){
		for(var x = 0; x < $scope.coleccionConsorcios.length; x++){
			if($scope.coleccionConsorcios[x]._id == data_aux.idConsorcio){
				$scope.coleccionConsorcios[x].oNuevoReclamo = 'nuevoEvento';
				$scope.$apply();
			}
		}

		var array = [];
		array.push(data_aux.idConsorcio);

		for(var x = 0; x < localStorage.getItem('idsConsorcios').split(',').length; x++){
			array.push(localStorage.getItem('idsConsorcios').split(',')[x]);
		}

		localStorage.setItem('idsConsorcios', array);
	}

	//Listado de ids para conteo inicial de eventos por consorcios
	var idsConsorcios = [];

	$scope.countEvents = function(idConsorcio, index){
		idsConsorcios.push(idConsorcio);

		if(idsConsorcios.length == $scope.coleccionConsorcios.length && parseInt(localStorage.getItem('login')) == 0){
			$http.get('/api/countEvents/' + idsConsorcios).success(function(data){
				idsConsorcios.length = 0;
				localStorage.setItem('events', JSON.stringify(data));

				for(var x = 0; x < $scope.coleccionConsorcios.length; x++){
					for(var y = 0; y < data.length; y++){
						if($scope.coleccionConsorcios[x]._id == data[y].idConsorcio && data[y].total > 0){
							$scope.coleccionConsorcios[x].oNuevoReclamo = 'nuevoEvento';
							idsConsorcios.push($scope.coleccionConsorcios[x]._id);
						}
					}
				}

				localStorage.setItem('idsConsorcios', idsConsorcios);
				localStorage.setItem('login', 1);
			});
		}
	}
});

adm.controller('modalCrearConsorcioController', function ($scope, $modal, $location, $modalInstance, $http, auth, maxDeptos, maxPisos, consorcioSeleccionado, consorcioFactory) {
	$scope.autoFillType = 'M';
	$scope.formaspago = '';
	$scope.btnGuardar = "Guardar";
	$scope.saving = false;
	
	function saveConsorcio(unConsorcio){
    	$http.post('/api/consorcios', { consorcio: unConsorcio })
		.success(function(data) {
			$modalInstance.close(function(){
				$scope.coleccionConsorcios = consorcioFactory.filterByAdministrador(unConsorcio.administrador, $scope.coleccionConsorcios);
			});
			$location.path( "/mensaje/" + consorcioSeleccionado);
		});
	}
	
	//Controlador para modalInstance
	$scope.select ={
		ddlPisos: '',
		ddlDeptos: ''
	}
	
	var r = new Random();
	
	$scope.maxPisos = maxPisos;
	$scope.maxDeptos = maxDeptos;
	
	$scope.crearConsorcio = true;
	$scope.modalTitle = "Nuevo consorcio";
	
	$scope.dibujarLocales = function(cantLocales){
		consorcioFactory.dibujarLocales($scope.consorcio, cantLocales);
		consorcioFactory.fillDeptos($scope.consorcio, $scope.autoFillType);
	}
	
	$scope.dibujarPisos = function(cantPisos, cantDeptos){
		consorcioFactory.dibujarPisos($scope.consorcio, cantPisos, cantDeptos);
		consorcioFactory.fillDeptos($scope.consorcio, $scope.autoFillType);
	}
	
	$scope.dibujarDeptos = function(cantPisos, cantDeptos){
		consorcioFactory.dibujarDeptos($scope.consorcio, cantPisos, cantDeptos);
		consorcioFactory.fillDeptos($scope.consorcio, $scope.autoFillType);
	}
	
	$scope.resetLocales = function(checked){
		if(!checked){
			$scope.consorcio.locales = "";
			if($.grep($scope.consorcio.pisos, function(piso){return piso.numero == 0;}).length > 0){
				$scope.consorcio.pisos.splice(0,1);
			}
		}
	}
	
	//Obtiene las formas de pago existentes	
	$scope.listaFormasPago = [];
	auth.getCurrentUserId(function(_id){
		$http.get('/api/ddlFormaspagos/' + _id)
	    .success(function(data) {
	    	$scope.listaFormasPago = data;
	    })
	    .error(function(data) {
	        ////console.log('Error obteniendo consorcios:' + data);
	    });
	});
    
    /*Inicializa imagen para nuevo consorcio*/
	$scope.firstImage = "../images/no_consorcio_image.png";
	$scope.consorcio = { 
		codigo: '',
		formaspago: [],
		tipo: 'D',
		pisos: [],
		lotes: '',
	 };
	
	$scope.setFileName = function(elem){
		$scope.fileName = "";
		$scope.fileName = elem.files[0].name;
		
		if (elem.files && elem.files[0]) {
			var reader = new FileReader();
			
			reader.onload = function (e) {
				$scope.firstImage = e.target.result;
				$scope.$apply();
			}
			
			reader.readAsDataURL(elem.files[0]);
		}
	}
	
	$scope.resetDeptoControllers = function(){
		$scope.select.ddlPisos = '';
		$scope.select.ddlDeptos = '';
		$scope.consorcio.pisos = [];
		$scope.consorcio.locales = '';
		$scope.chkLocales = false;
	}
	
	$scope.autoFill = function(value){
		$scope.autoFillType = value;
		consorcioFactory.fillDeptos($scope.consorcio, value);
	}

  	//CrearConsorcio llama a la API
	$scope.ok = function () {
		if($scope.formConsorcio.$invalid){
			$scope.submitted = true;
			
			$scope.saving = false;
			$scope.btnGuardar = "Guardar";
		}
		else{
			$scope.saving = true;
			$scope.btnGuardar = "Guardando...";
			
			auth.getCurrentUserId(function(_id){
				$scope.consorcio.administrador = _id;

				//Genero los lotes según los datos!
				/*var auxLotesArray = [];

		        for(var i = 1; i <= $scope.consorcio.lotes;i++){	        	
		        	auxLotesArray.push({ numero: i, codigo: r.hex(3).toUpperCase()});
		        }
		        $scope.consorcio.lotes = auxLotesArray;*/

		        //Genero formas de pago según los datos!
		        $scope.consorcio.formaspago = [];
	    		for(var i = 0; i < $scope.formConsorcio.formaspago.$viewValue.length; i++)
				{
	    			$scope.consorcio.formaspago.push($scope.formConsorcio.formaspago.$viewValue[i]);
				}
				
	    		if ($scope.consorcio.imagen != undefined)
				{
		    		//Genero el formData para almacenar el consorcio
		    		var fd = new FormData();
					fd.append('file', $scope.consorcio.imagen);

					$http.post('/api/crearArchivos/', fd, {
			            transformRequest: angular.identity,
			            headers: {'Content-Type': undefined}
			        })
			        .success(function(data){
			        	$scope.consorcio.imagen = data[0];
			        	saveConsorcio($scope.consorcio);
			        });
			    }
	    		else{
    				saveConsorcio($scope.consorcio);
	    		}
			});
		}
	}
    
	$scope.cancel = function () {
	  $modalInstance.dismiss('cancel');
	  $location.path( "/mensaje/" + consorcioSeleccionado );
	}
}).directive('uniqueConsorcio', ["$http", "auth", function ($http, auth) {
	  return {
		    require:'ngModel',
		    restrict:'A',
		    link:function (scope, el, attrs, ngModel) {
		    	ngModel.$parsers.push(function (viewValue) {
		        if (viewValue) {
		        	auth.getCurrentUserId(function(_id){
			          $http.get('/api/verifyUniqueConsorcioAddress/' + viewValue + '/' + _id)
			          .success(function(data){
			        	  if(data == true){
			        		  ngModel.$setValidity('uniqueConsorcio', true);
			        		  //console.log(ngModel);
			        	  }
			        	  else{
			        		  ngModel.$setValidity('uniqueConsorcio', false);
			        	  }
			        	  return viewValue;
			          });
		        	});
		        }
		        return viewValue;
		      });
		    }
	  	};
}]);

adm.controller('modalEditarConsorcioController', function ($rootScope, $scope, $http, $window, $location, uploadFileService, auth, $modalInstance, consorcio, consorcioFactory) {
	$scope.modalTitle = "Editar consorcio";
	$scope.consorcio = consorcio;
	$scope.formaspago = [];
	$scope.btnGuardar = "Guardar";
	$scope.firstImage = "../images/no_consorcio_image.png";
	$scope.mostrarUF = false;
	$scope.btnShowUF = "Mostrar Unidades Func.";
	$scope.crearConsorcio = false;
	
	$scope.autoFill = function(value){
		$scope.autoFillType = value;
		consorcioFactory.fillDeptos($scope.consorcio, value);
	}
	
	$scope.UFOn= function(){
		if(!$scope.consorcio.pisos && !$scope.consorcio.lotes){
			$scope.getDetalle();
		}
		$scope.mostrarUF = true;	
		$scope.btnShowUF = "Ocultar Unidades Func.";
	}
	
	$scope.UFOff = function(){
		$scope.mostrarUF = false;	
		$scope.btnShowUF = "Mostrar Unidades Func.";
	}
	
	$scope.getDetalle = function(){
		if(!$scope.consorcio.pisos && !$scope.consorcio.lotes){
			$scope.waitingDetalles = true;
			$http.get('/api/getDetalleConsorcio/' + $scope.consorcio._id)
			.success(function(data){
				$scope.waitingDetalles = false;
				$scope.consorcio.pisos = data.pisos;
				$scope.consorcio.lotes = data.lotes;
			});
		}
	}
	
	auth.getCurrentUserId(function(_id){
		$http.get('/api/ddlFormaspagos/' + _id)
		.success(function(data) {
			$scope.listaFormasPago = data;
			for(var i = 0; i < consorcio.formaspago.length;i++){
				$scope.formaspago.push(consorcio.formaspago[i]._id);
		    }
		});
	});
	
	if($scope.consorcio.imagen != undefined)
	{
		$http.get('/api/obtenerArchivoById/' + $scope.consorcio.imagen + '?' + (new Date()).getTime())
		.success(function(archivo){
			if(archivo != null && archivo != undefined && archivo != ''){
				$scope.firstImage = archivo.imagen;
			}
			else{
				$scope.firstImage = "../images/no_consorcio_image.png";
			}
		});
	}
	
	$scope.tieneDeptos = function(piso){
		return $.grep(piso.deptos, function(depto){
			return depto.nombre != '';
		}).length > 0;
	}
	
	//CrearConsorcio llama a la API
	$scope.ok = function () {
		if($scope.formConsorcio.$invalid){
			$scope.submitted = true;
			$scope.saving = false;
			$scope.btnGuardar = "Guardar";
		}
		else{
			$scope.saving = true;
			$scope.btnGuardar = "Guardando...";
			
			//Genero formas de pago según los datos!
	        $scope.consorcio.formaspago = [];
			for(var i = 0; i < $scope.formConsorcio.formaspago.$viewValue.length; i++)
			{
				$scope.consorcio.formaspago.push($scope.formConsorcio.formaspago.$viewValue[i]);
			}
			
			function updateConsorcio(consorcio){
				$http.put('/api/updateConsorcio/' + consorcio._id, { consorcio: consorcio })
				.success(function(data) {
					 $modalInstance.close();		
				});
			}
			
			if($scope.fileName && $scope.consorcio.imagen != '' && $scope.consorcio.imagen != undefined){//Se cargó una foto para el consorcio
				var fd = new FormData();
				fd.append('file', $scope.consorcio.imagen);
			
				$http.post('/api/crearArchivos/', fd, {
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
		        .success(function(data) {
		        	$scope.consorcio.imagen = data[0];
		        	updateConsorcio($scope.consorcio);
		        });
			}
			else{//La foto del consorcio no cambió
				updateConsorcio($scope.consorcio);
			}
		}
	};
	
	$scope.cancel = function () {
		  $modalInstance.close();
	};
	
	$scope.setFileName = function(elem){
		$scope.fileName = "";
		$scope.fileName = elem.files[0].name;
		
		if (elem.files && elem.files[0]) {
			var reader = new FileReader();
			
			reader.onload = function (e) {
				$scope.firstImage = e.target.result;
				$scope.$apply();
			}
			
			reader.readAsDataURL(elem.files[0]);
		}
	}

	$scope.verImagen = function(){ 
        $scope.viendoImagen = true;
    }

    $scope.cerrarImagen = function(){
        $scope.viendoImagen = false;
    }
});

adm.factory("consorcioFactory", function($http, $cookieStore, $location, $rootScope, base64){
	var r = new Random();

	return {//Los locales se dibujan cada vez que el contador cambia (siempre la diferencia es uno)
		dibujarLocales: function(consorcio, localesCount){
			////console.log("localesCount... " + localesCount)
			if(localesCount == undefined){
				return false;
			}
			
			var locales  = $.grep(consorcio.pisos, function(piso){
				return (piso.numero == 0);
			});
			
			//Si existen locales, el indice es 1!
			var startIndex = 0; 
			if(locales != ''){
				startIndex = 1;
			}
			
			var deptos_array = [];
			////console.log("Buscando el piso con locales... ");
			
			if(locales != ''){//Existe el piso 0 (de locales)?
				piso_temp = locales[0];
				////console.log("Encontré el piso con locales..." + JSON.stringify(piso_temp));
				/* Agrego tantos deptos como me indique el contador de locales
				 * localesCount < piso_temp.deptos.length => estoy quitando  locales 
			 	 * localesCount > piso_temp.deptos.length => estoy agregando locales
				 */
				if(localesCount < piso_temp.deptos.length){
					for(j = consorcio.pisos[0].deptos.length; j > localesCount; j--){
		    			consorcio.pisos[0].deptos.splice(j - 1, 1);
					}
					if(localesCount == 0){
						consorcio.pisos.splice(0, 1);
					}
				}
				else{
					for(var d = consorcio.pisos[0].deptos.length; d < localesCount; d++){
						var depto_temp = { 'nombre': '', 'codigo': r.hex(3).toUpperCase(), 'propietarios': [] };
						consorcio.pisos[0].deptos.push(depto_temp);
					}
				}
			}
			else{//No existen locales!
				////console.log("No encontré el piso con locales...");
				/*Agrego un piso previo a todos, para los locales que posea el consorcio*/
				piso_temp  = { 'numero': 0, 'deptos': [] };
				
				/*Agrego tantos deptos como me indique el contador de locales*/
				for(var d = 0; d < localesCount; d++){
					var depto_temp = { 'nombre': '', 'codigo': r.hex(3).toUpperCase(), 'propietarios': [] };
					piso_temp.deptos.push(depto_temp);
				}

				consorcio.pisos.unshift(piso_temp);
			}
			
		},
		dibujarDeptos: function(consorcio, pisosCount, deptosCount){
	    	var depto_temp = null;
	    	
	    	var locales  = $.grep(consorcio.pisos, function(piso){
	    		return (piso.numero == 0);
	    	});
	    	
	    	//Si existen locales, el indice es 1!
	    	var startIndex = 0; 
	    	if(locales != ''){
	    		startIndex = 1;
	    	}
	    	
	    	//Evalúo si estoy borrando deptos o agregando deptos
	    	if(consorcio.pisos != "" && deptosCount > consorcio.pisos[startIndex].deptos.length){
	    		//Agrego departamentos a todos los pisos
	    		for (var i = startIndex; i < consorcio.pisos.length; i++){
	    			for (var j = consorcio.pisos[i].deptos.length; j < deptosCount; j++){
		    			depto_temp = { 'nombre': '', 'codigo': r.hex(3).toUpperCase(), 'propietarios': [] };
		    			consorcio.pisos[i].deptos.push(depto_temp);
	    			}
		    	}
	    	}
	    	else{
	    		//Estoy borrando deptos a todos los pisos
	    		////console.log("Borrando depto...");
	    		////console.log(parseInt(startIndex));
	    		for (var i = parseInt(startIndex); i < (parseInt(pisosCount) + parseInt(startIndex)); i++){
	    			for(var j = consorcio.pisos[i].deptos.length; j > deptosCount; j--){
	    				////console.log(j);
	    				consorcio.pisos[i].deptos.splice(j - 1, 1);
	    			}
		    	}
	    	}
		},
	    dibujarPisos: function(consorcio, pisosCount, deptosCount){
	    	var depto_temp = null;
	    	var deptos_array = [];
	    	var startIndex = 0; 
	    	var locales = [];
	    	
	    	if(deptosCount == undefined){
	    		deptosCount = 0;
	    	}
	    	
	    	locales = $.grep(consorcio.pisos, function(piso){
	    		return (piso.numero == 0);
	    	});
	    	//Si existen locales, el indice es 1!
	    	if(locales != ''){
	    		startIndex = 1;
	    	}
	    	
	    	////console.log("PisosCount: " + pisosCount);
	    	////console.log("Pisos en el consorcio...cuántos?: ", consorcio.pisos.length);
	    	
	    	//Evalúo si estoy borrando pisos o agregando pisos!
	    	if(parseInt(pisosCount) + parseInt(startIndex) < parseInt(consorcio.pisos.length)){
	    		//Estoy borrando pisos!
	    		for(var j = consorcio.pisos.length; j > parseInt(pisosCount) + parseInt(startIndex); j--){
	    			consorcio.pisos.splice(j - 1, 1);
				}
	    	}
	    	else{
	    		//Estoy agregando pisos!
	    		for (var i = consorcio.pisos.length; i < parseInt(pisosCount) + parseInt(startIndex); i++){
	    			////console.log("Start index... : " + startIndex);
	    			deptos_array = [];
		    		for(var j = 0; j < deptosCount; j++){
		    			depto_temp = { 'nombre': '', 'codigo': r.hex(3).toUpperCase(), 'propietarios': [] };
		    			deptos_array.push(depto_temp);
		    		}
		    		
		    		//Inserto coleccion de departamentos
		    		consorcio.pisos.push({ 'numero': i + 1 - parseInt(startIndex), 'deptos': deptos_array });
		    	}
	    	}
	    },
	    obtenerConsorciosByAdmin: function(_id, consorcios){
			$http.get('/api/consorciosByAdmin/' + _id)
			.success(function(data){
				for(var i = 0; i < data.length; i++){
					data[i].active = data[i]._id == $rootScope.consorcio;
				}
				consorcios(data);
			});
			////console.log("Hola");
		},
		fillDeptos: function(consorcio, value){ 
			switch(value){
				case 'M':
					for(var p=0; p < consorcio.pisos.length; p++){
						for(var d=0; d < consorcio.pisos[p].deptos.length; d++){
							var index = d;
							if(d > 22){
								index = d - 23;
							}
							consorcio.pisos[p].deptos[d].nombre = "";
						}
					}
					break;
				case 'L':
					var letters = base64.keyStr.slice(0,26);
					for(var p=0; p < consorcio.pisos.length; p++){
						for(var d=0; d < consorcio.pisos[p].deptos.length; d++){
							var index = d;
							if(d > 22){
								index = d - 23;
							}
							consorcio.pisos[p].deptos[d].nombre = letters[d];
						}
					}
					break;
				case 'N':
					for(var p=0; p < consorcio.pisos.length; p++){
						for(var d=0; d < consorcio.pisos[p].deptos.length; d++){
							consorcio.pisos[p].deptos[d].nombre = d + 1;
						}
					}
					break;
			}
		}
	}
});

adm.controller('userModalRegistrarConsorcioController', function($scope, $modalInstance, $location, consorcio, $rootScope, $http){
	$scope.propietario = true;

	$scope.ok = function(){
		$scope.existe = false;
		$scope.incorrecto = false;

		var codigos = $scope.codigoDptoLote.slice(0, 5) + ',' + $scope.codigoDptoLote.slice(5, 8);

		$http.get('/mapi/verificarConsorcioWeb/' + codigos + '/' + $rootScope.globals.currentUser.id).success(function (data) {
			if(data.length != 0){
				if(data.length == 1){
					var datos = {
						_id: $rootScope.globals.currentUser.id,
						tipo: $scope.propietario ? 'Propietario' : 'Inquilino',
						descripcion: $scope.propietario ? 'Propietario' : 'Inquilino',
						codigo: $scope.codigoDptoLote.substr(0, 5),
						codigoDptoLote: $scope.codigoDptoLote.substr(5, 8),
						fechaAlta: new Date,
						fechaBaja: ""
					};

					$http.post('/mapi/registroUsuario', {datos: datos, usuarioExiste: 'true'}).success(function(data){
						$modalInstance.close();
					});
				}
				else{
					$scope.existe = true;
				}
			}
			else{
				$scope.incorrecto = true;
			}
		});
	};

	$scope.cancel = function () {
		$modalInstance.dismiss('cancel');
		$location.path( "/users/mensaje/" + consorcio);
	};
});